package com.livingflesh.stage;

import com.livingflesh.world.FleshWorldData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public final class StageManager {
    private StageManager() {
    }

    /** Номер текущего дня: первый день мира = 1. Учитывает пропуск ночи сном. */
    public static long currentDay(World world) {
        return world.getWorldTime() / 24000L + 1L;
    }

    /**
     * Подтягивает стадию к текущему дню.
     *
     * @param allowDowngrade если true, стадия может и понизиться (нужно для команды "stage auto")
     */
    public static void updateByTime(WorldServer world, FleshWorldData data, boolean allowDowngrade) {
        FleshStage target = FleshStage.forDay(currentDay(world));
        FleshStage current = data.getStage();
        if (target.id > current.id || (allowDowngrade && target.id != current.id)) {
            setStage(world, data, target, true);
        }
    }

    public static void setStage(WorldServer world, FleshWorldData data, FleshStage stage, boolean announce) {
        FleshStage old = data.getStage();
        data.setStage(stage);
        if (stage != FleshStage.DORMANT && data.getCores().isEmpty()) {
            // ядра нет, значит можно создавать новое сразу
            data.setNextCoreTime(0L);
        }
        if (announce && stage != old) {
            announce(world, stage);
        }
    }

    public static void announce(WorldServer world, FleshStage stage) {
        MinecraftServer server = world.getMinecraftServer();
        if (server == null) {
            return;
        }
        ITextComponent message = new TextComponentString("[Живая плоть] ")
                .setStyle(new Style().setColor(TextFormatting.DARK_RED).setBold(true));
        message.appendSibling(new TextComponentString("Стадия " + stage.id + ": " + stage.title)
                .setStyle(new Style().setColor(TextFormatting.RED).setBold(false)));
        server.getPlayerList().sendMessage(message);
    }
}

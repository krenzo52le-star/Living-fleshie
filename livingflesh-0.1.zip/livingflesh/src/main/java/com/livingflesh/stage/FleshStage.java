package com.livingflesh.stage;

/**
 * Стадии заражения мира. Настройки каждой стадии лежат прямо здесь,
 * чтобы баланс было легко править в одном месте.
 *
 * День считается так: первый день мира = день 1. Стадия 1 начинается с дня 2, стадия 2 с дня 4.
 */
public enum FleshStage {
    //          id  день  название          рост(тики) радиус  куски(тики) лимит  +HP   +урон +скор. шанс заражения при спавне
    DORMANT   (0, 0, "Спячка",           0,  0,   0, 0, 0.00D, 0.00D, 0.00D, 0.00F),
    INFECTION (1, 2, "Заражение",       40, 24, 240, 3, 0.25D, 0.25D, 0.00D, 0.00F),
    SPREAD    (2, 4, "Распространение", 25, 40, 120, 6, 0.60D, 0.50D, 0.10D, 0.20F);

    public final int id;
    public final int startDay;
    public final String title;
    /** Раз в сколько тиков плоть пытается разрастись (0 = не растёт). */
    public final int spreadInterval;
    /** Максимальный радиус разрастания вокруг ядра, в блоках. */
    public final int maxRadius;
    /** Раз в сколько тиков ядро пытается породить кусок плоти. */
    public final int pieceInterval;
    /** Максимум кусков плоти рядом с ядром. */
    public final int pieceCap;
    /** Бонусы заражённых мобов (доля от базового значения). */
    public final double healthBonus;
    public final double damageBonus;
    public final double speedBonus;
    /** Шанс, что обычный моб при появлении в мире сразу окажется заражённым. */
    public final float worldInfectChance;

    FleshStage(int id, int startDay, String title, int spreadInterval, int maxRadius, int pieceInterval,
               int pieceCap, double healthBonus, double damageBonus, double speedBonus, float worldInfectChance) {
        this.id = id;
        this.startDay = startDay;
        this.title = title;
        this.spreadInterval = spreadInterval;
        this.maxRadius = maxRadius;
        this.pieceInterval = pieceInterval;
        this.pieceCap = pieceCap;
        this.healthBonus = healthBonus;
        this.damageBonus = damageBonus;
        this.speedBonus = speedBonus;
        this.worldInfectChance = worldInfectChance;
    }

    public static FleshStage byId(int id) {
        FleshStage[] all = values();
        if (id < 0) {
            return all[0];
        }
        if (id >= all.length) {
            return all[all.length - 1];
        }
        return all[id];
    }

    /** Самая старшая стадия, которая уже началась к указанному дню. */
    public static FleshStage forDay(long day) {
        FleshStage[] all = values();
        for (int i = all.length - 1; i >= 0; i--) {
            if (day >= all[i].startDay) {
                return all[i];
            }
        }
        return all[0];
    }
}

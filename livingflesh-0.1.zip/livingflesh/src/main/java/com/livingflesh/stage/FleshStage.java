package com.livingflesh.stage;

/**
 * Стадии заражения мира. Настройки каждой стадии лежат прямо здесь,
 * чтобы баланс было легко править в одном месте.
 *
 * День считается так: первый день мира = день 1. Стадия 1 начинается с дня 2, стадия 2 с дня 4, стадия 3 с дня 14, стадия 4 с дня 23.
 */
public enum FleshStage {
    //          id  день  название          рост(тики) радиус  куски(тики) лимит  +HP   +урон +скор. шанс заражения  броня  отдача  дикие куски(тики, шанс)
    DORMANT   (0, 0,  "Спячка",           0,  0,   0, 0, 0.00D, 0.00D, 0.00D, 0.00F, 0.0D, 0.0D,    0, 0.00F),
    INFECTION (1, 2,  "Заражение",       40, 24, 400, 2, 0.25D, 0.25D, 0.10D, 0.00F, 0.0D, 0.0D,    0, 0.00F),
    SPREAD    (2, 4,  "Распространение", 25, 40, 200, 4, 0.60D, 0.50D, 0.20D, 0.20F, 0.0D, 0.0D,    0, 0.00F),
    MUTATION  (3, 14, "Мутация",         15, 60, 160, 5, 1.20D, 0.90D, 0.30D, 0.40F, 4.0D, 0.30D, 2400, 0.35F),
    RETRIBUTION(4, 23, "Расплата",     12, 80,   0, 0, 1.80D, 1.30D, 0.35D, 0.55F, 6.0D, 0.45D,    0, 0.00F);

    public final int id;
    public final int startDay;
    public final String title;
    /** Раз в сколько тиков плоть пытается разрастись (0 = не растёт). */
    public final int spreadInterval;
    /** Максимальный радиус разрастания вокруг ядра, в блоках. */
    public final int maxRadius;
    /** Раз в сколько тиков ядро пытается породить кусок плоти. */
    public final int pieceInterval;
    /** Максимум кусков плоти рядом с ядром. */
    public final int pieceCap;
    /** Бонусы заражённых мобов (доля от базового значения). */
    public final double healthBonus;
    public final double damageBonus;
    public final double speedBonus;
    /** Шанс, что обычный моб при появлении в мире сразу окажется заражённым. */
    public final float worldInfectChance;
    /** Плоская прибавка к броне и сопротивлению отдаче у заражённых (только поздние стадии). */
    public final double armorBonus;
    public final double knockbackResist;
    /** Редкие куски плоти вдали от очага: раз в сколько тиков делается попытка (0 = нет) и шанс успеха. */
    public final int wildPieceInterval;
    public final float wildPieceChance;
    /** Через сколько тиков после гибели ядра появится новое. */
    public final long coreRespawnDelay;
    /** Каратели (Пермадус) появляются сами: раз в сколько тиков делается попытка (0 = нет) и шанс успеха. */
    public final int karatelInterval;
    public final float karatelChance;

    FleshStage(int id, int startDay, String title, int spreadInterval, int maxRadius, int pieceInterval,
               int pieceCap, double healthBonus, double damageBonus, double speedBonus, float worldInfectChance,
               double armorBonus, double knockbackResist, int wildPieceInterval, float wildPieceChance) {
        this.id = id;
        this.startDay = startDay;
        this.title = title;
        this.spreadInterval = spreadInterval;
        this.maxRadius = maxRadius;
        this.pieceInterval = pieceInterval;
        this.pieceCap = pieceCap;
        this.healthBonus = healthBonus;
        this.damageBonus = damageBonus;
        this.speedBonus = speedBonus;
        this.worldInfectChance = worldInfectChance;
        this.armorBonus = armorBonus;
        this.knockbackResist = knockbackResist;
        this.wildPieceInterval = wildPieceInterval;
        this.wildPieceChance = wildPieceChance;
        boolean last = id >= 4;
        this.coreRespawnDelay = last ? 72000L : 24000L; // на последней стадии ядра появляются втрое реже
        this.karatelInterval = last ? 6000 : 0;
        this.karatelChance = last ? 0.25F : 0.0F;
    }

    public static FleshStage byId(int id) {
        FleshStage[] all = values();
        if (id < 0) {
            return all[0];
        }
        if (id >= all.length) {
            return all[all.length - 1];
        }
        return all[id];
    }

    /** Самая старшая стадия, которая уже началась к указанному дню. */
    public static FleshStage forDay(long day) {
        FleshStage[] all = values();
        for (int i = all.length - 1; i >= 0; i--) {
            if (day >= all[i].startDay) {
                return all[i];
            }
        }
        return all[0];
    }
}

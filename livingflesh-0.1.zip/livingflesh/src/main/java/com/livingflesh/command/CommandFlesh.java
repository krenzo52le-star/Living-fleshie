package com.livingflesh.command;

import com.livingflesh.stage.FleshStage;
import com.livingflesh.stage.StageManager;
import com.livingflesh.world.FleshSpreader;
import com.livingflesh.world.FleshWorldData;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.WorldServer;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;

/**
 * /flesh stage <0|1|2|3|4|auto>  - выставить стадию сразу (auto = снова считать по дням)
 * /flesh core [расстояние]   - создать ядро рядом с вами (по умолчанию в 100 блоках, на поверхности или под землёй)
 * /flesh info                - показать стадию, день и координаты ядер
 */
public class CommandFlesh extends CommandBase {

    @Override
    public String getName() {
        return "flesh";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/flesh stage <0|1|2|3|4|auto> | /flesh core [расстояние] | /flesh info";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) {
            throw new WrongUsageException(getUsage(sender));
        }
        WorldServer world = server.getWorld(0);
        FleshWorldData data = FleshWorldData.get(world);

        switch (args[0].toLowerCase()) {
            case "stage":
                executeStage(world, data, sender, args);
                break;
            case "core":
                executeCore(world, data, sender, args);
                break;
            case "info":
                executeInfo(world, data, sender);
                break;
            default:
                throw new WrongUsageException(getUsage(sender));
        }
    }

    private void executeStage(WorldServer world, FleshWorldData data, ICommandSender sender, String[] args) throws CommandException {
        if (args.length < 2) {
            throw new WrongUsageException("/flesh stage <0|1|2|3|4|auto>");
        }
        if (args[1].equalsIgnoreCase("auto")) {
            data.setManual(false);
            StageManager.updateByTime(world, data, true);
            sender.sendMessage(new TextComponentString("Стадия снова считается по дням. Сейчас: "
                    + data.getStage().id + " (" + data.getStage().title + ")"));
            return;
        }
        int id = parseInt(args[1], 0, FleshStage.values().length - 1);
        data.setManual(true);
        StageManager.setStage(world, data, FleshStage.byId(id), true);
        sender.sendMessage(new TextComponentString("Стадия выставлена вручную: " + id + ". "
                + "Автоматический рост по дням выключен, вернуть его можно командой /flesh stage auto"));
    }

    private void executeCore(WorldServer world, FleshWorldData data, ICommandSender sender, String[] args) throws CommandException {
        if (sender.getCommandSenderEntity() == null) {
            throw new CommandException("Эту команду нужно выполнять от имени игрока");
        }
        int distance = args.length > 1 ? parseInt(args[1], 5, 300) : 100;
        BlockPos pos = FleshSpreader.placeCoreAround(world, data, sender.getPosition(), distance);
        if (pos == null) {
            throw new CommandException("Не нашлось подходящего места для ядра, попробуйте ещё раз");
        }
        sender.sendMessage(new TextComponentString("Ядро создано: " + pos.getX() + " " + pos.getY() + " " + pos.getZ()));
    }

    private void executeInfo(WorldServer world, FleshWorldData data, ICommandSender sender) {
        FleshStage stage = data.getStage();
        sender.sendMessage(new TextComponentString("Стадия: " + stage.id + " (" + stage.title + ")"
                + (data.isManual() ? ", выставлена вручную" : ", по дням")));
        sender.sendMessage(new TextComponentString("День мира: " + StageManager.currentDay(world)
                + " (стадия 1 с дня " + FleshStage.INFECTION.startDay + ", стадия 2 с дня " + FleshStage.SPREAD.startDay + ")"));
        List<BlockPos> cores = data.getCores();
        if (cores.isEmpty()) {
            sender.sendMessage(new TextComponentString("Ядер нет"));
        }
        for (BlockPos core : cores) {
            sender.sendMessage(new TextComponentString("Ядро: " + core.getX() + " " + core.getY() + " " + core.getZ()));
        }
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos targetPos) {
        if (args.length == 1) {
            return getListOfStringsMatchingLastWord(args, "stage", "core", "info");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("stage")) {
            return getListOfStringsMatchingLastWord(args, "0", "1", "2", "3", "4", "auto");
        }
        return Collections.emptyList();
    }
}

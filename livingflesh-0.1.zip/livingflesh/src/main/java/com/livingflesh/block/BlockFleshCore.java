package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

/**
 * Ядро очага: из него растёт плоть и рождаются куски плоти.
 * Если ядро сломать, очаг перестаёт расти, а новое появится через один игровой день.
 */
public class BlockFleshCore extends Block {

    public BlockFleshCore() {
        super(Material.GROUND);
        setRegistryName(LivingFleshMod.MODID, "flesh_core");
        setTranslationKey(LivingFleshMod.MODID + ".flesh_core");
        setCreativeTab(com.livingflesh.ModTabs.TAB);
        setHardness(6.0F);
        setResistance(30.0F);
        setLightLevel(0.4F);
        setSoundType(SoundType.SLIME);
    }
}

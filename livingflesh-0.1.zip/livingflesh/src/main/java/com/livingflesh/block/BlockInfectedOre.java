package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

/** Заражённая руда: встречается в шахтах, как алмазы. Выпадает целиком, в печи даёт заражённый слиток. */
public class BlockInfectedOre extends Block {

    public BlockInfectedOre() {
        super(Material.ROCK);
        setRegistryName(LivingFleshMod.MODID, "infected_ore");
        setTranslationKey(LivingFleshMod.MODID + ".infected_ore");
        setCreativeTab(com.livingflesh.ModTabs.TAB);
        setHardness(3.0F);
        setResistance(5.0F);
        setSoundType(SoundType.STONE);
        setHarvestLevel("pickaxe", 1); // железная и выше... как железная руда: каменная кирка и лучше
    }
}

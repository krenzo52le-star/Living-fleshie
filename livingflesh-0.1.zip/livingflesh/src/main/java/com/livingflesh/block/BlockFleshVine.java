package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.ModBlocks;
import com.livingflesh.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.Random;

/** Свисающая плоть: растёт вниз из заражённого камня, листвы и плоти. Сквозь неё можно пройти. */
public class BlockFleshVine extends Block {
    private static final AxisAlignedBB BOX = new AxisAlignedBB(0.2D, 0.0D, 0.2D, 0.8D, 1.0D, 0.8D);

    public BlockFleshVine() {
        super(Material.PLANTS);
        setRegistryName(LivingFleshMod.MODID, "flesh_vine");
        setTranslationKey(LivingFleshMod.MODID + ".flesh_vine");
        setCreativeTab(com.livingflesh.ModTabs.TAB);
        setHardness(0.2F);
        setSoundType(SoundType.SLIME);
    }

    private static boolean canHangFrom(IBlockAccess world, BlockPos pos) {
        Block above = world.getBlockState(pos.up()).getBlock();
        return above == ModBlocks.INFECTED_STONE || above == ModBlocks.INFECTED_LEAVES
                || above == ModBlocks.FLESH_BLOCK || above == ModBlocks.FLESH_VINE;
    }

    @Override
    public boolean canPlaceBlockAt(World world, BlockPos pos) {
        return super.canPlaceBlockAt(world, pos) && canHangFrom(world, pos);
    }

    @Override
    public void neighborChanged(IBlockState state, World world, BlockPos pos, Block block, BlockPos fromPos) {
        if (!world.isRemote && !canHangFrom(world, pos)) {
            world.destroyBlock(pos, true);
        }
    }

    @Override
    public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess source, BlockPos pos) {
        return BOX;
    }

    @Nullable
    @Override
    public AxisAlignedBB getCollisionBoundingBox(IBlockState state, IBlockAccess world, BlockPos pos) {
        return NULL_AABB; // проходимая
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public BlockRenderLayer getRenderLayer() {
        return BlockRenderLayer.CUTOUT;
    }

    @Override
    public BlockFaceShape getBlockFaceShape(IBlockAccess world, IBlockState state, BlockPos pos, EnumFacing face) {
        return BlockFaceShape.UNDEFINED;
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return ModItems.DEAD_FLESH;
    }

    @Override
    public int quantityDropped(Random random) {
        return random.nextInt(2);
    }
}

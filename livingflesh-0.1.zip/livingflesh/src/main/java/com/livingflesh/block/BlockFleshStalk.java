package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.ModBlocks;
import com.livingflesh.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import java.util.Random;

/** Мясное растение: стебель из блоков, растёт на живой плоти (или на другом стебле), высота 2-5 блоков. */
public class BlockFleshStalk extends Block {
    private static final AxisAlignedBB BOX = new AxisAlignedBB(0.2D, 0.0D, 0.2D, 0.8D, 1.0D, 0.8D);

    public BlockFleshStalk() {
        super(Material.PLANTS);
        setRegistryName(LivingFleshMod.MODID, "flesh_stalk");
        setTranslationKey(LivingFleshMod.MODID + ".flesh_stalk");
        setCreativeTab(com.livingflesh.ModTabs.TAB);
        setHardness(0.6F);
        setSoundType(SoundType.SLIME);
    }

    private static boolean canStayOn(IBlockAccess world, BlockPos pos) {
        Block below = world.getBlockState(pos.down()).getBlock();
        return below == ModBlocks.FLESH_BLOCK || below == ModBlocks.FLESH_STALK || below == ModBlocks.FLESH_CORE;
    }

    @Override
    public boolean canPlaceBlockAt(World world, BlockPos pos) {
        return super.canPlaceBlockAt(world, pos) && canStayOn(world, pos);
    }

    @Override
    public void neighborChanged(IBlockState state, World world, BlockPos pos, Block block, BlockPos fromPos) {
        if (!world.isRemote && !canStayOn(world, pos)) {
            world.destroyBlock(pos, true);
        }
    }

    @Override
    public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess source, BlockPos pos) {
        return BOX;
    }

    @Override
    @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
    public net.minecraft.util.BlockRenderLayer getRenderLayer() {
        return net.minecraft.util.BlockRenderLayer.CUTOUT;
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false;
    }

    @Override
    public BlockFaceShape getBlockFaceShape(IBlockAccess world, IBlockState state, BlockPos pos, EnumFacing face) {
        return BlockFaceShape.UNDEFINED;
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return ModItems.DEAD_FLESH;
    }

    @Override
    public int quantityDropped(Random random) {
        return random.nextInt(2); // 0 или 1
    }
}

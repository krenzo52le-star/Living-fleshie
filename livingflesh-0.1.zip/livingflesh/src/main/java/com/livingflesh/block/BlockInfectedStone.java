package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Random;

/** Заражённый камень с двумя вариантами спрайта (выбирается случайно). Ломается в булыжник. */
public class BlockInfectedStone extends Block {
    public static final PropertyInteger VARIANT = PropertyInteger.create("variant", 0, 1);

    public BlockInfectedStone() {
        super(Material.ROCK);
        setRegistryName(LivingFleshMod.MODID, "infected_stone");
        setTranslationKey(LivingFleshMod.MODID + ".infected_stone");
        setCreativeTab(com.livingflesh.ModTabs.TAB);
        setHardness(1.5F);
        setResistance(10.0F);
        setSoundType(SoundType.STONE);
        setHarvestLevel("pickaxe", 0);
        setDefaultState(blockState.getBaseState().withProperty(VARIANT, 0));
    }

    /** Заражённый камень случайного варианта. */
    public IBlockState randomState(Random rand) {
        return getDefaultState().withProperty(VARIANT, rand.nextInt(2));
    }

    @Override
    protected BlockStateContainer createBlockState() {
        return new BlockStateContainer(this, VARIANT);
    }

    @Override
    public IBlockState getStateFromMeta(int meta) {
        return getDefaultState().withProperty(VARIANT, meta & 1);
    }

    @Override
    public int getMetaFromState(IBlockState state) {
        return state.getValue(VARIANT);
    }

    @Override
    public IBlockState getStateForPlacement(World world, BlockPos pos, EnumFacing facing, float hitX, float hitY,
                                            float hitZ, int meta, EntityLivingBase placer, EnumHand hand) {
        return randomState(world.rand);
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return Item.getItemFromBlock(Blocks.COBBLESTONE);
    }
}

package com.livingflesh.block;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.translation.I18n;

/** ItemBlock с запасным названием: если lang-файл не подхватился, показываем русское имя, а не ключ. */
public class NamedItemBlock extends ItemBlock {
    private final String fallback;

    public NamedItemBlock(Block block, String fallback) {
        super(block);
        this.fallback = fallback;
    }

    @Override
    @SuppressWarnings("deprecation")
    public String getItemStackDisplayName(ItemStack stack) {
        String key = getTranslationKey(stack) + ".name";
        if (I18n.canTranslate(key)) {
            return I18n.translateToLocal(key);
        }
        return fallback;
    }
}

package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;

import java.util.Random;

/** Заражённая трава: так выглядит обычный дёрн после заражения. Ломается в землю. */
public class BlockInfectedGrass extends Block {
    public BlockInfectedGrass() {
        super(Material.GROUND);
        setRegistryName(LivingFleshMod.MODID, "infected_grass");
        setTranslationKey(LivingFleshMod.MODID + ".infected_grass");
        setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
        setHardness(0.6F);
        setSoundType(SoundType.GROUND);
        setHarvestLevel("shovel", 0);
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return Item.getItemFromBlock(Blocks.DIRT);
    }
}

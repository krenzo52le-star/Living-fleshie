package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.InfectionHelper;
import com.livingflesh.world.FleshWorldData;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Обычный блок живой плоти. Замедляет игрока и заражает мобов, которые ходят по нему. */
public class BlockFlesh extends Block {

    public BlockFlesh() {
        super(Material.GROUND);
        setRegistryName(LivingFleshMod.MODID, "flesh_block");
        setTranslationKey(LivingFleshMod.MODID + ".flesh_block");
        setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
        setHardness(0.8F);
        setResistance(3.0F);
        setSoundType(SoundType.SLIME);
        setHarvestLevel("shovel", 0);
    }

    @Override
    public void onEntityWalk(World world, BlockPos pos, Entity entity) {
        if (world.isRemote) {
            return;
        }
        if (entity instanceof EntityPlayer) {
            ((EntityPlayer) entity).addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 40, 0, false, false));
            return;
        }
        if (entity instanceof EntityLiving && world.rand.nextFloat() < 0.04F) {
            int stage = FleshWorldData.get(world).getStage().id;
            if (stage >= 1) {
                InfectionHelper.infect((EntityLiving) entity, stage, true);
            }
        }
    }
}

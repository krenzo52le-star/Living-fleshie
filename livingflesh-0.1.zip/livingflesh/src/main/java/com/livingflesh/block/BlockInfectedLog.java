package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import net.minecraft.block.BlockRotatedPillar;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;

/** Заражённое бревно (поворачивается по оси, как обычное). */
public class BlockInfectedLog extends BlockRotatedPillar {
    public BlockInfectedLog() {
        super(Material.WOOD);
        setRegistryName(LivingFleshMod.MODID, "infected_log");
        setTranslationKey(LivingFleshMod.MODID + ".infected_log");
        setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
        setHardness(2.0F);
        setSoundType(SoundType.WOOD);
        setHarvestLevel("axe", 0);
    }
}

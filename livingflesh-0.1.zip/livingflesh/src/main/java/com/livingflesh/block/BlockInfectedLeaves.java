package com.livingflesh.block;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.util.BlockRenderLayer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.Random;

/** Заражённая листва: не опадает, с неё редко падает мёртвая плоть. */
public class BlockInfectedLeaves extends Block {
    public BlockInfectedLeaves() {
        super(Material.LEAVES);
        setRegistryName(LivingFleshMod.MODID, "infected_leaves");
        setTranslationKey(LivingFleshMod.MODID + ".infected_leaves");
        setCreativeTab(com.livingflesh.ModTabs.TAB);
        setHardness(0.2F);
        setLightOpacity(1);
        setSoundType(SoundType.PLANT);
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public BlockRenderLayer getRenderLayer() {
        return BlockRenderLayer.CUTOUT_MIPPED;
    }

    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return ModItems.DEAD_FLESH;
    }

    @Override
    public int quantityDropped(Random random) {
        return random.nextInt(10) == 0 ? 1 : 0;
    }
}

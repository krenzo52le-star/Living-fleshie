package com.livingflesh;

import com.livingflesh.command.CommandFlesh;
import com.livingflesh.world.FleshWorldEvents;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = LivingFleshMod.MODID, name = LivingFleshMod.NAME, version = LivingFleshMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class LivingFleshMod {
    public static final String MODID = "livingflesh";
    public static final String NAME = "Living Flesh";
    public static final String VERSION = "0.30.0";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new FleshWorldEvents());
        MinecraftForge.EVENT_BUS.register(new com.livingflesh.world.FleshDrops());
        MinecraftForge.EVENT_BUS.register(new com.livingflesh.world.InfectionSwordEvents());
        net.minecraftforge.fml.common.registry.GameRegistry.registerWorldGenerator(new com.livingflesh.world.InfectedOreGen(), 0);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // заражённая руда в печи даёт заражённый слиток
        net.minecraftforge.fml.common.registry.GameRegistry.addSmelting(ModBlocks.INFECTED_ORE,
                new net.minecraft.item.ItemStack(ModItems.INFECTED_INGOT), 0.7F);
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandFlesh());
    }
}

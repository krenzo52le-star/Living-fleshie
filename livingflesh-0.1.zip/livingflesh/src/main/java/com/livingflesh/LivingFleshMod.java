package com.livingflesh;

import com.livingflesh.command.CommandFlesh;
import com.livingflesh.world.FleshWorldEvents;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;

@Mod(modid = LivingFleshMod.MODID, name = LivingFleshMod.NAME, version = LivingFleshMod.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class LivingFleshMod {
    public static final String MODID = "livingflesh";
    public static final String NAME = "Living Flesh";
    public static final String VERSION = "0.2.0";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new FleshWorldEvents());
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandFlesh());
    }
}

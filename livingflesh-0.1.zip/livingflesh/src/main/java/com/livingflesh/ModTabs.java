package com.livingflesh;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;

/** Своя вкладка творческого режима со всеми предметами, блоками и яйцами мода (название берётся из lang: itemGroup.livingflesh). */
public class ModTabs {
    public static final CreativeTabs TAB = new CreativeTabs(LivingFleshMod.MODID) {
        @Override
        public ItemStack createIcon() {
            return new ItemStack(ModItems.ENCYCLOPEDIA);
        }
    };
}

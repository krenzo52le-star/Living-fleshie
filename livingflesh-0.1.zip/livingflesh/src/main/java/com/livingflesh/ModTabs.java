package com.livingflesh;

import com.livingflesh.util.Names;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;

/** Своя вкладка творческого режима со всеми предметами, блоками и яйцами мода. */
public class ModTabs {
    public static final CreativeTabs TAB = new CreativeTabs(LivingFleshMod.MODID) {
        @Override
        public ItemStack getTabIconItem() {
            return new ItemStack(ModItems.ENCYCLOPEDIA);
        }

        @Override
        public String getTranslatedTabLabel() {
            return Names.tr("itemGroup." + LivingFleshMod.MODID, "Живая плоть");
        }
    };
}

package com.livingflesh.util;

import net.minecraft.util.text.translation.I18n;

/** Название из lang-файла, а если он не подхватился, то запасное из кода (чтобы не видеть сырой ключ). */
public final class Names {
    private Names() {
    }

    @SuppressWarnings("deprecation")
    public static String tr(String key, String fallback) {
        return I18n.canTranslate(key) ? I18n.translateToLocal(key) : fallback;
    }
}

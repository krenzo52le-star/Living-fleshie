package com.livingflesh.entity;

import com.livingflesh.util.Names;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.world.World;

/**
 * Бешеная корова: заражённая корова, которая убила больше пяти здоровых существ. Тёмная плоть, раскрытая пасть
 * и щупальца изо рта. Намного крепче и опаснее обычной заражённой коровы.
 */
public class EntityRabidCow extends EntityInfectedCow {

    public EntityRabidCow(World world) {
        super(world);
        setSize(1.0F, 1.5F);
        this.experienceValue = 15;
        enablePersistence();
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.3D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(7.0D);
        this.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(0.5D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0D);
    }

    @Override
    public String getName() {
        if (hasCustomName()) {
            return getCustomNameTag();
        }
        return Names.tr("entity.livingflesh.rabid_cow.name", "Бешеная корова");
    }
}

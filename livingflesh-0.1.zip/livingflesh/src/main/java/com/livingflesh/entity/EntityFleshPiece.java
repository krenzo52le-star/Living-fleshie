package com.livingflesh.entity;

import com.livingflesh.stage.FleshStage;
import com.livingflesh.world.FleshWorldData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/**
 * Разносчик инфекции (раньше «кусок плоти»): быстрое насекомоподобное существо размером с курицу.
 * Охотится на игроков и животных, прыгает на цель и заражает всех, кого укусит. Голода не вызывает.
 */
public class EntityFleshPiece extends EntityMob {

    public EntityFleshPiece(World world) {
        super(world);
        setSize(0.7F, 0.5F);
        this.experienceValue = 2;
    }

    @Override
    protected void initEntityAI() {
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new AILeap(this));
        this.tasks.addTask(2, new EntityAIAttackMelee(this, 1.2D, false));
        this.tasks.addTask(5, new EntityAIWanderAvoidWater(this, 0.8D));
        this.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(7, new EntityAILookIdle(this));

        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, true));
        // охотится на ещё не заражённых мобов
        this.targetTasks.addTask(3, new EntityAINearestAttackableTarget<EntityLiving>(this, EntityLiving.class, 10, true, false,
                target -> target != null && InfectionHelper.canInfect(target) && InfectionHelper.stageOf(target) == 0));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(6.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.38D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(1.5D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(20.0D);
    }

    @Override
    public boolean attackEntityAsMob(Entity target) {
        boolean hit = super.attackEntityAsMob(target);
        if (hit && target instanceof EntityLivingBase) {
            EntityLivingBase victim = (EntityLivingBase) target;
            FleshStage stage = FleshWorldData.get(this.world).getStage();
            InfectionHelper.infect(victim, Math.max(1, stage.id), true);
        }
        return hit;
    }

    @Override
    protected void playStepSound(net.minecraft.util.math.BlockPos pos, net.minecraft.block.Block block) {
        this.playSound(SoundEvents.ENTITY_SPIDER_STEP, 0.15F, 1.3F);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_SLIME_DEATH;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    public String getName() {
        if (hasCustomName()) {
            return getCustomNameTag();
        }
        return com.livingflesh.util.Names.tr("entity.livingflesh.flesh_piece.name", "Разносчик инфекции");
    }

    /** Прыжок на цель: когда игрок или животное в нескольких блоках, существо резко бросается к нему. */
    private static class AILeap extends EntityAIBase {
        private final EntityFleshPiece mob;
        private EntityLivingBase target;

        AILeap(EntityFleshPiece mob) {
            this.mob = mob;
            setMutexBits(5);
        }

        @Override
        public boolean shouldExecute() {
            this.target = mob.getAttackTarget();
            if (target == null || !mob.onGround || !target.isEntityAlive()) {
                return false;
            }
            double distSq = mob.getDistanceSq(target);
            return distSq >= 4.0D && distSq <= 36.0D && mob.getRNG().nextInt(8) == 0;
        }

        @Override
        public boolean shouldContinueExecuting() {
            return false;
        }

        @Override
        public void startExecuting() {
            double dx = target.posX - mob.posX;
            double dz = target.posZ - mob.posZ;
            double len = Math.max(0.1D, Math.sqrt(dx * dx + dz * dz));
            mob.motionX = dx / len * 0.7D;
            mob.motionZ = dz / len * 0.7D;
            mob.motionY = 0.42D;
            mob.faceEntity(target, 30.0F, 30.0F);
        }
    }
}

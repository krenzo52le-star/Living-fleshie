package com.livingflesh.entity;

import com.livingflesh.util.Names;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/** Заражённая курица: свой скин, нападает на игроков, не несёт яиц. */
public class EntityInfectedChicken extends EntityChicken implements InfectedMob {

    public EntityInfectedChicken(World world) {
        super(world);
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.tasks.addTask(0, new InfectionHelper.FleshBiteAI(this));
        this.targetTasks.addTask(1, new InfectionHelper.FleshTargetAI(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        // у ванильного животного нет атрибута урона, без него оно не сможет кусаться
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(2.0D);
    }

    @Nullable
    @Override
    protected ResourceLocation getLootTable() {
        return null; // ничего ванильного, только дроп из общего обработчика
    }

    /** Заражённая курица не несёт яиц. */
    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        this.timeUntilNextEgg = Integer.MAX_VALUE;
    }

    @Override
    public String getName() {
        if (hasCustomName()) {
            return getCustomNameTag();
        }
        return Names.tr("entity.livingflesh.infected_chicken.name", "Заражённая курица");
    }
}

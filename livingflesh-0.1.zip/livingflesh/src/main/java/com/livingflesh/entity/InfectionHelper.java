package com.livingflesh.entity;

import com.livingflesh.stage.FleshStage;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.WorldServer;

import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Заражение мобов. Стадия заражения хранится в тегах моба (lf_stage_1, lf_stage_2),
 * поэтому она сама сохраняется вместе с мобом и видна командой /tag.
 */
public final class InfectionHelper {
    private static final String TAG_PREFIX = "lf_stage_";

    private static final UUID ID_HEALTH = UUID.fromString("6c1e0a52-3a10-4f7b-9d0e-0c1f5e7a1001");
    private static final UUID ID_DAMAGE = UUID.fromString("6c1e0a52-3a10-4f7b-9d0e-0c1f5e7a1002");
    private static final UUID ID_SPEED = UUID.fromString("6c1e0a52-3a10-4f7b-9d0e-0c1f5e7a1003");

    private InfectionHelper() {
    }

    /** Текущая стадия заражения моба: 0 = не заражён. */
    public static int stageOf(Entity entity) {
        Set<String> tags = entity.getTags();
        if (tags.isEmpty()) {
            return 0;
        }
        for (int i = FleshStage.values().length - 1; i >= 1; i--) {
            if (tags.contains(TAG_PREFIX + i)) {
                return i;
            }
        }
        return 0;
    }

    /** Можно ли вообще заразить этого моба (игроки, боссы, стойки и сами куски плоти не заражаются). */
    public static boolean canInfect(EntityLivingBase entity) {
        return entity instanceof EntityLiving
                && !(entity instanceof EntityFleshPiece)
                && entity.isEntityAlive()
                && entity.isNonBoss();
    }

    /**
     * Заражает моба на указанной стадии. Если он уже заражён такой же или более высокой стадией, ничего не делает.
     *
     * @return true, если моб был заражён или усилен
     */
    public static boolean infect(EntityLivingBase entity, int stage, boolean effects) {
        if (!canInfect(entity) || stage < 1 || stageOf(entity) >= stage) {
            return false;
        }
        for (int i = 1; i < FleshStage.values().length; i++) {
            entity.removeTag(TAG_PREFIX + i);
        }
        entity.addTag(TAG_PREFIX + stage);
        apply(entity, stage);
        entity.setHealth(entity.getMaxHealth());

        if (effects && entity.world instanceof WorldServer) {
            WorldServer world = (WorldServer) entity.world;
            Random rand = world.rand;
            for (int i = 0; i < 12; i++) {
                world.spawnParticle(EnumParticleTypes.REDSTONE,
                        entity.posX + (rand.nextDouble() - 0.5D) * entity.width,
                        entity.posY + rand.nextDouble() * entity.height,
                        entity.posZ + (rand.nextDouble() - 0.5D) * entity.width,
                        0, 0.8D, 0.05D, 0.1D, 1.0D);
            }
            world.playSound(null, entity.posX, entity.posY, entity.posZ,
                    SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1.0F, 0.6F);
        }
        return true;
    }

    /** Заново применить ИИ и бонусы уже заражённому мобу (после загрузки из сохранения). */
    public static void refresh(EntityLivingBase entity) {
        int stage = stageOf(entity);
        if (stage > 0) {
            apply(entity, stage);
        }
    }

    /** Заражение игрока пока лёгкое: только голод. Полноценная стадийная болезнь будет позже. */
    public static void affectPlayer(EntityLivingBase target) {
        if (target instanceof EntityPlayer) {
            target.addPotionEffect(new PotionEffect(MobEffects.HUNGER, 200, 0));
        }
    }

    /** Лёгкие красные частицы над заражёнными, чтобы их было видно среди обычных мобов. */
    public static void tickParticles(EntityLivingBase entity) {
        int stage = stageOf(entity);
        if (stage < 1 || !(entity.world instanceof WorldServer)) {
            return;
        }
        WorldServer world = (WorldServer) entity.world;
        Random rand = world.rand;
        double green = stage >= 2 ? 0.0D : 0.15D;
        world.spawnParticle(EnumParticleTypes.REDSTONE,
                entity.posX + (rand.nextDouble() - 0.5D) * entity.width,
                entity.posY + rand.nextDouble() * entity.height,
                entity.posZ + (rand.nextDouble() - 0.5D) * entity.width,
                0, 0.7D, green, 0.1D, 1.0D);
    }

    // ------------------------------------------------------------------ внутреннее

    private static void apply(EntityLivingBase entity, int stage) {
        FleshStage config = FleshStage.byId(stage);

        // у мирных животных нет атрибута урона, добавляем, чтобы они могли кусаться
        if (entity instanceof EntityCreature && entity.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE) == null) {
            entity.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(2.0D);
        }
        setModifier(entity, SharedMonsterAttributes.MAX_HEALTH, ID_HEALTH, "Flesh health", config.healthBonus);
        setModifier(entity, SharedMonsterAttributes.ATTACK_DAMAGE, ID_DAMAGE, "Flesh damage", config.damageBonus);
        setModifier(entity, SharedMonsterAttributes.MOVEMENT_SPEED, ID_SPEED, "Flesh speed", config.speedBonus);
        ensureAggression(entity);
    }

    private static void setModifier(EntityLivingBase entity, IAttribute attribute, UUID id, String name, double amount) {
        IAttributeInstance instance = entity.getEntityAttribute(attribute);
        if (instance == null) {
            return;
        }
        instance.removeModifier(id);
        if (amount != 0.0D) {
            instance.applyModifier(new AttributeModifier(id, name, amount, 1)); // 1 = прибавка к базовому значению в долях
        }
    }

    /** Мирные заражённые животные начинают нападать на игроков. Монстры и так агрессивны. */
    private static void ensureAggression(EntityLivingBase entity) {
        if (!(entity instanceof EntityCreature) || entity instanceof IMob) {
            return;
        }
        EntityCreature creature = (EntityCreature) entity;
        for (EntityAITasks.EntityAITaskEntry entry : creature.tasks.taskEntries) {
            if (entry.action instanceof FleshMeleeAI) {
                return; // уже добавлено
            }
        }
        creature.tasks.addTask(0, new FleshMeleeAI(creature));
        creature.targetTasks.addTask(1, new FleshTargetAI(creature));
    }

    public static class FleshMeleeAI extends EntityAIAttackMelee {
        public FleshMeleeAI(EntityCreature creature) {
            super(creature, 1.2D, false);
        }
    }

    public static class FleshTargetAI extends EntityAINearestAttackableTarget<EntityPlayer> {
        public FleshTargetAI(EntityCreature creature) {
            super(creature, EntityPlayer.class, true);
        }
    }
}

package com.livingflesh.entity;

import com.livingflesh.stage.FleshStage;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.WorldServer;

import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Заражение мобов. Стадия заражения хранится в тегах моба (lf_stage_1, lf_stage_2),
 * поэтому она сама сохраняется вместе с мобом и видна командой /tag.
 *
 * Заражённые мобы это отдельные существа (EntityInfectedCow, EntityInfectedPig) со своими
 * скинами и яйцами призыва. При заражении обычная корова или свинья заменяется такой версией.
 * Мобы, у которых заражённой версии ещё нет, не заражаются и остаются ванильными.
 */
public final class InfectionHelper {
    private static final String TAG_PREFIX = "lf_stage_";

    private static final UUID ID_HEALTH = UUID.fromString("6c1e0a52-3a10-4f7b-9d0e-0c1f5e7a1001");
    private static final UUID ID_DAMAGE = UUID.fromString("6c1e0a52-3a10-4f7b-9d0e-0c1f5e7a1002");
    private static final UUID ID_SPEED = UUID.fromString("6c1e0a52-3a10-4f7b-9d0e-0c1f5e7a1003");
    private static final UUID ID_ARMOR = UUID.fromString("6c1e0a52-3a10-4f7b-9d0e-0c1f5e7a1004");
    private static final UUID ID_KNOCK = UUID.fromString("6c1e0a52-3a10-4f7b-9d0e-0c1f5e7a1005");

    private InfectionHelper() {
    }

    /** Текущая стадия заражения моба: 0 = не заражён. */
    public static int stageOf(Entity entity) {
        Set<String> tags = entity.getTags();
        if (tags.isEmpty()) {
            return 0;
        }
        for (int i = FleshStage.values().length - 1; i >= 1; i--) {
            if (tags.contains(TAG_PREFIX + i)) {
                return i;
            }
        }
        return 0;
    }

    /** Можно ли заразить этого моба. Заражаются только те, у кого есть заражённая версия (корова, свинья, овца, курица, зомби, житель); остальные не трогаем. */
    public static boolean canInfect(EntityLivingBase entity) {
        return (entity instanceof InfectedMob || entity.getClass() == EntityCow.class || entity.getClass() == EntityPig.class
                || entity.getClass() == EntityZombie.class || entity.getClass() == EntitySheep.class
                || entity.getClass() == EntityChicken.class || entity.getClass() == EntityVillager.class)
                && entity.isEntityAlive();
    }

    /**
     * Заражает моба на указанной стадии. Если он уже заражён такой же или более высокой стадией, ничего не делает.
     * Обычные корова и свинья заменяются заражёнными версиями.
     *
     * @return заражённый моб (это может быть новое существо вместо старого) или null, если заражения не было
     */
    public static EntityLivingBase infect(EntityLivingBase entity, int stage, boolean effects) {
        if (!canInfect(entity) || stage < 1 || stageOf(entity) >= stage) {
            return null;
        }
        EntityLivingBase result = entity;
        if (!(entity instanceof InfectedMob)) {
            EntityLiving variant = createInfectedVariant((EntityLiving) entity);
            if (variant == null) {
                return null;
            }
            result = variant;
        }

        for (int i = 1; i < FleshStage.values().length; i++) {
            result.removeTag(TAG_PREFIX + i);
        }
        result.addTag(TAG_PREFIX + stage);
        apply(result, stage);
        result.setHealth(result.getMaxHealth());

        if (result != entity) {
            entity.setDead();
            entity.world.spawnEntity(result);
        }

        if (effects && result.world instanceof WorldServer) {
            WorldServer world = (WorldServer) result.world;
            Random rand = world.rand;
            for (int i = 0; i < 12; i++) {
                world.spawnParticle(EnumParticleTypes.REDSTONE,
                        result.posX + (rand.nextDouble() - 0.5D) * result.width,
                        result.posY + rand.nextDouble() * result.height,
                        result.posZ + (rand.nextDouble() - 0.5D) * result.width,
                        0, 0.8D, 0.05D, 0.1D, 1.0D);
            }
            world.playSound(null, result.posX, result.posY, result.posZ,
                    SoundEvents.ENTITY_SLIME_SQUISH, SoundCategory.HOSTILE, 1.0F, 0.6F);
        }
        return result;
    }

    /** Заново применить ИИ и бонусы уже заражённому мобу (после загрузки из сохранения). */
    public static void refresh(EntityLivingBase entity) {
        int stage = stageOf(entity);
        if (stage > 0) {
            apply(entity, stage);
        }
    }

    /** Заражение игрока пока лёгкое: только голод. Полноценная стадийная болезнь будет позже. */
    public static void affectPlayer(EntityLivingBase target) {
        if (target instanceof EntityPlayer) {
            target.addPotionEffect(new PotionEffect(MobEffects.HUNGER, 200, 0));
        }
    }

    /** Лёгкие красные частицы над заражёнными, чтобы их было видно среди обычных мобов. */
    public static void tickParticles(EntityLivingBase entity) {
        int stage = stageOf(entity);
        if (stage < 1 || !(entity.world instanceof WorldServer)) {
            return;
        }
        WorldServer world = (WorldServer) entity.world;
        Random rand = world.rand;
        double green = stage >= 2 ? 0.0D : 0.15D;
        world.spawnParticle(EnumParticleTypes.REDSTONE,
                entity.posX + (rand.nextDouble() - 0.5D) * entity.width,
                entity.posY + rand.nextDouble() * entity.height,
                entity.posZ + (rand.nextDouble() - 0.5D) * entity.width,
                0, 0.7D, green, 0.1D, 1.0D);
    }

    // ------------------------------------------------------------------ внутреннее

    /**
     * Для обычных коровы и свиньи создаёт заражённую версию с теми же данными (положение, здоровье, возраст, имя).
     * Для остальных мобов возвращает null.
     */
    private static EntityLiving createInfectedVariant(EntityLiving old) {
        EntityLiving fresh;
        if (old.getClass() == EntityCow.class) {
            fresh = new EntityInfectedCow(old.world);
        } else if (old.getClass() == EntityPig.class) {
            fresh = new EntityInfectedPig(old.world);
        } else if (old.getClass() == EntityZombie.class) {
            fresh = new EntityInfectedZombie(old.world);
        } else if (old.getClass() == EntitySheep.class) {
            fresh = new EntityInfectedSheep(old.world);
        } else if (old.getClass() == EntityChicken.class) {
            fresh = new EntityInfectedChicken(old.world);
        } else if (old.getClass() == EntityVillager.class) {
            fresh = new EntityInfectedVillager(old.world);
        } else {
            return null;
        }
        NBTTagCompound data = old.writeToNBT(new NBTTagCompound());
        // у нового существа должен быть свой идентификатор
        data.removeTag("UUIDMost");
        data.removeTag("UUIDLeast");
        fresh.readFromNBT(data);
        fresh.setLocationAndAngles(old.posX, old.posY, old.posZ, old.rotationYaw, old.rotationPitch);
        return fresh;
    }

    private static void apply(EntityLivingBase entity, int stage) {
        FleshStage config = FleshStage.byId(stage);

        setModifier(entity, SharedMonsterAttributes.MAX_HEALTH, ID_HEALTH, "Flesh health", config.healthBonus);
        setModifier(entity, SharedMonsterAttributes.ATTACK_DAMAGE, ID_DAMAGE, "Flesh damage", config.damageBonus);
        setModifier(entity, SharedMonsterAttributes.MOVEMENT_SPEED, ID_SPEED, "Flesh speed", config.speedBonus);
        setModifier(entity, SharedMonsterAttributes.ARMOR, ID_ARMOR, "Flesh armor", config.armorBonus, 0);
        setModifier(entity, SharedMonsterAttributes.KNOCKBACK_RESISTANCE, ID_KNOCK, "Flesh knockback", config.knockbackResist, 0);
    }

    private static void setModifier(EntityLivingBase entity, IAttribute attribute, UUID id, String name, double amount) {
        setModifier(entity, attribute, id, name, amount, 1);
    }

    /** operation: 0 = прибавка к значению, 1 = доля от базового значения. */
    private static void setModifier(EntityLivingBase entity, IAttribute attribute, UUID id, String name, double amount, int operation) {
        IAttributeInstance instance = entity.getEntityAttribute(attribute);
        if (instance == null) {
            return;
        }
        instance.removeModifier(id);
        if (amount != 0.0D) {
            instance.applyModifier(new AttributeModifier(id, name, amount, operation));
        }
    }

    /** Свой укус вместо ванильного ИИ ближнего боя: сам подходит и сам наносит урон. */
    public static class FleshBiteAI extends EntityAIBase {
        private final EntityCreature mob;
        private int cooldown;
        private int repath;

        public FleshBiteAI(EntityCreature mob) {
            this.mob = mob;
            setMutexBits(3);
        }

        private boolean valid(EntityLivingBase target) {
            if (target == null || !target.isEntityAlive()) {
                return false;
            }
            return !(target instanceof EntityPlayer) || !(((EntityPlayer) target).isCreative() || ((EntityPlayer) target).isSpectator());
        }

        @Override
        public boolean shouldExecute() {
            return valid(mob.getAttackTarget());
        }

        @Override
        public boolean shouldContinueExecuting() {
            return valid(mob.getAttackTarget());
        }

        @Override
        public void resetTask() {
            mob.getNavigator().clearPath();
        }

        @Override
        public void updateTask() {
            EntityLivingBase target = mob.getAttackTarget();
            if (target == null) {
                return;
            }
            mob.getLookHelper().setLookPositionWithEntity(target, 30.0F, 30.0F);
            if (--repath <= 0) {
                repath = 4 + mob.getRNG().nextInt(7);
                mob.getNavigator().tryMoveToEntityLiving(target, 1.25D);
            }
            if (cooldown > 0) {
                cooldown--;
            }
            double reach = (mob.width + target.width) / 2.0D + 1.3D;
            double dx = target.posX - mob.posX;
            double dz = target.posZ - mob.posZ;
            boolean close = dx * dx + dz * dz <= reach * reach && Math.abs(target.posY - mob.posY) < 2.0D;
            if (close && cooldown <= 0) {
                cooldown = 20;
                mob.swingArm(EnumHand.MAIN_HAND);
                IAttributeInstance attr = mob.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE);
                float damage = attr != null ? (float) attr.getAttributeValue() : 3.0F;
                if (target.attackEntityFrom(DamageSource.causeMobDamage(mob), damage)) {
                    affectPlayer(target);
                }
            }
        }
    }

    public static class FleshTargetAI extends EntityAINearestAttackableTarget<EntityPlayer> {
        public FleshTargetAI(EntityCreature creature) {
            super(creature, EntityPlayer.class, true);
        }
    }
}

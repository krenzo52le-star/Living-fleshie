package com.livingflesh.entity;

import com.livingflesh.util.Names;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/** Заражённый зомби: отдельное существо со своим скином. Из него падает только мёртвая плоть. */
public class EntityInfectedZombie extends EntityZombie implements InfectedMob {

    public EntityInfectedZombie(World world) {
        super(world);
    }

    @Nullable
    @Override
    protected ResourceLocation getLootTable() {
        return null; // никакой гнилой плоти и прочего, только мёртвая плоть из общего обработчика
    }

    @Override
    public String getName() {
        if (hasCustomName()) {
            return getCustomNameTag();
        }
        return Names.tr("entity.livingflesh.infected_zombie.name", "Заражённый зомби");
    }
}

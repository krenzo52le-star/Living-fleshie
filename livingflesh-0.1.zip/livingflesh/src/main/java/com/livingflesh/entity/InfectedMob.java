package com.livingflesh.entity;

/** Метка для отдельных заражённых существ мода. */
public interface InfectedMob {
}

package com.livingflesh.entity;

import com.livingflesh.util.Names;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/** Заражённая овца: свой скин, нападает на игроков, без шерсти и мяса. */
public class EntityInfectedSheep extends EntitySheep implements InfectedMob {

    public EntityInfectedSheep(World world) {
        super(world);
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        InfectionHelper.makeHostile(this); // не паникует и не убегает, как ванильные враждебные мобы
        this.tasks.addTask(0, new InfectionHelper.FleshBiteAI(this));
        this.targetTasks.addTask(1, new InfectionHelper.FleshTargetAI(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        // у ванильного животного нет атрибута урона, без него оно не сможет кусаться
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
    }

    @Nullable
    @Override
    protected ResourceLocation getLootTable() {
        return null; // ничего ванильного, только дроп из общего обработчика
    }

    /** Заражённая овца всегда «стриженая»: ванильная шерсть не рисуется, виден заражённый скин. */
    @Override
    public boolean getSheared() {
        return true;
    }

    @Override
    public String getName() {
        if (hasCustomName()) {
            return getCustomNameTag();
        }
        return Names.tr("entity.livingflesh.infected_sheep.name", "Заражённая овца");
    }

    @Override
    protected net.minecraft.util.SoundEvent getAmbientSound() {
        return null; // заражённые молчат
    }

    @Override
    protected net.minecraft.util.SoundEvent getHurtSound(net.minecraft.util.DamageSource source) {
        return null;
    }

    @Override
    protected net.minecraft.util.SoundEvent getDeathSound() {
        return null;
    }
}

package com.livingflesh.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.world.World;

/** Заражённая свинья: обычная свинья с другим скином, которая нападает на игроков. */
public class EntityInfectedPig extends EntityPig implements InfectedMob {

    public EntityInfectedPig(World world) {
        super(world);
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        this.tasks.addTask(0, new InfectionHelper.FleshBiteAI(this));
        this.targetTasks.addTask(1, new InfectionHelper.FleshTargetAI(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        // у ванильного животного нет атрибута урона, без него оно не сможет кусаться
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
    }

    @Override
    public String getName() {
        if (hasCustomName()) {
            return getCustomNameTag();
        }
        return com.livingflesh.util.Names.tr("entity.livingflesh.infected_pig.name", "Заражённая свинья");
    }
}

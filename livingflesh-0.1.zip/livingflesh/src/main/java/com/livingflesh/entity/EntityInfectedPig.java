package com.livingflesh.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/** Заражённая свинья: обычная свинья с другим скином, которая нападает на игроков. */
public class EntityInfectedPig extends EntityPig implements InfectedMob {

    public EntityInfectedPig(World world) {
        super(world);
    }

    @Override
    protected void initEntityAI() {
        super.initEntityAI();
        InfectionHelper.makeHostile(this); // не паникует и не убегает, как ванильные враждебные мобы
        this.tasks.addTask(0, new InfectionHelper.FleshBiteAI(this));
        this.targetTasks.addTask(1, new InfectionHelper.FleshTargetAI(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        // у ванильного животного нет атрибута урона, без него оно не сможет кусаться
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
    }

    @Nullable
    @Override
    protected ResourceLocation getLootTable() {
        return null; // ни мяса, ни кожи, только мёртвая плоть из общего обработчика
    }

    @Override
    public String getName() {
        if (hasCustomName()) {
            return getCustomNameTag();
        }
        return com.livingflesh.util.Names.tr("entity.livingflesh.infected_pig.name", "Заражённая свинья");
    }

    @Override
    protected net.minecraft.util.SoundEvent getAmbientSound() {
        return null; // заражённые молчат
    }

    @Override
    protected net.minecraft.util.SoundEvent getHurtSound(net.minecraft.util.DamageSource source) {
        return null;
    }

    @Override
    protected net.minecraft.util.SoundEvent getDeathSound() {
        return null;
    }
}

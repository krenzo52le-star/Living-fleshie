package com.livingflesh;

import com.livingflesh.item.ItemEncyclopedia;
import com.livingflesh.item.ItemFleshEgg;
import net.minecraft.item.Item;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID)
public class ModItems {
    public static final Item DEAD_FLESH = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.dead_flesh.name", "Мёртвая плоть");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".dead_flesh")
            .setRegistryName(LivingFleshMod.MODID, "dead_flesh")
            .setCreativeTab(CreativeTabs.MISC);

    public static final Item FLESH_BONE = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.flesh_bone.name", "Кость из плоти");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".flesh_bone")
            .setRegistryName(LivingFleshMod.MODID, "flesh_bone")
            .setCreativeTab(CreativeTabs.MISC);

    public static final Item EGG_FLESH_PIECE = new ItemFleshEgg("egg_flesh_piece", "flesh_piece", "Яйцо призыва: Разносчик инфекции");
    public static final Item EGG_INFECTED_COW = new ItemFleshEgg("egg_infected_cow", "infected_cow", "Яйцо призыва: Заражённая корова");
    public static final Item EGG_INFECTED_PIG = new ItemFleshEgg("egg_infected_pig", "infected_pig", "Яйцо призыва: Заражённая свинья");

    public static final Item EGG_INFECTED_ZOMBIE = new ItemFleshEgg("egg_infected_zombie", "infected_zombie", "Яйцо призыва: Заражённый зомби");
    public static final Item EGG_INFECTED_SHEEP = new ItemFleshEgg("egg_infected_sheep", "infected_sheep", "Яйцо призыва: Заражённая овца");
    public static final Item EGG_INFECTED_CHICKEN = new ItemFleshEgg("egg_infected_chicken", "infected_chicken", "Яйцо призыва: Заражённая курица");
    public static final Item EGG_PERMADUS = new ItemFleshEgg("egg_permadus", "permadus", "Яйцо призыва: Каратель");
    public static final Item EGG_INFECTED_VILLAGER = new ItemFleshEgg("egg_infected_villager", "infected_villager", "Яйцо призыва: Заражённый житель");
    public static final Item ENCYCLOPEDIA = new ItemEncyclopedia();

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(DEAD_FLESH, FLESH_BONE, EGG_FLESH_PIECE, EGG_INFECTED_COW, EGG_INFECTED_PIG, EGG_INFECTED_ZOMBIE, EGG_INFECTED_SHEEP, EGG_INFECTED_CHICKEN, EGG_INFECTED_VILLAGER, EGG_PERMADUS, ENCYCLOPEDIA);
    }
}

package com.livingflesh;

import com.livingflesh.item.ItemEncyclopedia;
import com.livingflesh.item.ItemFleshEgg;
import net.minecraft.item.Item;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID)
public class ModItems {
    public static final Item DEAD_FLESH = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.dead_flesh.name", "Мёртвая плоть");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".dead_flesh")
            .setRegistryName(LivingFleshMod.MODID, "dead_flesh")
            .setCreativeTab(com.livingflesh.ModTabs.TAB);

    public static final Item FLESH_BONE = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.flesh_bone.name", "Кость из плоти");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".flesh_bone")
            .setRegistryName(LivingFleshMod.MODID, "flesh_bone")
            .setCreativeTab(com.livingflesh.ModTabs.TAB);

    public static final Item PERMADUS_CORE = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.permadus_core.name", "Ядро Карателя");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".permadus_core")
            .setRegistryName(LivingFleshMod.MODID, "permadus_core")
            .setCreativeTab(com.livingflesh.ModTabs.TAB);

    public static final Item REINFORCED_WEB = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.reinforced_web.name", "Укреплённая паутина");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".reinforced_web")
            .setRegistryName(LivingFleshMod.MODID, "reinforced_web")
            .setCreativeTab(com.livingflesh.ModTabs.TAB);

    public static final Item REINFORCED_BASE = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.reinforced_base.name", "Укреплённая основа");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".reinforced_base")
            .setRegistryName(LivingFleshMod.MODID, "reinforced_base")
            .setCreativeTab(com.livingflesh.ModTabs.TAB);

    public static final Item CHARGED_INGOT = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.charged_ingot.name", "Заряженный слиток");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".charged_ingot")
            .setRegistryName(LivingFleshMod.MODID, "charged_ingot")
            .setCreativeTab(com.livingflesh.ModTabs.TAB);

    /** Материал меча инфекции: итоговый урон 11 (1 + 3 меча + 7 материала). */
    public static final net.minecraft.item.Item.ToolMaterial INFECTION_MATERIAL =
            net.minecraftforge.common.util.EnumHelper.addToolMaterial("LIVINGFLESH_INFECTION", 3, 1800, 8.0F, 7.0F, 12);

    public static final Item INFECTION_SWORD = new net.minecraft.item.ItemSword(INFECTION_MATERIAL) {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.infection_sword.name", "Меч инфекции");
        }

        @Override
        @net.minecraftforge.fml.relauncher.SideOnly(net.minecraftforge.fml.relauncher.Side.CLIENT)
        public void addInformation(net.minecraft.item.ItemStack stack, @javax.annotation.Nullable net.minecraft.world.World world,
                                   java.util.List<String> tooltip, net.minecraft.client.util.ITooltipFlag flag) {
            tooltip.add("\u00a77+50% урона по заражённым");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".infection_sword")
            .setRegistryName(LivingFleshMod.MODID, "infection_sword")
            .setCreativeTab(com.livingflesh.ModTabs.TAB);

    public static final Item INFECTED_INGOT = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.infected_ingot.name", "Заражённый слиток");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".infected_ingot")
            .setRegistryName(LivingFleshMod.MODID, "infected_ingot")
            .setCreativeTab(com.livingflesh.ModTabs.TAB);

    public static final Item EGG_FLESH_PIECE = new ItemFleshEgg("egg_flesh_piece", "flesh_piece", "Яйцо призыва: Разносчик инфекции");
    public static final Item EGG_INFECTED_COW = new ItemFleshEgg("egg_infected_cow", "infected_cow", "Яйцо призыва: Заражённая корова");
    public static final Item EGG_INFECTED_PIG = new ItemFleshEgg("egg_infected_pig", "infected_pig", "Яйцо призыва: Заражённая свинья");

    public static final Item EGG_INFECTED_ZOMBIE = new ItemFleshEgg("egg_infected_zombie", "infected_zombie", "Яйцо призыва: Заражённый зомби");
    public static final Item EGG_INFECTED_SHEEP = new ItemFleshEgg("egg_infected_sheep", "infected_sheep", "Яйцо призыва: Заражённая овца");
    public static final Item EGG_INFECTED_CHICKEN = new ItemFleshEgg("egg_infected_chicken", "infected_chicken", "Яйцо призыва: Заражённая курица");
    public static final Item EGG_PERMADUS = new ItemFleshEgg("egg_permadus", "permadus", "Яйцо призыва: Каратель");
    public static final Item EGG_ARACHNEIDEF = new ItemFleshEgg("egg_arachneidef", "arachneidef", "Яйцо призыва: Арахнейдеф");
    public static final Item EGG_RABID_COW = new ItemFleshEgg("egg_rabid_cow", "rabid_cow", "Яйцо призыва: Бешеная корова");
    public static final Item EGG_INFECTED_VILLAGER = new ItemFleshEgg("egg_infected_villager", "infected_villager", "Яйцо призыва: Заражённый житель");
    public static final Item ENCYCLOPEDIA = new ItemEncyclopedia();

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(DEAD_FLESH, FLESH_BONE, PERMADUS_CORE, REINFORCED_WEB, REINFORCED_BASE, CHARGED_INGOT, INFECTION_SWORD, INFECTED_INGOT, EGG_FLESH_PIECE, EGG_INFECTED_COW, EGG_INFECTED_PIG, EGG_INFECTED_ZOMBIE, EGG_INFECTED_SHEEP, EGG_INFECTED_CHICKEN, EGG_INFECTED_VILLAGER, EGG_PERMADUS, EGG_RABID_COW, EGG_ARACHNEIDEF, ENCYCLOPEDIA);
    }
}

package com.livingflesh;

import com.livingflesh.item.ItemEncyclopedia;
import com.livingflesh.item.ItemFleshEgg;
import net.minecraft.item.Item;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID)
public class ModItems {
    public static final Item DEAD_FLESH = new Item() {
        @Override
        public String getItemStackDisplayName(net.minecraft.item.ItemStack stack) {
            return com.livingflesh.util.Names.tr("item.livingflesh.dead_flesh.name", "Мёртвая плоть");
        }
    }
            .setTranslationKey(LivingFleshMod.MODID + ".dead_flesh")
            .setRegistryName(LivingFleshMod.MODID, "dead_flesh")
            .setCreativeTab(CreativeTabs.MISC);

    public static final Item EGG_FLESH_PIECE = new ItemFleshEgg("egg_flesh_piece", "flesh_piece", "Яйцо призыва: Кусок плоти");
    public static final Item EGG_INFECTED_COW = new ItemFleshEgg("egg_infected_cow", "infected_cow", "Яйцо призыва: Заражённая корова");
    public static final Item EGG_INFECTED_PIG = new ItemFleshEgg("egg_infected_pig", "infected_pig", "Яйцо призыва: Заражённая свинья");

    public static final Item ENCYCLOPEDIA = new ItemEncyclopedia();

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(DEAD_FLESH, EGG_FLESH_PIECE, EGG_INFECTED_COW, EGG_INFECTED_PIG, ENCYCLOPEDIA);
    }
}

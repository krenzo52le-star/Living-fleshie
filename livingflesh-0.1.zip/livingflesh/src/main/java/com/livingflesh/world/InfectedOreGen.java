package com.livingflesh.world;

import com.livingflesh.ModBlocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraftforge.fml.common.IWorldGenerator;

import java.util.Random;

/** Жилы заражённой руды в Верхнем мире: одна попытка на чанк на высотах 1-16, как у алмазов. */
public class InfectedOreGen implements IWorldGenerator {
    private static final int VEIN_SIZE = 6;

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator generator, IChunkProvider provider) {
        if (world.provider.getDimension() != 0) {
            return;
        }
        int x = chunkX * 16 + random.nextInt(16);
        int y = 1 + random.nextInt(16);
        int z = chunkZ * 16 + random.nextInt(16);
        new WorldGenMinable(ModBlocks.INFECTED_ORE.getDefaultState(), VEIN_SIZE).generate(world, random, new BlockPos(x, y, z));
    }
}

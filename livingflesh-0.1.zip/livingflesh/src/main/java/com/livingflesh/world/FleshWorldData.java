package com.livingflesh.world;

import com.livingflesh.stage.FleshStage;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.common.util.Constants;

import java.util.ArrayList;
import java.util.List;

/** Данные мира, которые сохраняются вместе с сохранением: стадия, режим стадии и список ядер. */
public class FleshWorldData extends WorldSavedData {
    public static final String NAME = "livingflesh_world";

    private int stage = 0;
    /** true, если стадия выставлена командой и не должна меняться по дням. */
    private boolean manual = false;
    /** Не создавать новое ядро, пока totalWorldTime меньше этого значения. */
    private long nextCoreTime = 0L;
    private final List<BlockPos> cores = new ArrayList<>();

    public FleshWorldData() {
        super(NAME);
    }

    public FleshWorldData(String name) {
        super(name);
    }

    public static FleshWorldData get(World world) {
        MapStorage storage = world.getMapStorage();
        FleshWorldData data = (FleshWorldData) storage.getOrLoadData(FleshWorldData.class, NAME);
        if (data == null) {
            data = new FleshWorldData();
            storage.setData(NAME, data);
        }
        return data;
    }

    public FleshStage getStage() {
        return FleshStage.byId(stage);
    }

    public void setStage(FleshStage newStage) {
        this.stage = newStage.id;
        markDirty();
    }

    public boolean isManual() {
        return manual;
    }

    public void setManual(boolean manual) {
        this.manual = manual;
        markDirty();
    }

    public long getNextCoreTime() {
        return nextCoreTime;
    }

    public void setNextCoreTime(long time) {
        this.nextCoreTime = time;
        markDirty();
    }

    /** Копия списка, чтобы можно было безопасно удалять ядра во время обхода. */
    public List<BlockPos> getCores() {
        return new ArrayList<>(cores);
    }

    public void addCore(BlockPos pos) {
        cores.add(pos.toImmutable());
        markDirty();
    }

    public void removeCore(BlockPos pos) {
        cores.remove(pos);
        markDirty();
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        stage = nbt.getInteger("stage");
        manual = nbt.getBoolean("manual");
        nextCoreTime = nbt.getLong("nextCoreTime");
        cores.clear();
        NBTTagList list = nbt.getTagList("cores", Constants.NBT.TAG_COMPOUND);
        for (int i = 0; i < list.tagCount(); i++) {
            cores.add(NBTUtil.getPosFromTag(list.getCompoundTagAt(i)));
        }
    }

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        nbt.setInteger("stage", stage);
        nbt.setBoolean("manual", manual);
        nbt.setLong("nextCoreTime", nextCoreTime);
        NBTTagList list = new NBTTagList();
        for (BlockPos pos : cores) {
            list.appendTag(NBTUtil.createPosTag(pos));
        }
        nbt.setTag("cores", list);
        return nbt;
    }
}

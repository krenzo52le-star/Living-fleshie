package com.livingflesh.world;

import com.livingflesh.ModItems;
import com.livingflesh.entity.EntityArachneidef;
import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.entity.EntityPermadus;
import com.livingflesh.entity.InfectedMob;
import com.livingflesh.entity.InfectionHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Особенность «Меча инфекции»: +50% урона по заражённым существам. */
public class InfectionSwordEvents {
    public static final float BONUS = 1.5F;

    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        DamageSource source = event.getSource();
        if (!(source.getTrueSource() instanceof EntityPlayer) || source.isProjectile() || source.isExplosion()) {
            return;
        }
        EntityPlayer player = (EntityPlayer) source.getTrueSource();
        if (player.getHeldItemMainhand().getItem() != ModItems.INFECTION_SWORD) {
            return;
        }
        if (isInfected(event.getEntityLiving())) {
            event.setAmount(event.getAmount() * BONUS);
        }
    }

    public static boolean isInfected(EntityLivingBase e) {
        return e instanceof InfectedMob || e instanceof EntityFleshPiece || e instanceof EntityPermadus
                || e instanceof EntityArachneidef || InfectionHelper.stageOf(e) > 0;
    }
}

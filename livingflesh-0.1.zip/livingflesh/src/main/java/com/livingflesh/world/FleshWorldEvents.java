package com.livingflesh.world;

import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.entity.InfectionHelper;
import com.livingflesh.stage.FleshStage;
import com.livingflesh.stage.StageManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

public class FleshWorldEvents {
    /** Метка: этому мобу уже бросали кость заражения при появлении, второй раз не бросаем. */
    private static final String TAG_ROLLED = "lf_rolled";

    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != Side.SERVER) {
            return;
        }
        if (event.world.provider.getDimension() != 0) {
            return; // пока только Верхний мир
        }
        WorldServer world = (WorldServer) event.world;
        long time = world.getTotalWorldTime();
        FleshWorldData data = FleshWorldData.get(world);

        if (time % 20L == 0L && !data.isManual()) {
            StageManager.updateByTime(world, data, false);
        }

        FleshStage stage = data.getStage();
        if (stage == FleshStage.DORMANT) {
            return;
        }
        if (time % 20L == 0L) {
            FleshSpreader.ensureCore(world, data);
        }
        if (stage.spreadInterval > 0 && time % stage.spreadInterval == 0L) {
            for (BlockPos core : data.getCores()) {
                FleshSpreader.spreadStep(world, core, stage);
            }
        }
        if (stage.wildPieceInterval > 0 && time % stage.wildPieceInterval == 0L
                && world.rand.nextFloat() < stage.wildPieceChance) {
            FleshSpreader.spawnWildPiece(world);
        }
        if (stage.karatelInterval > 0 && time % stage.karatelInterval == 0L
                && world.rand.nextFloat() < stage.karatelChance) {
            FleshSpreader.spawnKaratel(world);
        }
        if (stage.pieceInterval > 0 && time % stage.pieceInterval == 0L) {
            for (BlockPos core : data.getCores()) {
                FleshSpreader.spawnPiece(world, core, stage);
            }
        }
    }

    @SubscribeEvent
    public void onEntityJoin(EntityJoinWorldEvent event) {
        Entity entity = event.getEntity();
        if (entity.world.isRemote || !(entity instanceof EntityLiving) || entity instanceof EntityFleshPiece) {
            return;
        }
        EntityLiving living = (EntityLiving) entity;

        // уже заражённый моб загрузился из сохранения: вернуть ему бонусы (и подтянуть до стадии мира)
        if (InfectionHelper.stageOf(living) > 0) {
            upgradeToWorldStage(living);
            InfectionHelper.refresh(living);
            return;
        }
        // заражённое существо, призванное яйцом или командой, получает стадию мира (минимум 1)
        if (living instanceof com.livingflesh.entity.InfectedMob) {
            int id = Math.max(1, FleshWorldData.get(entity.world).getStage().id);
            InfectionHelper.infect(living, id, false);
            return;
        }

        if (entity.world.provider.getDimension() != 0 || entity.getTags().contains(TAG_ROLLED)) {
            return;
        }
        FleshStage stage = FleshWorldData.get(entity.world).getStage();
        if (stage.worldInfectChance <= 0.0F) {
            return;
        }
        entity.addTag(TAG_ROLLED);
        if (!(entity instanceof EntityMob || entity instanceof EntityAnimal)) {
            return;
        }
        if (entity.world.rand.nextFloat() < stage.worldInfectChance) {
            EntityLivingBase infected = InfectionHelper.infect(living, stage.id, false);
            if (infected != null && infected != living) {
                // вместо обычного моба уже создан заражённый, исходный в мир не добавляем
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        EntityLivingBase entity = event.getEntityLiving();
        if (entity.world.isRemote || entity.ticksExisted % 10 != 0) {
            return;
        }
        InfectionHelper.tickParticles(entity);
        // раз в 10 секунд проверяем, не наступила ли стадия посильнее: тогда заражённый крепнет прямо в мире
        if (entity.ticksExisted % 200 == 0 && entity instanceof EntityLiving) {
            upgradeToWorldStage((EntityLiving) entity);
        }
    }

    /** Заражённый моб, который заражён более ранней стадией, получает бонусы текущей стадии мира. */
    private static void upgradeToWorldStage(EntityLiving living) {
        int own = InfectionHelper.stageOf(living);
        if (own <= 0 || living.world.provider.getDimension() != 0) {
            return;
        }
        int world = FleshWorldData.get(living.world).getStage().id;
        if (world > own) {
            InfectionHelper.infect(living, world, false);
        }
    }
}

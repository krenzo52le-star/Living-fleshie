package com.livingflesh.world;

import com.livingflesh.ModItems;
import com.livingflesh.entity.InfectionHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** С заражённых мобов с шансом 30% выпадает «Мёртвая плоть», а с заражённого зомби с шансом 45% «Кость из плоти» (плоть с него не падает). */
public class FleshDrops {
    public static final float DROP_CHANCE = 0.30F;
    public static final float ZOMBIE_BONE_CHANCE = 0.45F;
    public static final float KARATEL_CORE_CHANCE = 0.17F;

    @SubscribeEvent
    public void onDrops(LivingDropsEvent event) {
        EntityLivingBase entity = event.getEntityLiving();
        if (!entity.world.isRemote && entity instanceof com.livingflesh.entity.EntityPermadus
                && entity.world.rand.nextFloat() < KARATEL_CORE_CHANCE) {
            event.getDrops().add(new EntityItem(entity.world, entity.posX, entity.posY + 1.0D, entity.posZ,
                    new ItemStack(ModItems.PERMADUS_CORE)));
        }
        if (entity.world.isRemote || entity instanceof EntityPlayer || InfectionHelper.stageOf(entity) <= 0) {
            return;
        }
        boolean zombie = entity instanceof com.livingflesh.entity.EntityInfectedZombie;
        float chance = zombie ? ZOMBIE_BONE_CHANCE : DROP_CHANCE;
        if (entity.world.rand.nextFloat() < chance) {
            event.getDrops().add(new EntityItem(entity.world, entity.posX, entity.posY, entity.posZ,
                    new ItemStack(zombie ? ModItems.FLESH_BONE : ModItems.DEAD_FLESH)));
        }
    }
}

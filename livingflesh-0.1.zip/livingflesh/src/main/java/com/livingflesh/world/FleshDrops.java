package com.livingflesh.world;

import com.livingflesh.ModItems;
import com.livingflesh.entity.InfectionHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** С заражённых мобов с шансом 30% выпадает «Мёртвая плоть». */
public class FleshDrops {
    public static final float DROP_CHANCE = 0.30F;

    @SubscribeEvent
    public void onDrops(LivingDropsEvent event) {
        EntityLivingBase entity = event.getEntityLiving();
        if (entity.world.isRemote || entity instanceof EntityPlayer || InfectionHelper.stageOf(entity) <= 0) {
            return;
        }
        if (entity.world.rand.nextFloat() < DROP_CHANCE) {
            event.getDrops().add(new EntityItem(entity.world, entity.posX, entity.posY, entity.posZ,
                    new ItemStack(ModItems.DEAD_FLESH)));
        }
    }
}

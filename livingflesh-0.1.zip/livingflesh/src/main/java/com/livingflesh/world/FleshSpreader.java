package com.livingflesh.world;

import com.livingflesh.ModBlocks;
import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.stage.FleshStage;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldServer;

import java.util.List;
import java.util.Random;

/** Вся логика появления ядра, разрастания плоти и спавна кусков плоти. */
public final class FleshSpreader {
    private static final int MAX_WALK_STEPS = 300;
    /** Через сколько тиков после гибели ядра появится новое (24000 = один игровой день). */
    private static final long CORE_RESPAWN_DELAY = 24000L;

    private FleshSpreader() {
    }

    // ---------------------------------------------------------------- ядро

    /** Проверяет ядра и, если их нет, создаёт новое примерно в 100 блоках от случайного игрока. */
    public static void ensureCore(WorldServer world, FleshWorldData data) {
        long now = world.getTotalWorldTime();

        boolean removedAny = false;
        for (BlockPos core : data.getCores()) {
            if (world.isBlockLoaded(core) && world.getBlockState(core).getBlock() != ModBlocks.FLESH_CORE) {
                data.removeCore(core);
                removedAny = true;
            }
        }
        if (removedAny && data.getCores().isEmpty()) {
            data.setNextCoreTime(now + CORE_RESPAWN_DELAY);
        }

        if (!data.getCores().isEmpty() || now < data.getNextCoreTime() || world.playerEntities.isEmpty()) {
            return;
        }
        EntityPlayer player = world.playerEntities.get(world.rand.nextInt(world.playerEntities.size()));
        BlockPos placed = placeCoreAround(world, data, player.getPosition(), 100);
        if (placed == null) {
            data.setNextCoreTime(now + 200L); // не нашли подходящее место, попробуем через 10 секунд
        }
    }

    /**
     * Ставит ядро на поверхности на расстоянии distance (плюс-минус 10) от центра.
     *
     * @return позиция ядра или null, если подходящее место не нашлось
     */
    public static BlockPos placeCoreAround(WorldServer world, FleshWorldData data, BlockPos center, int distance) {
        Random rand = world.rand;
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = rand.nextDouble() * Math.PI * 2.0D;
            double dist = distance + (rand.nextInt(21) - 10);
            int x = center.getX() + (int) Math.round(Math.cos(angle) * dist);
            int z = center.getZ() + (int) Math.round(Math.sin(angle) * dist);

            BlockPos top = world.getTopSolidOrLiquidBlock(new BlockPos(x, 64, z));
            BlockPos ground = top.down();
            if (!isInfectableGround(world.getBlockState(ground).getBlock())) {
                continue;
            }
            IBlockState above = world.getBlockState(top);
            if (above.getMaterial().isLiquid() || !(world.isAirBlock(top) || above.getBlock().isReplaceable(world, top))) {
                continue;
            }
            world.setBlockState(ground, ModBlocks.FLESH_BLOCK.getDefaultState(), 2);
            world.setBlockState(top, ModBlocks.FLESH_CORE.getDefaultState(), 2);
            data.addCore(top);
            return top;
        }
        return null;
    }

    // ------------------------------------------------------------- рост

    /**
     * Один шаг разрастания. Идём случайным блужданием от ядра по уже заражённой земле
     * и заражаем первую чистую клетку на краю. Так плоть всегда растёт цельным пятном.
     */
    public static void spreadStep(WorldServer world, BlockPos core, FleshStage stage) {
        if (!world.isBlockLoaded(core)) {
            return;
        }
        Random rand = world.rand;
        int maxRadiusSq = stage.maxRadius * stage.maxRadius;
        int x = core.getX();
        int z = core.getZ();

        for (int step = 0; step < MAX_WALK_STEPS; step++) {
            int oldDistSq = sq(x - core.getX()) + sq(z - core.getZ());
            EnumFacing facing = EnumFacing.getHorizontal(rand.nextInt(4));
            int nx = x + facing.getFrontOffsetX();
            int nz = z + facing.getFrontOffsetZ();
            int newDistSq = sq(nx - core.getX()) + sq(nz - core.getZ());
            // чаще идём наружу, чтобы пятно росло заметно быстрее
            if (newDistSq < oldDistSq && rand.nextInt(100) < 55) {
                nx = x - facing.getFrontOffsetX();
                nz = z - facing.getFrontOffsetZ();
                newDistSq = sq(nx - core.getX()) + sq(nz - core.getZ());
            }
            if (newDistSq > maxRadiusSq) {
                x = core.getX();
                z = core.getZ();
                continue;
            }
            x = nx;
            z = nz;

            BlockPos column = new BlockPos(x, 64, z);
            if (!world.isBlockLoaded(column)) {
                return;
            }
            BlockPos top = world.getTopSolidOrLiquidBlock(column);
            BlockPos ground = top.down();
            Block groundBlock = world.getBlockState(ground).getBlock();

            if (groundBlock == ModBlocks.FLESH_BLOCK || groundBlock == ModBlocks.FLESH_CORE) {
                continue; // уже плоть, идём дальше
            }
            if (!isInfectableGround(groundBlock)) {
                x = core.getX(); // упёрлись в воду, постройку и т.п., начинаем заново от ядра
                z = core.getZ();
                continue;
            }
            IBlockState above = world.getBlockState(top);
            if (!world.isAirBlock(top)) {
                if (above.getMaterial().isLiquid() || !above.getBlock().isReplaceable(world, top)) {
                    continue;
                }
                world.setBlockToAir(top); // трава, цветы, снежный слой
            }
            world.setBlockState(ground, ModBlocks.FLESH_BLOCK.getDefaultState(), 2);
            return;
        }
    }

    // ---------------------------------------------------------- куски плоти

    public static void spawnPiece(WorldServer world, BlockPos core, FleshStage stage) {
        if (!world.isBlockLoaded(core) || !playerNear(world, core, 96.0D)) {
            return;
        }
        AxisAlignedBB area = new AxisAlignedBB(core).grow(24.0D);
        if (world.getEntitiesWithinAABB(EntityFleshPiece.class, area).size() >= stage.pieceCap) {
            return;
        }
        Random rand = world.rand;
        for (int attempt = 0; attempt < 6; attempt++) {
            int x = core.getX() + rand.nextInt(13) - 6;
            int z = core.getZ() + rand.nextInt(13) - 6;
            BlockPos top = world.getTopSolidOrLiquidBlock(new BlockPos(x, 64, z));
            if (world.getBlockState(top.down()).getBlock() == ModBlocks.FLESH_BLOCK && world.isAirBlock(top)) {
                EntityFleshPiece piece = new EntityFleshPiece(world);
                piece.setLocationAndAngles(x + 0.5D, top.getY(), z + 0.5D, rand.nextFloat() * 360.0F, 0.0F);
                world.spawnEntity(piece);
                return;
            }
        }
    }

    // ------------------------------------------------------------- помощники

    private static boolean playerNear(WorldServer world, BlockPos pos, double range) {
        List<EntityPlayer> players = world.playerEntities;
        for (EntityPlayer player : players) {
            if (player.getDistanceSq(pos) <= range * range) {
                return true;
            }
        }
        return false;
    }

    /** Плоть заменяет только природную землю, чтобы не съедать постройки игрока. */
    private static boolean isInfectableGround(Block block) {
        return block == Blocks.GRASS
                || block == Blocks.DIRT
                || block == Blocks.SAND
                || block == Blocks.GRAVEL
                || block == Blocks.STONE
                || block == Blocks.SANDSTONE
                || block == Blocks.RED_SANDSTONE
                || block == Blocks.CLAY
                || block == Blocks.MYCELIUM
                || block == Blocks.HARDENED_CLAY
                || block == Blocks.STAINED_HARDENED_CLAY;
    }

    private static int sq(int v) {
        return v * v;
    }
}

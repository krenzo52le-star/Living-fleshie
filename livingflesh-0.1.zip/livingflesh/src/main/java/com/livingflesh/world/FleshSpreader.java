package com.livingflesh.world;

import com.livingflesh.ModBlocks;
import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.stage.FleshStage;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockRotatedPillar;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldServer;

import java.util.List;
import java.util.Random;

/** Вся логика появления ядра, разрастания плоти и спавна кусков плоти. */
public final class FleshSpreader {
    private static final int MAX_WALK_STEPS = 300;

    private FleshSpreader() {
    }

    // ---------------------------------------------------------------- ядро

    /** Проверяет ядра и, если их нет, создаёт новое примерно в 100 блоках от случайного игрока. */
    public static void ensureCore(WorldServer world, FleshWorldData data) {
        long now = world.getTotalWorldTime();

        boolean removedAny = false;
        for (BlockPos core : data.getCores()) {
            if (world.isBlockLoaded(core) && world.getBlockState(core).getBlock() != ModBlocks.FLESH_CORE) {
                data.removeCore(core);
                removedAny = true;
            }
        }
        if (removedAny && data.getCores().isEmpty()) {
            data.setNextCoreTime(now + data.getStage().coreRespawnDelay);
        }

        if (!data.getCores().isEmpty() || now < data.getNextCoreTime() || world.playerEntities.isEmpty()) {
            return;
        }
        EntityPlayer player = world.playerEntities.get(world.rand.nextInt(world.playerEntities.size()));
        BlockPos placed = placeCoreAround(world, data, player.getPosition(), 100);
        if (placed == null) {
            data.setNextCoreTime(now + 200L); // не нашли подходящее место, попробуем через 10 секунд
        }
    }

    /**
     * Ставит ядро на расстоянии distance (плюс-минус 10) от центра: либо на поверхности, либо под землёй
     * (в пещере на полу, а если пещеры не нашлось, то внутри породы). В воздухе ядро не появляется.
     *
     * @return позиция ядра или null, если подходящее место не нашлось
     */
    public static BlockPos placeCoreAround(WorldServer world, FleshWorldData data, BlockPos center, int distance) {
        Random rand = world.rand;
        BlockPos embedded = null; // запасной вариант: ядро внутри породы
        for (int attempt = 0; attempt < 60; attempt++) {
            double angle = rand.nextDouble() * Math.PI * 2.0D;
            double dist = distance + (rand.nextInt(21) - 10);

            if (rand.nextBoolean()) {
                // поверхность
                int x = center.getX() + (int) Math.round(Math.cos(angle) * dist);
                int z = center.getZ() + (int) Math.round(Math.sin(angle) * dist);
                BlockPos top = world.getTopSolidOrLiquidBlock(new BlockPos(x, 64, z));
                BlockPos ground = top.down();
                if (!isInfectableGround(world.getBlockState(ground).getBlock())) {
                    continue;
                }
                IBlockState above = world.getBlockState(top);
                if (above.getMaterial().isLiquid() || !(world.isAirBlock(top) || above.getBlock().isReplaceable(world, top))) {
                    continue;
                }
                world.setBlockState(ground, ModBlocks.FLESH_BLOCK.getDefaultState(), 2);
                world.setBlockState(top, ModBlocks.FLESH_CORE.getDefaultState(), 2);
                data.addCore(top);
                return top;
            }

            // под землёй: точка в шаре радиусом dist вокруг центра
            int dy = rand.nextInt(81) - 40;
            double horiz2 = dist * dist - (double) dy * dy;
            if (horiz2 < dist * dist * 0.25D) {
                continue;
            }
            double horiz = Math.sqrt(horiz2);
            int x = center.getX() + (int) Math.round(Math.cos(angle) * horiz);
            int z = center.getZ() + (int) Math.round(Math.sin(angle) * horiz);
            int y = Math.max(6, center.getY() + dy);
            int surface = world.getTopSolidOrLiquidBlock(new BlockPos(x, 64, z)).getY();
            if (y > surface - 6) {
                continue; // слишком близко к поверхности, это уже не «под землёй»
            }
            BlockPos pos = new BlockPos(x, y, z);
            IBlockState state = world.getBlockState(pos);
            Block block = state.getBlock();
            if (world.isAirBlock(pos)) {
                // пещера: ядро ставим на пол, воздуха над ним должно быть достаточно
                BlockPos floor = pos.down();
                if (isInfectableGround(world.getBlockState(floor).getBlock())
                        && world.getBlockState(floor).getBlock() != Blocks.GRASS
                        && world.isAirBlock(pos.up())) {
                    world.setBlockState(floor, ModBlocks.FLESH_BLOCK.getDefaultState(), 2);
                    world.setBlockState(pos, ModBlocks.FLESH_CORE.getDefaultState(), 2);
                    data.addCore(pos);
                    return pos;
                }
            } else if (embedded == null && isInfectableGround(block) && block != Blocks.GRASS
                    && !state.getMaterial().isLiquid()) {
                embedded = pos;
            }
        }
        if (embedded != null) {
            world.setBlockState(embedded, ModBlocks.FLESH_CORE.getDefaultState(), 2);
            data.addCore(embedded);
            return embedded;
        }
        return null;
    }

    /** Ядро под землёй: над ним нет открытой поверхности ближе чем в нескольких блоках. */
    private static boolean isUnderground(WorldServer world, BlockPos core) {
        return world.getTopSolidOrLiquidBlock(core).getY() - core.getY() > 3;
    }

    // ------------------------------------------------------------- рост

    /**
     * Один шаг разрастания. Идём случайным блужданием от ядра по уже заражённой земле
     * и заражаем первую чистую клетку на краю. Так плоть всегда растёт цельным пятном.
     */
    public static void spreadStep(WorldServer world, BlockPos core, FleshStage stage) {
        if (!world.isBlockLoaded(core)) {
            return;
        }
        if (isUnderground(world, core)) {
            spreadUnderground(world, core, stage);
            return;
        }
        Random rand = world.rand;
        int maxRadiusSq = stage.maxRadius * stage.maxRadius;
        int x = core.getX();
        int z = core.getZ();

        for (int step = 0; step < MAX_WALK_STEPS; step++) {
            int oldDistSq = sq(x - core.getX()) + sq(z - core.getZ());
            int dir = rand.nextInt(4);
            int nx = x + (dir == 2 ? 1 : dir == 3 ? -1 : 0);
            int nz = z + (dir == 0 ? 1 : dir == 1 ? -1 : 0);
            int newDistSq = sq(nx - core.getX()) + sq(nz - core.getZ());
            // чаще идём наружу, чтобы пятно росло заметно быстрее
            if (newDistSq < oldDistSq && rand.nextInt(100) < 55) {
                nx = x - (dir == 2 ? 1 : dir == 3 ? -1 : 0);
                nz = z - (dir == 0 ? 1 : dir == 1 ? -1 : 0);
                newDistSq = sq(nx - core.getX()) + sq(nz - core.getZ());
            }
            if (newDistSq > maxRadiusSq) {
                x = core.getX();
                z = core.getZ();
                continue;
            }
            x = nx;
            z = nz;

            BlockPos column = new BlockPos(x, 64, z);
            if (!world.isBlockLoaded(column)) {
                return;
            }
            BlockPos top = world.getTopSolidOrLiquidBlock(column);
            BlockPos ground = top.down();
            Block groundBlock = world.getBlockState(ground).getBlock();

            if (groundBlock == ModBlocks.FLESH_BLOCK || groundBlock == ModBlocks.FLESH_CORE) {
                if (groundBlock == ModBlocks.FLESH_BLOCK) {
                    tryGrowStalk(world, top);
                }
                infectNature(world, top);
                continue; // уже плоть, идём дальше
            }
            boolean infectedGrass = groundBlock == ModBlocks.INFECTED_GRASS || groundBlock == ModBlocks.INFECTED_STONE;
            if (infectedGrass && rand.nextInt(100) >= 30) {
                infectNature(world, top);
                continue; // заражённая трава пока остаётся травой, в плоть она превращается не сразу
            }
            if (!infectedGrass && !isInfectableGround(groundBlock)) {
                x = core.getX(); // упёрлись в воду, постройку и т.п., начинаем заново от ядра
                z = core.getZ();
                continue;
            }
            IBlockState above = world.getBlockState(top);
            if (!world.isAirBlock(top)) {
                if (above.getMaterial().isLiquid() || !above.getBlock().isReplaceable(world, top)) {
                    continue;
                }
                world.setBlockToAir(top); // трава, цветы, снежный слой
            }
            // обычная трава и камень сначала становятся заражёнными, остальная земля сразу плотью
            world.setBlockState(ground, infectedFormOf(groundBlock, rand), 2);
            return;
        }
    }

    /**
     * Разрастание подземного ядра: случайное блуждание в трёх измерениях по заражённым блокам и по воздуху пещер.
     * Первая чистая природная порода на пути превращается в плоть.
     */
    private static void spreadUnderground(WorldServer world, BlockPos core, FleshStage stage) {
        Random rand = world.rand;
        double maxSq = (double) stage.maxRadius * stage.maxRadius;
        BlockPos cur = core;
        for (int step = 0; step < MAX_WALK_STEPS; step++) {
            EnumFacing dir = EnumFacing.values()[rand.nextInt(6)];
            BlockPos next = cur.offset(dir);
            // чаще идём наружу, чтобы пятно росло заметно
            if (distSq(next, core) < distSq(cur, core) && rand.nextInt(100) < 55) {
                next = cur.offset(dir.getOpposite());
            }
            if (distSq(next, core) > maxSq) {
                cur = core;
                continue;
            }
            if (!world.isBlockLoaded(next)) {
                return;
            }
            IBlockState state = world.getBlockState(next);
            Block block = state.getBlock();
            if (block == ModBlocks.FLESH_BLOCK || block == ModBlocks.FLESH_CORE) {
                if (block == ModBlocks.FLESH_BLOCK && world.isAirBlock(next.up())) {
                    tryGrowStalk(world, next.up());
                }
                if (block == ModBlocks.FLESH_BLOCK) {
                    tryGrowVine(world, next);
                }
                cur = next;
                continue;
            }
            if (block == ModBlocks.INFECTED_STONE) {
                if (rand.nextInt(100) < 30) {
                    world.setBlockState(next, ModBlocks.FLESH_BLOCK.getDefaultState(), 2); // заражённый камень дозревает до плоти
                    return;
                }
                tryGrowVine(world, next);
                cur = next;
                continue;
            }
            if (isInfectableGround(block) && !state.getMaterial().isLiquid()) {
                world.setBlockState(next, infectedFormOf(block, rand), 2);
                return;
            }
            if (world.isAirBlock(next)) {
                cur = next; // идём по пещере и заражаем её стены, пол и потолок
                EnumFacing wall = EnumFacing.values()[rand.nextInt(6)];
                BlockPos target = next.offset(wall);
                if (world.isBlockLoaded(target) && isInfectableGround(world.getBlockState(target).getBlock())) {
                    world.setBlockState(target, infectedFormOf(world.getBlockState(target).getBlock(), rand), 2);
                    return;
                }
                continue;
            }
            cur = core; // руда, вода, постройка и т.п.: начинаем заново от ядра
        }
    }

    /** Во что превращается природный блок при заражении: трава и камень проходят промежуточную стадию. */
    private static IBlockState infectedFormOf(Block block, Random rand) {
        if (block == Blocks.GRASS) {
            return ModBlocks.INFECTED_GRASS.getDefaultState();
        }
        if (block == Blocks.STONE) {
            return ((com.livingflesh.block.BlockInfectedStone) ModBlocks.INFECTED_STONE).randomState(rand);
        }
        return ModBlocks.FLESH_BLOCK.getDefaultState();
    }

    /** Свисающая плоть высотой 2-3 блока под заражённым камнем, листвой или плотью. */
    private static void tryGrowVine(WorldServer world, BlockPos anchor) {
        Random rand = world.rand;
        BlockPos base = anchor.down();
        if (rand.nextInt(6) != 0 || !world.isAirBlock(base)) {
            return;
        }
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (world.getBlockState(base.add(dx, 0, dz)).getBlock() == ModBlocks.FLESH_VINE) {
                    return;
                }
            }
        }
        int wanted = 2 + rand.nextInt(2); // 2..3
        int height = 0;
        while (height < wanted && world.isAirBlock(base.down(height))) {
            height++;
        }
        if (height < 2) {
            return;
        }
        for (int i = 0; i < height; i++) {
            world.setBlockState(base.down(i), ModBlocks.FLESH_VINE.getDefaultState(), 2);
        }
    }

    private static double distSq(BlockPos a, BlockPos b) {
        double dx = a.getX() - b.getX();
        double dy = a.getY() - b.getY();
        double dz = a.getZ() - b.getZ();
        return dx * dx + dy * dy + dz * dz;
    }

    /**
     * Заражает деревья рядом: бревно или листва, которые касаются уже заражённого блока, становятся заражёнными.
     * Дерево заражается постепенно, снизу вверх от заражённой земли.
     */
    private static void infectNature(WorldServer world, BlockPos center) {
        Random rand = world.rand;
        int done = 0;
        for (int i = 0; i < 12 && done < 3; i++) {
            BlockPos pos = center.add(rand.nextInt(9) - 4, rand.nextInt(14) - 1, rand.nextInt(9) - 4);
            if (!world.isBlockLoaded(pos)) {
                continue;
            }
            IBlockState state = world.getBlockState(pos);
            Block block = state.getBlock();
            if (block == ModBlocks.INFECTED_LEAVES || block == ModBlocks.INFECTED_STONE) {
                tryGrowVine(world, pos);
                continue;
            }
            boolean log = block instanceof BlockLog;
            if (!log && !(block instanceof BlockLeaves)) {
                continue;
            }
            if (!touchesInfection(world, pos)) {
                continue;
            }
            if (log) {
                world.setBlockState(pos, infectedLogFrom(state), 2);
            } else {
                world.setBlockState(pos, ModBlocks.INFECTED_LEAVES.getDefaultState(), 2);
            }
            done++;
        }
    }

    private static IBlockState infectedLogFrom(IBlockState old) {
        EnumFacing.Axis axis = EnumFacing.Axis.Y;
        if (old.getPropertyKeys().contains(BlockLog.LOG_AXIS)) {
            BlockLog.EnumAxis a = old.getValue(BlockLog.LOG_AXIS);
            if (a == BlockLog.EnumAxis.X) {
                axis = EnumFacing.Axis.X;
            } else if (a == BlockLog.EnumAxis.Z) {
                axis = EnumFacing.Axis.Z;
            }
        }
        return ModBlocks.INFECTED_LOG.getDefaultState().withProperty(BlockRotatedPillar.AXIS, axis);
    }

    private static boolean touchesInfection(WorldServer world, BlockPos pos) {
        for (EnumFacing face : EnumFacing.values()) {
            Block b = world.getBlockState(pos.offset(face)).getBlock();
            if (b == ModBlocks.FLESH_BLOCK || b == ModBlocks.INFECTED_GRASS
                    || b == ModBlocks.INFECTED_LOG || b == ModBlocks.INFECTED_LEAVES || b == ModBlocks.INFECTED_STONE) {
                return true;
            }
        }
        return false;
    }

    /** Редко вырастает мясное растение высотой 2-5 блоков на живой плоти; рядом уже есть растение - не растёт. */
    private static void tryGrowStalk(WorldServer world, BlockPos base) {
        Random rand = world.rand;
        if (rand.nextInt(60) != 0 || !world.isAirBlock(base)) {
            return;
        }
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                if (world.getBlockState(base.add(dx, 0, dz)).getBlock() == ModBlocks.FLESH_STALK) {
                    return;
                }
            }
        }
        int wanted = 2 + rand.nextInt(4); // 2..5
        int height = 0;
        while (height < wanted && world.isAirBlock(base.up(height))) {
            height++;
        }
        if (height < 2) {
            return; // упёрлись в потолок, растение не вырастет
        }
        for (int i = 0; i < height; i++) {
            world.setBlockState(base.up(i), ModBlocks.FLESH_STALK.getDefaultState(), 2);
        }
    }

    // ---------------------------------------------------------- куски плоти

    public static void spawnPiece(WorldServer world, BlockPos core, FleshStage stage) {
        if (!world.isBlockLoaded(core) || !playerNear(world, core, 96.0D)) {
            return;
        }
        AxisAlignedBB area = new AxisAlignedBB(core).grow(24.0D);
        if (world.getEntitiesWithinAABB(EntityFleshPiece.class, area).size() >= stage.pieceCap) {
            return;
        }
        Random rand = world.rand;
        if (isUnderground(world, core)) {
            for (int attempt = 0; attempt < 10; attempt++) {
                BlockPos pos = core.add(rand.nextInt(13) - 6, rand.nextInt(7) - 3, rand.nextInt(13) - 6);
                if (world.isBlockLoaded(pos) && world.isAirBlock(pos) && world.isAirBlock(pos.up())
                        && world.getBlockState(pos.down()).getBlock() == ModBlocks.FLESH_BLOCK) {
                    EntityFleshPiece piece = new EntityFleshPiece(world);
                    piece.setLocationAndAngles(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, rand.nextFloat() * 360.0F, 0.0F);
                    world.spawnEntity(piece);
                    return;
                }
            }
            return;
        }
        for (int attempt = 0; attempt < 6; attempt++) {
            int x = core.getX() + rand.nextInt(13) - 6;
            int z = core.getZ() + rand.nextInt(13) - 6;
            BlockPos top = world.getTopSolidOrLiquidBlock(new BlockPos(x, 64, z));
            if (world.getBlockState(top.down()).getBlock() == ModBlocks.FLESH_BLOCK && world.isAirBlock(top)) {
                EntityFleshPiece piece = new EntityFleshPiece(world);
                piece.setLocationAndAngles(x + 0.5D, top.getY(), z + 0.5D, rand.nextFloat() * 360.0F, 0.0F);
                world.spawnEntity(piece);
                return;
            }
        }
    }

    /**
     * Очень редкий кусок плоти вдали от очага: появляется на поверхности в 24-48 блоках от случайного игрока,
     * вне заражённой земли. Больше одного рядом не бывает.
     */
    public static void spawnWildPiece(WorldServer world) {
        if (world.playerEntities.isEmpty()) {
            return;
        }
        Random rand = world.rand;
        EntityPlayer player = world.playerEntities.get(rand.nextInt(world.playerEntities.size()));
        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = rand.nextDouble() * Math.PI * 2.0D;
            double dist = 24 + rand.nextInt(25);
            int x = player.getPosition().getX() + (int) Math.round(Math.cos(angle) * dist);
            int z = player.getPosition().getZ() + (int) Math.round(Math.sin(angle) * dist);
            if (!world.isBlockLoaded(new BlockPos(x, 64, z))) {
                continue;
            }
            BlockPos top = world.getTopSolidOrLiquidBlock(new BlockPos(x, 64, z));
            BlockPos ground = top.down();
            Block groundBlock = world.getBlockState(ground).getBlock();
            if (!world.isAirBlock(top) || world.getBlockState(ground).getMaterial().isLiquid()
                    || groundBlock == ModBlocks.FLESH_BLOCK || groundBlock == ModBlocks.INFECTED_GRASS
                    || groundBlock == ModBlocks.INFECTED_STONE || !world.getBlockState(ground).isFullBlock()) {
                continue;
            }
            if (!world.getEntitiesWithinAABB(EntityFleshPiece.class, new AxisAlignedBB(top).grow(16.0D)).isEmpty()) {
                return;
            }
            EntityFleshPiece piece = new EntityFleshPiece(world);
            piece.setLocationAndAngles(x + 0.5D, top.getY(), z + 0.5D, rand.nextFloat() * 360.0F, 0.0F);
            world.spawnEntity(piece);
            return;
        }
    }

    /** Редко призывает Карателя на поверхности неподалёку от игрока (не больше двух на мир). */
    public static void spawnKaratel(WorldServer world) {
        spawnPermadus(world, false);
    }

    /** Редко призывает Арахнейдефа (не больше одного на мир). */
    public static void spawnArachneidef(WorldServer world) {
        spawnPermadus(world, true);
    }

    private static void spawnPermadus(WorldServer world, boolean arachneidef) {
        if (world.playerEntities.isEmpty()) {
            return;
        }
        int existing = 0;
        for (net.minecraft.entity.Entity e : world.loadedEntityList) {
            if (arachneidef ? e instanceof com.livingflesh.entity.EntityArachneidef : e instanceof com.livingflesh.entity.EntityPermadus) {
                existing++;
            }
        }
        if (existing >= (arachneidef ? 1 : 2)) {
            return;
        }
        Random rand = world.rand;
        EntityPlayer player = world.playerEntities.get(rand.nextInt(world.playerEntities.size()));
        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = rand.nextDouble() * Math.PI * 2.0D;
            double dist = 32 + rand.nextInt(25);
            int x = player.getPosition().getX() + (int) Math.round(Math.cos(angle) * dist);
            int z = player.getPosition().getZ() + (int) Math.round(Math.sin(angle) * dist);
            if (!world.isBlockLoaded(new BlockPos(x, 64, z))) {
                continue;
            }
            BlockPos top = world.getTopSolidOrLiquidBlock(new BlockPos(x, 64, z));
            if (world.getBlockState(top.down()).getMaterial().isLiquid() || !world.getBlockState(top.down()).isFullBlock()
                    || !world.isAirBlock(top) || !world.isAirBlock(top.up()) || !world.isAirBlock(top.up(2))) {
                continue;
            }
            net.minecraft.entity.EntityLiving karatel = arachneidef
                    ? new com.livingflesh.entity.EntityArachneidef(world) : new com.livingflesh.entity.EntityPermadus(world);
            karatel.setLocationAndAngles(x + 0.5D, top.getY(), z + 0.5D, rand.nextFloat() * 360.0F, 0.0F);
            world.spawnEntity(karatel);
            return;
        }
    }

    // ------------------------------------------------------------- помощники

    private static boolean playerNear(WorldServer world, BlockPos pos, double range) {
        List<EntityPlayer> players = world.playerEntities;
        for (EntityPlayer player : players) {
            if (player.getDistanceSq(pos) <= range * range) {
                return true;
            }
        }
        return false;
    }

    /** Плоть заменяет только природную землю, чтобы не съедать постройки игрока. */
    private static boolean isInfectableGround(Block block) {
        return block == Blocks.GRASS
                || block == Blocks.DIRT
                || block == Blocks.SAND
                || block == Blocks.GRAVEL
                || block == Blocks.STONE
                || block == Blocks.SANDSTONE
                || block == Blocks.RED_SANDSTONE
                || block == Blocks.CLAY
                || block == Blocks.MYCELIUM
                || block == Blocks.HARDENED_CLAY
                || block == Blocks.STAINED_HARDENED_CLAY;
    }

    private static int sq(int v) {
        return v * v;
    }
}

package com.livingflesh;

import com.livingflesh.entity.EntityFleshPiece;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID)
public class ModEntities {

    @SubscribeEvent
    public static void registerEntities(RegistryEvent.Register<EntityEntry> event) {
        event.getRegistry().register(
                EntityEntryBuilder.create()
                        .entity(EntityFleshPiece.class)
                        .id(new ResourceLocation(LivingFleshMod.MODID, "flesh_piece"), 0)
                        .name(LivingFleshMod.MODID + ".flesh_piece")
                        .tracker(64, 3, true)
                        .egg(0x7A1F1F, 0xD9626B)
                        .build());
    }
}

package com.livingflesh;

import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.entity.EntityInfectedChicken;
import com.livingflesh.entity.EntityInfectedCow;
import com.livingflesh.entity.EntityInfectedPig;
import com.livingflesh.entity.EntityInfectedSheep;
import com.livingflesh.entity.EntityInfectedVillager;
import com.livingflesh.entity.EntityPermadus;
import com.livingflesh.entity.EntityInfectedZombie;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID)
public class ModEntities {

    @SubscribeEvent
    public static void registerEntities(RegistryEvent.Register<EntityEntry> event) {
        EntityEntry fleshPiece = EntityEntryBuilder.create()
                .entity(EntityFleshPiece.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "flesh_piece"), 0)
                .name(LivingFleshMod.MODID + ".flesh_piece")
                .tracker(64, 3, true)
                .build();

        EntityEntry infectedCow = EntityEntryBuilder.create()
                .entity(EntityInfectedCow.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "infected_cow"), 1)
                .name(LivingFleshMod.MODID + ".infected_cow")
                .tracker(64, 3, true)
                .build();

        EntityEntry infectedPig = EntityEntryBuilder.create()
                .entity(EntityInfectedPig.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "infected_pig"), 2)
                .name(LivingFleshMod.MODID + ".infected_pig")
                .tracker(64, 3, true)
                .build();

        EntityEntry infectedZombie = EntityEntryBuilder.create()
                .entity(EntityInfectedZombie.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "infected_zombie"), 3)
                .name(LivingFleshMod.MODID + ".infected_zombie")
                .tracker(64, 3, true)
                .build();

        EntityEntry infectedSheep = EntityEntryBuilder.create()
                .entity(EntityInfectedSheep.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "infected_sheep"), 4)
                .name(LivingFleshMod.MODID + ".infected_sheep")
                .tracker(64, 3, true)
                .build();

        EntityEntry infectedChicken = EntityEntryBuilder.create()
                .entity(EntityInfectedChicken.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "infected_chicken"), 5)
                .name(LivingFleshMod.MODID + ".infected_chicken")
                .tracker(64, 3, true)
                .build();

        EntityEntry infectedVillager = EntityEntryBuilder.create()
                .entity(EntityInfectedVillager.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "infected_villager"), 6)
                .name(LivingFleshMod.MODID + ".infected_villager")
                .tracker(64, 3, true)
                .build();

        EntityEntry permadus = EntityEntryBuilder.create()
                .entity(EntityPermadus.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "permadus"), 7)
                .name(LivingFleshMod.MODID + ".permadus")
                .tracker(80, 3, true)
                .build();

        event.getRegistry().registerAll(fleshPiece, infectedCow, infectedPig, infectedZombie, infectedSheep, infectedChicken, infectedVillager, permadus);
    }
}

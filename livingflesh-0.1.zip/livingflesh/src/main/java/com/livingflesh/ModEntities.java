package com.livingflesh;

import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.entity.EntityInfectedCow;
import com.livingflesh.entity.EntityInfectedPig;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID)
public class ModEntities {

    @SubscribeEvent
    public static void registerEntities(RegistryEvent.Register<EntityEntry> event) {
        EntityEntry fleshPiece = EntityEntryBuilder.create()
                .entity(EntityFleshPiece.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "flesh_piece"), 0)
                .name(LivingFleshMod.MODID + ".flesh_piece")
                .tracker(64, 3, true)
                .egg(0x7A1F1F, 0xD9626B)
                .build();

        EntityEntry infectedCow = EntityEntryBuilder.create()
                .entity(EntityInfectedCow.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "infected_cow"), 1)
                .name(LivingFleshMod.MODID + ".infected_cow")
                .tracker(64, 3, true)
                .build();

        EntityEntry infectedPig = EntityEntryBuilder.create()
                .entity(EntityInfectedPig.class)
                .id(new ResourceLocation(LivingFleshMod.MODID, "infected_pig"), 2)
                .name(LivingFleshMod.MODID + ".infected_pig")
                .tracker(64, 3, true)
                .build();

        event.getRegistry().registerAll(fleshPiece, infectedCow, infectedPig);
    }
}

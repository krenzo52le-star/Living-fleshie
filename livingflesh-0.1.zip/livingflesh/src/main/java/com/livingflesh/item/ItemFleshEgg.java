package com.livingflesh.item;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.util.Names;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Своё яйцо призыва: название не зависит от lang-файла. */
public class ItemFleshEgg extends Item {
    private final ResourceLocation entityId;
    private final String itemName;
    private final String fallback;

    public ItemFleshEgg(String itemName, String entityName, String fallback) {
        this.itemName = itemName;
        this.entityId = new ResourceLocation(LivingFleshMod.MODID, entityName);
        this.fallback = fallback;
        setRegistryName(LivingFleshMod.MODID, itemName);
        setTranslationKey(LivingFleshMod.MODID + "." + itemName);
        setCreativeTab(CreativeTabs.MISC);
    }

    @Override
    public String getItemStackDisplayName(ItemStack stack) {
        return Names.tr("item." + LivingFleshMod.MODID + "." + itemName + ".name", fallback);
    }

    @Override
    public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos pos, EnumHand hand,
                                      EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (world.isRemote) {
            return EnumActionResult.SUCCESS;
        }
        ItemStack stack = player.getHeldItem(hand);
        BlockPos spawn = pos.offset(facing);
        if (!player.canPlayerEdit(spawn, facing, stack)) {
            return EnumActionResult.FAIL;
        }
        Entity entity = EntityList.createEntityByIDFromName(entityId, world);
        if (entity == null) {
            return EnumActionResult.FAIL;
        }
        entity.setLocationAndAngles(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D,
                world.rand.nextFloat() * 360.0F, 0.0F);
        if (entity instanceof EntityLiving) {
            EntityLiving living = (EntityLiving) entity;
            living.rotationYawHead = living.rotationYaw;
            living.renderYawOffset = living.rotationYaw;
            living.onInitialSpawn(world.getDifficultyForLocation(spawn), null);
        }
        world.spawnEntity(entity);
        if (!player.capabilities.isCreativeMode) {
            stack.shrink(1);
        }
        return EnumActionResult.SUCCESS;
    }
}

package com.livingflesh.item;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.client.gui.BookOpener;
import com.livingflesh.util.Names;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

/** Энциклопедия плоти: по ПКМ открывает книгу со справкой о стадиях, заражённых и механиках. */
public class ItemEncyclopedia extends Item {
    public ItemEncyclopedia() {
        setRegistryName(LivingFleshMod.MODID, "encyclopedia");
        setTranslationKey(LivingFleshMod.MODID + ".encyclopedia");
        setCreativeTab(com.livingflesh.ModTabs.TAB);
        setMaxStackSize(1);
    }

    @Override
    public String getItemStackDisplayName(ItemStack stack) {
        return Names.tr("item.livingflesh.encyclopedia.name", "Энциклопедия плоти");
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        if (world.isRemote) {
            BookOpener.open(); // клиентский код, на сервере не выполняется
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, player.getHeldItem(hand));
    }
}

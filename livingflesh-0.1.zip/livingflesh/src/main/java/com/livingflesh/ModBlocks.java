package com.livingflesh;

import com.livingflesh.block.BlockFlesh;
import com.livingflesh.block.BlockFleshCore;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import com.livingflesh.block.NamedItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID)
public class ModBlocks {
    public static final Block FLESH_BLOCK = new BlockFlesh();
    public static final Block FLESH_CORE = new BlockFleshCore();
    public static final Block FLESH_STALK = new com.livingflesh.block.BlockFleshStalk();
    public static final Block INFECTED_GRASS = new com.livingflesh.block.BlockInfectedGrass();
    public static final Block INFECTED_LOG = new com.livingflesh.block.BlockInfectedLog();
    public static final Block INFECTED_LEAVES = new com.livingflesh.block.BlockInfectedLeaves();
    public static final Block INFECTED_STONE = new com.livingflesh.block.BlockInfectedStone();
    public static final Block INFECTED_ORE = new com.livingflesh.block.BlockInfectedOre();
    public static final Block FLESH_VINE = new com.livingflesh.block.BlockFleshVine();

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(FLESH_BLOCK, FLESH_CORE, FLESH_STALK, INFECTED_GRASS, INFECTED_LOG, INFECTED_LEAVES, INFECTED_STONE, FLESH_VINE, INFECTED_ORE);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(itemFor(FLESH_BLOCK, "Живая плоть"), itemFor(FLESH_CORE, "Ядро плоти"), itemFor(FLESH_STALK, "Мясное растение"),
                itemFor(INFECTED_GRASS, "Заражённая трава"), itemFor(INFECTED_LOG, "Заражённое бревно"), itemFor(INFECTED_LEAVES, "Заражённая листва"),
                itemFor(INFECTED_STONE, "Заражённый камень"), itemFor(FLESH_VINE, "Свисающая плоть"), itemFor(INFECTED_ORE, "Заражённая руда"));
    }

    private static Item itemFor(Block block, String name) {
        return new NamedItemBlock(block, name).setRegistryName(block.getRegistryName());
    }
}

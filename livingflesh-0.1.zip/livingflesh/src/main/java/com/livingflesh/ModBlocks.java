package com.livingflesh;

import com.livingflesh.block.BlockFlesh;
import com.livingflesh.block.BlockFleshCore;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID)
public class ModBlocks {
    public static final Block FLESH_BLOCK = new BlockFlesh();
    public static final Block FLESH_CORE = new BlockFleshCore();

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(FLESH_BLOCK, FLESH_CORE);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(itemFor(FLESH_BLOCK), itemFor(FLESH_CORE));
    }

    private static Item itemFor(Block block) {
        return new ItemBlock(block).setRegistryName(block.getRegistryName());
    }
}

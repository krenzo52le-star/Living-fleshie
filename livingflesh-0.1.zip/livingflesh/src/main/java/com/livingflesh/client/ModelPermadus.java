package com.livingflesh.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Модель Пермадуса (около 3 блоков): тяжёлое сутулое тело на двух ногах, свисающая голова с пастью,
 * две толстые руки и множество тонких конечностей, торчащих из спины, боков и плеч.
 * Движение рваное: тело и лишние конечности дёргаются, походка хромая.
 * Земля находится на y = 24, лицо смотрит в сторону -z.
 */
public class ModelPermadus extends ModelBase {
    private final ModelRenderer thighL, shinL, thighR, shinR;
    private final ModelRenderer torso, head, jaw;
    private final ModelRenderer upperL, foreL, upperR, foreR;

    /** Лишние конечности: цепочки из сегментов с базовым углом и своей фазой дёрганья. */
    private static class Limb {
        final ModelRenderer[] seg;
        final float[] baseX, baseZ;
        final float seed;

        Limb(ModelRenderer[] seg, float[] baseX, float[] baseZ, float seed) {
            this.seg = seg;
            this.baseX = baseX;
            this.baseZ = baseZ;
            this.seed = seed;
        }
    }

    private final List<Limb> limbs = new ArrayList<>();

    public ModelPermadus() {
        this.textureWidth = 128;
        this.textureHeight = 128;

        // Ноги кривые: левая толстая и короткая, правая тонкая и длинная, стопы смотрят в разные стороны.
        thighL = box(90, 0, -3F, 0F, -3F, 6, 12, 6);
        thighL.setRotationPoint(5F, 2F, 0F);
        shinL = box(68, 29, -2.5F, 0F, -2.5F, 5, 10, 5);
        shinL.setRotationPoint(0F, 12F, 0F);
        thighL.addChild(shinL);
        shinL.addChild(foot(8F, 0.5F));
        thighR = box(52, 29, -2F, 0F, -2F, 4, 11, 4);
        thighR.setRotationPoint(-4F, 2F, 0F);
        shinR = box(100, 29, -1.5F, 0F, -1.5F, 3, 11, 3);
        shinR.setRotationPoint(0F, 11F, 0F);
        thighR.addChild(shinR);
        shinR.addChild(foot(9F, -0.3F));

        // Торс, наклонённый вперёд.
        torso = box(0, 0, -7F, -20F, -4.5F, 14, 20, 9);
        torso.setRotationPoint(0F, 2F, 0F);
        box(0, 45, -5F, -18F, 4.5F, 10, 10, 3, torso);   // горб на спине
        box(24, 58, -3F, -9F, -6F, 6, 6, 2, torso);        // нарост на груди
        box(0, 29, 7F, -16F, -3F, 4, 10, 6, torso);        // опухоль на левом боку
        box(70, 45, -10F, -21F, -2F, 5, 5, 5, torso);       // вздутое правое плечо
        box(26, 45, -8.5F, -9F, -1F, 3, 8, 4, torso);       // нарост на правом боку

        // Голова свисает вперёд.
        head = box(20, 29, -4F, -7F, -7F, 8, 8, 8);
        head.setRotationPoint(0F, -19F, -1F);
        torso.addChild(head);
        jaw = box(90, 45, -3.5F, 0F, -7F, 7, 3, 7);
        jaw.setRotationPoint(0F, 1F, 0F);
        head.addChild(jaw);
        box(0, 58, -6.5F, -4F, -5F, 3, 5, 5, head);        // вздутая щека
        box(70, 58, 0F, -8.5F, -7F, 5, 2, 3, head);         // тяжёлая бровь
        box(56, 58, 3F, -3F, -4F, 2, 3, 3, head);           // бугор у правого глаза
        box(86, 58, -3F, 0.5F, -7.5F, 6, 1, 1, jaw);       // зубы нижние
        box(86, 58, -3F, -0.5F, -7.5F, 6, 1, 1, head);     // зубы верхние

        // Две главные руки.
        // Левая рука длинная и толстая, правая короткая и согнутая.
        upperL = box(66, 0, -3F, 0F, -3F, 6, 14, 6);
        upperL.setRotationPoint(10F, -18F, 0F);
        foreL = box(46, 0, -2.5F, 0F, -2.5F, 5, 16, 5);
        foreL.setRotationPoint(0F, 14F, 0F);
        upperL.addChild(foreL);
        claws(foreL, 16F);
        torso.addChild(upperL);
        upperR = box(112, 29, -2F, 0F, -2F, 4, 10, 4);
        upperR.setRotationPoint(-10F, -15F, 0F);
        foreR = box(88, 29, -1.5F, 0F, -1.5F, 3, 12, 3);
        foreR.setRotationPoint(0F, 10F, 0F);
        upperR.addChild(foreR);
        claws(foreR, 12F);
        torso.addChild(upperR);

        // Торчащие конечности: x, y, z крепления (в системе торса) и направление.
        addLimb(7F, -14F, 1F, 1.1F, 1.0F, 4, 1F);
        addLimb(-7F, -12F, 2F, 0.9F, -1.1F, 4, 2F);
        addLimb(6F, -4F, 3F, 1.4F, 1.4F, 3, 3F);
        addLimb(-6F, -6F, 3F, 1.3F, -1.5F, 3, 4F);
        addLimb(3F, -19F, 4F, 1.9F, 0.5F, 4, 5F);
        addLimb(-3F, -17F, 4F, 1.7F, -0.6F, 4, 6F);
        addLimb(0F, -10F, 4.5F, 2.5F, 0.0F, 4, 7F);
        addLimb(8F, -19F, -1F, -0.8F, 1.7F, 3, 8F);
        addLimb(-8F, -20F, -1F, -0.9F, -1.8F, 3, 9F);
        addLimb(4F, -1F, 4F, 1.8F, 0.9F, 3, 10F);
        addLimb(-4F, -2F, 4F, 1.9F, -1.0F, 3, 11F);
        addLimb(0F, -22F, 2F, 1.6F, 0.2F, 4, 12F);
    }

    private ModelRenderer foot(float y, float turn) {
        ModelRenderer f = box(40, 45, -3F, y, -6F, 6, 2, 9);
        f.rotateAngleY = turn;
        return f;
    }

    private void claws(ModelRenderer fore, float y) {
        box(66, 58, -2F, y, -2F, 1, 5, 1, fore);
        box(66, 58, 0F, y, -2F, 1, 5, 1, fore);
        box(66, 58, -1F, y, 1F, 1, 5, 1, fore);
    }

    private void addLimb(float x, float y, float z, float rx, float rz, int n, float seed) {
        ModelRenderer[] seg = new ModelRenderer[n];
        float[] bx = new float[n];
        float[] bz = new float[n];
        ModelRenderer parent = torso;
        float len = 7F;
        float w = 2F;
        for (int i = 0; i < n; i++) {
            ModelRenderer s = box(limbU(len), limbV(len), -w / 2, 0F, -w / 2, (int) w, (int) len, (int) w);
            if (i == 0) {
                s.setRotationPoint(x, y, z);
            } else {
                s.setRotationPoint(0F, len + 2F, 0F);
            }
            s.rotateAngleX = bx[i] = i == 0 ? rx : (i % 2 == 0 ? 0.5F : -0.5F);
            s.rotateAngleZ = bz[i] = i == 0 ? rz : 0.25F * (i % 2 == 0 ? 1 : -1);
            parent.addChild(s);
            parent = s;
            seg[i] = s;
            len = Math.max(5F, len - 1F);
        }
        // шип на конце
        box(66, 58, -0.5F, parent == null ? 0 : 5F, -0.5F, 1, 4, 1, parent);
        limbs.add(new Limb(seg, bx, bz, seed));
    }

    private ModelRenderer box(int u, int v, float x, float y, float z, int w, int h, int d) {
        ModelRenderer r = new ModelRenderer(this, u, v);
        r.addBox(x, y, z, w, h, d);
        return r;
    }

    private ModelRenderer box(int u, int v, float x, float y, float z, int w, int h, int d, ModelRenderer parent) {
        ModelRenderer r = box(u, v, x, y, z, w, h, d);
        parent.addChild(r);
        return r;
    }

    /** Псевдослучайное число от -1 до 1 по целому шагу. */
    private static float hash(float n) {
        float s = MathHelper.sin(n * 12.9898F) * 43758.547F;
        return (s - (float) Math.floor(s)) * 2F - 1F;
    }

    /** Рваный сигнал: быстро щёлкает к новому значению и держится до следующего щелчка. */
    private static float twitch(float t, float seed) {
        float step = (float) Math.floor(t);
        float f = t - step;
        float k = Math.min(1F, f * 5F);
        k = k * k * (3F - 2F * k);
        return hash(step + seed) * (1F - k) + hash(step + 1F + seed) * k;
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, age, yaw, pitch, scale, entity);
        thighL.render(scale);
        thighR.render(scale);
        torso.render(scale);
        upperL.render(scale);
        upperR.render(scale);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale, Entity entity) {
        float walk = limbSwing * 0.45F;
        float amp = Math.min(1F, limbSwingAmount * 1.6F);
        // хромая походка: шаг то короткий, то резкий
        float jerkWalk = twitch(limbSwing * 0.5F, 3F);
        thighL.rotateAngleX = MathHelper.cos(walk) * 0.7F * amp + jerkWalk * 0.15F * amp;
        thighR.rotateAngleX = MathHelper.cos(walk + (float) Math.PI) * 0.45F * amp - jerkWalk * 0.15F * amp;
        shinL.rotateAngleX = Math.max(0F, -MathHelper.cos(walk)) * 0.9F * amp + 0.1F;
        shinR.rotateAngleX = Math.max(0F, MathHelper.cos(walk)) * 0.5F * amp + 0.1F;
        thighL.rotateAngleZ = -0.12F;
        thighR.rotateAngleZ = 0.1F;

        // торс: тяжёлый наклон, раскачка и подёргивания
        float t = age * 0.35F;
        torso.rotateAngleX = 0.35F + twitch(t, 20F) * 0.08F + MathHelper.cos(walk * 2F) * 0.05F * amp;
        torso.rotateAngleZ = 0.12F + MathHelper.cos(walk) * 0.12F * amp + twitch(t * 0.8F, 30F) * 0.06F;
        torso.rotateAngleY = twitch(t * 0.6F, 40F) * 0.1F;
        torso.rotationPointY = 2F + Math.abs(MathHelper.cos(walk)) * 1.2F * amp;

        // голова: смотрит на цель, но дёргается
        head.rotateAngleY = yaw * 0.0174533F * 0.6F + twitch(t * 1.5F, 50F) * 0.25F;
        head.rotateAngleX = pitch * 0.0174533F * 0.5F + 0.45F + twitch(t * 1.2F, 60F) * 0.2F;
        head.rotateAngleZ = 0.22F + twitch(t * 1.1F, 70F) * 0.18F;
        jaw.rotateAngleX = 0.25F + (twitch(t * 2F, 80F) + 1F) * 0.35F;

        // главные руки
        upperL.rotateAngleX = -MathHelper.cos(walk) * 0.5F * amp + twitch(t * 0.9F, 90F) * 0.25F - 0.1F;
        upperR.rotateAngleX = MathHelper.cos(walk) * 0.5F * amp + twitch(t * 0.9F, 100F) * 0.25F - 0.1F;
        upperL.rotateAngleZ = -0.15F + twitch(t, 110F) * 0.12F;
        upperR.rotateAngleZ = 0.15F + twitch(t, 120F) * 0.12F;
        foreL.rotateAngleX = -0.5F + twitch(t * 1.3F, 130F) * 0.3F;
        foreR.rotateAngleX = -1.1F + twitch(t * 1.3F, 140F) * 0.3F;

        // лишние конечности: каждая дёргается сама по себе
        for (Limb l : limbs) {
            for (int i = 0; i < l.seg.length; i++) {
                float tt = age * (0.45F + 0.1F * i) + l.seed * 7F;
                l.seg[i].rotateAngleX = l.baseX[i] + twitch(tt, l.seed * 5F + i) * 0.5F;
                l.seg[i].rotateAngleZ = l.baseZ[i] + twitch(tt * 0.9F, l.seed * 3F + i + 9F) * 0.4F;
            }
        }
    }
}

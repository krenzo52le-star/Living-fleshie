package com.livingflesh.client.gui;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.client.gui.EncyclopediaData.Article;
import com.livingflesh.client.gui.EncyclopediaData.Category;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.EntityLiving;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Экран энциклопедии. Три вида: главная (3 раздела), список статей раздела, статья.
 * Все размеры считаются от размера экрана, поэтому книга помещается и на маленьком экране телефона.
 * Кнопки обычные ванильные (GuiButton).
 */
public class GuiEncyclopedia extends GuiScreen {
    private static final ResourceLocation TEXTURE = new ResourceLocation(LivingFleshMod.MODID, "textures/gui/encyclopedia.png");
    private static final int TEX_W = 320;
    private static final int TEX_H = 192;

    private static final int INK = 0x3B2A1A;
    private static final int TITLE = 0x7A1F1F;
    private static final int LABEL = 0x5A1A1A;
    private static final int VALUE = 0x6B5A44;

    private static final int B_BACK = 1;
    private static final int B_PREV = 2;
    private static final int B_NEXT = 3;
    private static final int B_CAT = 10;   // 10..12
    private static final int B_SUB = 50;   // 50 + номер подкатегории
    private static final int B_ITEM = 100; // 100 + номер статьи

    private static final int VIEW_MAIN = 0;
    private static final int VIEW_LIST = 1;
    private static final int VIEW_ARTICLE = 2;

    private int view = VIEW_MAIN;
    private int category;
    private int sub = -1; // -1 = подкатегория не выбрана
    private int listPage;
    private int listPages = 1;
    private int article;
    private int textPage;
    private int textPages = 1;
    private int linesPerPage = 1;
    private List<String> descLines = new ArrayList<>();

    private EntityLiving shownEntity;
    private int shownEntityFor = -1;

    // геометрия книги
    private int bx, by, bw, bh;
    private int leftX, leftW, rightX, rightW, top, bottom;

    @Override
    public void initGui() {
        super.initGui();
        bw = Math.min(TEX_W, width - 6);
        bh = Math.min(TEX_H, height - 6);
        bx = (width - bw) / 2;
        by = (height - bh) / 2;
        int pad = Math.max(8, bw * 19 / TEX_W);
        int half = bw / 2;
        leftX = bx + pad;
        leftW = half - pad - 5;
        rightX = bx + half + 5;
        rightW = half - pad - 5;
        int vpad = Math.max(6, bh * 15 / TEX_H);
        top = by + vpad;
        bottom = by + bh - vpad;
        buildButtons();
    }

    private Category currentCategory() {
        Category cat = EncyclopediaData.CATEGORIES.get(category);
        return sub >= 0 ? cat.subs.get(sub) : cat;
    }

    private List<Article> articles() {
        return currentCategory().articles;
    }

    /** В разделе с подкатегориями на первом шаге показываем выбор подкатегории. */
    private boolean choosingSub() {
        Category cat = EncyclopediaData.CATEGORIES.get(category);
        return sub < 0 && !cat.subs.isEmpty();
    }

    private List<String> entryTitles() {
        List<String> titles = new ArrayList<>();
        if (choosingSub()) {
            for (Category c : EncyclopediaData.CATEGORIES.get(category).subs) {
                titles.add(c.title);
            }
        } else {
            for (Article a : articles()) {
                titles.add(a.title);
            }
        }
        return titles;
    }

    private void buildButtons() {
        buttonList.clear();
        if (view == VIEW_MAIN) {
            int gap = 4;
            int total = 3 * 20 + 2 * gap;
            int y0 = top + (bottom - top - total) / 2 + 6;
            for (int i = 0; i < EncyclopediaData.CATEGORIES.size(); i++) {
                buttonList.add(new GuiButton(B_CAT + i, rightX, y0 + i * (20 + gap), rightW, 20,
                        EncyclopediaData.CATEGORIES.get(i).title));
            }
        } else if (view == VIEW_LIST) {
            List<String> list = entryTitles();
            int idBase = choosingSub() ? B_SUB : B_ITEM;
            int rows = Math.max(1, (bottom - (top + 18) - 26) / 24);
            int perPage = rows * 2;
            listPages = Math.max(1, (list.size() + perPage - 1) / perPage);
            listPage = Math.max(0, Math.min(listPage, listPages - 1));
            for (int k = 0; k < perPage; k++) {
                int idx = listPage * perPage + k;
                if (idx >= list.size()) {
                    break;
                }
                int col = k % 2;
                int row = k / 2;
                buttonList.add(new GuiButton(idBase + idx, col == 0 ? leftX : rightX, top + 18 + row * 24,
                        col == 0 ? leftW : rightW, 20, list.get(idx)));
            }
            buttonList.add(new GuiButton(B_BACK, leftX, bottom - 20, 60, 20, "Назад"));
            if (listPages > 1) {
                buttonList.add(new GuiButton(B_PREV, rightX + rightW - 44, bottom - 20, 20, 20, "<"));
                buttonList.add(new GuiButton(B_NEXT, rightX + rightW - 20, bottom - 20, 20, 20, ">"));
            }
        } else {
            Article a = articles().get(article);
            descLines = fontRenderer.listFormattedStringToWidth(a.text, Math.max(20, rightW));
            linesPerPage = Math.max(1, (bottom - (top + 16) - 24) / 9);
            textPages = Math.max(1, (descLines.size() + linesPerPage - 1) / linesPerPage);
            textPage = Math.max(0, Math.min(textPage, textPages - 1));
            buttonList.add(new GuiButton(B_BACK, leftX, bottom - 20, 60, 20, "Назад"));
            if (textPages > 1) {
                buttonList.add(new GuiButton(B_PREV, rightX + rightW - 44, bottom - 20, 20, 20, "<"));
                buttonList.add(new GuiButton(B_NEXT, rightX + rightW - 20, bottom - 20, 20, 20, ">"));
            }
        }
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        int id = button.id;
        if (id == B_BACK) {
            if (view == VIEW_ARTICLE) {
                view = VIEW_LIST;
            } else if (sub >= 0) {
                sub = -1; // из подкатегории назад к выбору подкатегории
                listPage = 0;
            } else {
                view = VIEW_MAIN;
            }
        } else if (id == B_PREV) {
            if (view == VIEW_LIST) {
                listPage--;
            } else {
                textPage--;
            }
        } else if (id == B_NEXT) {
            if (view == VIEW_LIST) {
                listPage++;
            } else {
                textPage++;
            }
        } else if (id >= B_ITEM) {
            article = id - B_ITEM;
            textPage = 0;
            shownEntityFor = -1;
            view = VIEW_ARTICLE;
        } else if (id >= B_SUB) {
            sub = id - B_SUB;
            listPage = 0;
        } else if (id >= B_CAT) {
            category = id - B_CAT;
            sub = -1;
            listPage = 0;
            view = VIEW_LIST;
        }
        buildButtons();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == mc.gameSettings.keyBindInventory.getKeyCode()) {
            mc.displayGuiScreen(null);
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    // ----------------------------------------------------------------- рисование

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        GlStateManager.enableBlend();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        mc.getTextureManager().bindTexture(TEXTURE);
        drawScaledCustomSizeModalRect(bx, by, 0, 0, TEX_W, TEX_H, bw, bh, TEX_W, TEX_H);

        if (view == VIEW_MAIN) {
            drawMain();
        } else if (view == VIEW_LIST) {
            drawList();
        } else {
            drawArticle(mouseX, mouseY);
        }
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void centered(String text, int cx, int y, int color) {
        fontRenderer.drawString(text, cx - fontRenderer.getStringWidth(text) / 2, y, color);
    }

    private void drawMain() {
        int cx = leftX + leftW / 2;
        centered("Энциклопедия", cx, top + 2, TITLE);
        centered("плоти", cx, top + 12, TITLE);
        int iconSize = Math.max(24, Math.min(leftW, bottom - top - 70));
        drawItem(new ItemStack(com.livingflesh.ModBlocks.FLESH_CORE), cx, top + 26 + iconSize / 2, iconSize);
        List<String> lines = fontRenderer.listFormattedStringToWidth("Записки о Живой плоти: что это, как растёт и чем грозит.", Math.max(20, leftW));
        int y = top + 30 + iconSize;
        for (String line : lines) {
            if (y > bottom - 9) {
                break;
            }
            centered(line, cx, y, VALUE);
            y += 9;
        }
        centered("Разделы", rightX + rightW / 2, top + 2, TITLE);
    }

    private void drawList() {
        Category cat = EncyclopediaData.CATEGORIES.get(category);
        String heading = sub >= 0 ? cat.title + ": " + cat.subs.get(sub).title : cat.title;
        centered(heading, bx + bw / 2, top + 2, TITLE);
        if (!choosingSub() && articles().isEmpty()) {
            centered("Скоро будет", bx + bw / 2, (top + bottom) / 2 - 8, TITLE);
            centered("Записей пока нет.", bx + bw / 2, (top + bottom) / 2 + 4, VALUE);
        }
        if (listPages > 1) {
            String counter = (listPage + 1) + "/" + listPages;
            fontRenderer.drawString(counter, rightX + rightW - 50 - fontRenderer.getStringWidth(counter), bottom - 14, VALUE);
        }
    }

    private void drawArticle(int mouseX, int mouseY) {
        Article a = articles().get(article);

        // ---- левая страница: название, картинка, сведения
        int cx = leftX + leftW / 2;
        String title = fontRenderer.trimStringToWidth(a.title, leftW);
        centered(title, cx, top + 2, TITLE);
        int pw = Math.max(24, (int) (leftW * 0.44F));
        int py = top + 14;
        int ph = Math.max(24, bottom - 24 - py);
        drawRect(leftX, py, leftX + pw, py + ph, 0x22000000);
        drawRect(leftX, py, leftX + pw, py + 1, 0x44000000);
        drawRect(leftX, py + ph - 1, leftX + pw, py + ph, 0x44000000);
        drawRect(leftX, py, leftX + 1, py + ph, 0x44000000);
        drawRect(leftX + pw - 1, py, leftX + pw, py + ph, 0x44000000);

        int picCx = leftX + pw / 2;
        if (a.entity != null && mc.world != null) {
            if (shownEntityFor != article) {
                shownEntity = a.entity.apply(mc.world);
                shownEntityFor = article;
            }
            if (shownEntity != null) {
                int scale = (int) (Math.min(pw, ph) * 0.62F / Math.max(0.5F, shownEntity.height));
                GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
                GuiInventory.drawEntityOnScreen(picCx, py + ph - 6, Math.max(8, scale),
                        (float) (picCx - mouseX), (float) (py + ph / 2 - mouseY), shownEntity);
            }
        } else if (a.icon != null) {
            drawItem(a.icon.get(), picCx, py + ph / 2, Math.min(pw, ph) - 10);
        }

        int ix = leftX + pw + 6;
        int iw = Math.max(20, leftW - pw - 6);
        int y = py;
        for (String row : a.info) {
            int sep = row.indexOf('|');
            String label = sep >= 0 ? row.substring(0, sep) : row;
            String value = sep >= 0 ? row.substring(sep + 1) : "";
            if (y > bottom - 34) {
                break;
            }
            fontRenderer.drawString(fontRenderer.trimStringToWidth(label, iw), ix, y, LABEL);
            y += 9;
            for (String line : fontRenderer.listFormattedStringToWidth(value, iw)) {
                if (y > bottom - 26) {
                    break;
                }
                fontRenderer.drawString(line, ix, y, VALUE);
                y += 9;
            }
            y += 3;
        }

        // ---- правая страница: описание
        int ty = top + 2;
        int from = textPage * linesPerPage;
        for (int i = from; i < Math.min(descLines.size(), from + linesPerPage); i++) {
            fontRenderer.drawString(descLines.get(i), rightX, ty, INK);
            ty += 9;
        }
        if (textPages > 1) {
            String counter = (textPage + 1) + "/" + textPages;
            fontRenderer.drawString(counter, rightX + rightW - 50 - fontRenderer.getStringWidth(counter), bottom - 14, VALUE);
        }
    }

    /** Рисует предмет увеличенным, по центру в точке (cx, cy) в квадрате size. */
    private void drawItem(ItemStack stack, int cx, int cy, int size) {
        float s = Math.max(1.0F, size / 16.0F);
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx - 8.0F * s, cy - 8.0F * s, 0.0F);
        GlStateManager.scale(s, s, 1.0F);
        mc.getRenderItem().renderItemAndEffectIntoGUI(stack, 0, 0);
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
    }
}

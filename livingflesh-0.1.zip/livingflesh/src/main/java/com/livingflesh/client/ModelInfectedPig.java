package com.livingflesh.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/**
 * Модель заражённой свиньи (сгенерирована скриптом): розовая кожа с пятнами плоти, открытые рёбра и рана на боках,
 * костяной гребень, опухоли, голова с клыками и отвисающей челюстью, уши разного размера, кривые ноги,
 * лишние конечности и щупальца. Двигается рывками.
 * Земля находится на y = 24, лицо смотрит в сторону -z.
 */
public class ModelInfectedPig extends ModelBase {
    private final ModelRenderer thighFL;
    private final ModelRenderer shinFL;
    private final ModelRenderer hoofFL;
    private final ModelRenderer thighFR;
    private final ModelRenderer shinFR;
    private final ModelRenderer hoofFR;
    private final ModelRenderer thighRL;
    private final ModelRenderer shinRL;
    private final ModelRenderer hoofRL;
    private final ModelRenderer thighRR;
    private final ModelRenderer shinRR;
    private final ModelRenderer body;
    private final ModelRenderer spine;
    private final ModelRenderer sp1;
    private final ModelRenderer sp2;
    private final ModelRenderer sp3;
    private final ModelRenderer shoulder;
    private final ModelRenderer belly;
    private final ModelRenderer hip;
    private final ModelRenderer head;
    private final ModelRenderer snout;
    private final ModelRenderer jaw;
    private final ModelRenderer teethU;
    private final ModelRenderer teethL;
    private final ModelRenderer tuskL;
    private final ModelRenderer tuskR;
    private final ModelRenderer earL;
    private final ModelRenderer earR;
    private final ModelRenderer eye;
    private final ModelRenderer cheek;
    private final ModelRenderer tail;
    private final ModelRenderer tailTip;
    private final ModelRenderer tentL1;
    private final ModelRenderer tentL2;
    private final ModelRenderer tentR1;
    private final ModelRenderer tentR2;
    private final ModelRenderer xlegA;
    private final ModelRenderer xlegB;
    private final ModelRenderer xlegC;

    public ModelInfectedPig() {
        this.textureWidth = 128;
        this.textureHeight = 128;

        thighFL = new ModelRenderer(this, 28, 24);
        thighFL.addBox(-2F, 0F, -2F, 4, 4, 4);
        thighFL.setRotationPoint(3.5F, 17F, -6F);
        thighFL.rotateAngleX = 0F; thighFL.rotateAngleY = 0F; thighFL.rotateAngleZ = -0.05F;
        shinFL = new ModelRenderer(this, 94, 24);
        shinFL.addBox(-1.5F, 0F, -1.5F, 3, 3, 3);
        shinFL.setRotationPoint(0F, 4F, 0F);
        thighFL.addChild(shinFL);
        hoofFL = new ModelRenderer(this, 24, 35);
        hoofFL.addBox(-2F, 2F, -2.5F, 4, 1, 4);
        hoofFL.setRotationPoint(0F, 0F, 0F);
        shinFL.addChild(hoofFL);
        thighFR = new ModelRenderer(this, 28, 24);
        thighFR.addBox(-1.5F, 0F, -1.5F, 3, 5, 3);
        thighFR.setRotationPoint(-3.5F, 17F, -6F);
        thighFR.rotateAngleX = -0.3F; thighFR.rotateAngleY = 0F; thighFR.rotateAngleZ = 0.1F;
        shinFR = new ModelRenderer(this, 94, 24);
        shinFR.addBox(-1F, 0F, -1F, 2, 3, 2);
        shinFR.setRotationPoint(0F, 5F, 0F);
        shinFR.rotateAngleX = 0.7F; shinFR.rotateAngleY = 0F; shinFR.rotateAngleZ = -0.1F;
        thighFR.addChild(shinFR);
        hoofFR = new ModelRenderer(this, 24, 35);
        hoofFR.addBox(-2F, 2F, -2.5F, 4, 1, 4);
        hoofFR.setRotationPoint(0F, 0F, 0F);
        hoofFR.rotateAngleX = 0F; hoofFR.rotateAngleY = 0.3F; hoofFR.rotateAngleZ = 0F;
        shinFR.addChild(hoofFR);
        thighRL = new ModelRenderer(this, 28, 24);
        thighRL.addBox(-2.5F, 0F, -2F, 5, 4, 5);
        thighRL.setRotationPoint(3.5F, 17F, 4F);
        thighRL.rotateAngleX = -0.5F; thighRL.rotateAngleY = 0F; thighRL.rotateAngleZ = 0F;
        shinRL = new ModelRenderer(this, 94, 24);
        shinRL.addBox(-1.5F, 0F, -1.5F, 3, 4, 3);
        shinRL.setRotationPoint(0F, 4F, 0F);
        shinRL.rotateAngleX = 1.0F; shinRL.rotateAngleY = 0F; shinRL.rotateAngleZ = 0F;
        thighRL.addChild(shinRL);
        hoofRL = new ModelRenderer(this, 24, 35);
        hoofRL.addBox(-2F, 3F, -2.5F, 4, 1, 4);
        hoofRL.setRotationPoint(0F, 0F, 0F);
        shinRL.addChild(hoofRL);
        thighRR = new ModelRenderer(this, 28, 24);
        thighRR.addBox(-3F, 0F, -3F, 6, 4, 6);
        thighRR.setRotationPoint(-3.5F, 17F, 4F);
        shinRR = new ModelRenderer(this, 94, 24);
        shinRR.addBox(-2.5F, 0F, -2.5F, 5, 3, 5);
        shinRR.setRotationPoint(0F, 4F, 0F);
        thighRR.addChild(shinRR);
        body = new ModelRenderer(this, 0, 0);
        body.addBox(-5F, -4F, -9F, 10, 8, 16);
        body.setRotationPoint(0F, 14F, 0F);
        body.rotateAngleX = 0F; body.rotateAngleY = 0F; body.rotateAngleZ = 0.06F;
        spine = new ModelRenderer(this, 52, 0);
        spine.addBox(-1.5F, -7F, -8F, 3, 3, 14);
        spine.setRotationPoint(0F, 0F, 0F);
        body.addChild(spine);
        sp1 = new ModelRenderer(this, 20, 35);
        sp1.addBox(-0.5F, -10F, -6F, 1, 3, 1);
        sp1.setRotationPoint(0F, 0F, 0F);
        sp1.rotateAngleX = 0.2F; sp1.rotateAngleY = 0F; sp1.rotateAngleZ = 0.1F;
        body.addChild(sp1);
        sp2 = new ModelRenderer(this, 20, 35);
        sp2.addBox(-0.5F, -10F, -1F, 1, 3, 1);
        sp2.setRotationPoint(0F, 0F, 0F);
        sp2.rotateAngleX = -0.1F; sp2.rotateAngleY = 0F; sp2.rotateAngleZ = -0.2F;
        body.addChild(sp2);
        sp3 = new ModelRenderer(this, 20, 35);
        sp3.addBox(-0.5F, -10F, 4F, 1, 3, 1);
        sp3.setRotationPoint(0F, 0F, 0F);
        sp3.rotateAngleX = 0.25F; sp3.rotateAngleY = 0F; sp3.rotateAngleZ = 0.2F;
        body.addChild(sp3);
        shoulder = new ModelRenderer(this, 74, 24);
        shoulder.addBox(2F, -7F, -8F, 5, 4, 5);
        shoulder.setRotationPoint(0F, 0F, 0F);
        body.addChild(shoulder);
        belly = new ModelRenderer(this, 52, 24);
        belly.addBox(-3F, 4F, -2F, 5, 4, 6);
        belly.setRotationPoint(0F, 0F, 0F);
        body.addChild(belly);
        hip = new ModelRenderer(this, 74, 24);
        hip.addBox(-8F, -3F, 2F, 3, 4, 4);
        hip.setRotationPoint(0F, 0F, 0F);
        body.addChild(hip);
        head = new ModelRenderer(this, 86, 0);
        head.addBox(-4F, -4F, -8F, 8, 8, 8);
        head.setRotationPoint(0F, -0.5F, -8.5F);
        head.rotateAngleX = 0.25F; head.rotateAngleY = 0.12F; head.rotateAngleZ = 0.22F;
        body.addChild(head);
        snout = new ModelRenderer(this, 48, 35);
        snout.addBox(-2F, 0F, -9F, 4, 3, 1);
        snout.setRotationPoint(0F, 0F, 0F);
        head.addChild(snout);
        jaw = new ModelRenderer(this, 0, 24);
        jaw.addBox(-3F, 0F, -8F, 6, 3, 8);
        jaw.setRotationPoint(0F, 3.5F, 0F);
        jaw.rotateAngleX = 0.3F; jaw.rotateAngleY = 0F; jaw.rotateAngleZ = 0F;
        head.addChild(jaw);
        teethU = new ModelRenderer(this, 68, 35);
        teethU.addBox(-2.5F, 3F, -9F, 5, 1, 1);
        teethU.setRotationPoint(0F, 0F, 0F);
        head.addChild(teethU);
        teethL = new ModelRenderer(this, 68, 35);
        teethL.addBox(-2.5F, -1F, -8.5F, 5, 1, 1);
        teethL.setRotationPoint(0F, 0F, 0F);
        jaw.addChild(teethL);
        tuskL = new ModelRenderer(this, 20, 35);
        tuskL.addBox(-0.5F, -4F, -0.5F, 1, 4, 1);
        tuskL.setRotationPoint(2.5F, 3F, -8.5F);
        tuskL.rotateAngleX = 0F; tuskL.rotateAngleY = 0F; tuskL.rotateAngleZ = 0.4F;
        head.addChild(tuskL);
        tuskR = new ModelRenderer(this, 20, 35);
        tuskR.addBox(-0.5F, -3F, -0.5F, 1, 3, 1);
        tuskR.setRotationPoint(-2.5F, 3F, -8.5F);
        tuskR.rotateAngleX = 0F; tuskR.rotateAngleY = 0F; tuskR.rotateAngleZ = -0.5F;
        head.addChild(tuskR);
        earL = new ModelRenderer(this, 58, 35);
        earL.addBox(-2F, 0F, -0.5F, 4, 3, 1);
        earL.setRotationPoint(3.5F, -3.5F, -2F);
        earL.rotateAngleX = 0F; earL.rotateAngleY = 0F; earL.rotateAngleZ = -1.0F;
        head.addChild(earL);
        earR = new ModelRenderer(this, 58, 35);
        earR.addBox(-2F, 0F, -0.5F, 3, 2, 1);
        earR.setRotationPoint(-3.5F, -3.5F, -2F);
        earR.rotateAngleX = 0F; earR.rotateAngleY = 0F; earR.rotateAngleZ = 0.8F;
        head.addChild(earR);
        eye = new ModelRenderer(this, 40, 35);
        eye.addBox(3F, -3F, -8.4F, 2, 3, 2);
        eye.setRotationPoint(0F, 0F, 0F);
        head.addChild(eye);
        cheek = new ModelRenderer(this, 114, 24);
        cheek.addBox(-5.5F, -2F, -5F, 3, 4, 4);
        cheek.setRotationPoint(0F, 0F, 0F);
        head.addChild(cheek);
        tail = new ModelRenderer(this, 16, 35);
        tail.addBox(-0.5F, 0F, -0.5F, 1, 5, 1);
        tail.setRotationPoint(0F, -2F, 7F);
        tail.rotateAngleX = 0.9F; tail.rotateAngleY = 0F; tail.rotateAngleZ = 0F;
        body.addChild(tail);
        tailTip = new ModelRenderer(this, 20, 35);
        tailTip.addBox(-0.5F, 5F, -0.5F, 1, 3, 1);
        tailTip.setRotationPoint(0F, 0F, 0F);
        tail.addChild(tailTip);
        tentL1 = new ModelRenderer(this, 8, 35);
        tentL1.addBox(-1F, 0F, -1F, 2, 5, 2);
        tentL1.setRotationPoint(2.5F, -4F, 3F);
        tentL1.rotateAngleX = 0.4F; tentL1.rotateAngleY = 0F; tentL1.rotateAngleZ = 0.9F;
        body.addChild(tentL1);
        tentL2 = new ModelRenderer(this, 8, 35);
        tentL2.addBox(-1F, 0F, -1F, 2, 4, 2);
        tentL2.setRotationPoint(0F, 5F, 0F);
        tentL2.rotateAngleX = 0.4F; tentL2.rotateAngleY = 0F; tentL2.rotateAngleZ = 0.2F;
        tentL1.addChild(tentL2);
        tentR1 = new ModelRenderer(this, 8, 35);
        tentR1.addBox(-1F, 0F, -1F, 2, 5, 2);
        tentR1.setRotationPoint(-2.5F, -4F, 5F);
        tentR1.rotateAngleX = -0.3F; tentR1.rotateAngleY = 0F; tentR1.rotateAngleZ = -0.9F;
        body.addChild(tentR1);
        tentR2 = new ModelRenderer(this, 8, 35);
        tentR2.addBox(-1F, 0F, -1F, 2, 4, 2);
        tentR2.setRotationPoint(0F, 5F, 0F);
        tentR2.rotateAngleX = 0.4F; tentR2.rotateAngleY = 0F; tentR2.rotateAngleZ = -0.2F;
        tentR1.addChild(tentR2);
        xlegA = new ModelRenderer(this, 0, 35);
        xlegA.addBox(-1F, 0F, -1F, 2, 6, 2);
        xlegA.setRotationPoint(-5F, 2F, -2F);
        xlegA.rotateAngleX = 0F; xlegA.rotateAngleY = 0F; xlegA.rotateAngleZ = -0.6F;
        body.addChild(xlegA);
        xlegB = new ModelRenderer(this, 0, 35);
        xlegB.addBox(-1F, 0F, -1F, 2, 5, 2);
        xlegB.setRotationPoint(0F, 6F, 0F);
        xlegB.rotateAngleX = 0.5F; xlegB.rotateAngleY = 0F; xlegB.rotateAngleZ = 0.3F;
        xlegA.addChild(xlegB);
        xlegC = new ModelRenderer(this, 0, 35);
        xlegC.addBox(-1F, 0F, -1F, 2, 4, 2);
        xlegC.setRotationPoint(5F, -2F, 5F);
        xlegC.rotateAngleX = 0.2F; xlegC.rotateAngleY = 0F; xlegC.rotateAngleZ = 1.3F;
        body.addChild(xlegC);
    }

    private static float hash(float n) {
        float s = MathHelper.sin(n * 12.9898F) * 43758.547F;
        return (s - (float) Math.floor(s)) * 2F - 1F;
    }

    /** Рваный сигнал: резко щёлкает к новому значению и держится до следующего щелчка. */
    private static float twitch(float t, float seed) {
        float step = (float) Math.floor(t);
        float f = t - step;
        float k = Math.min(1F, f * 5F);
        k = k * k * (3F - 2F * k);
        return hash(step + seed) * (1F - k) + hash(step + 1F + seed) * k;
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, age, yaw, pitch, scale, entity);
        body.render(scale);
        thighFL.render(scale);
        thighFR.render(scale);
        thighRL.render(scale);
        thighRR.render(scale);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale, Entity entity) {
        float walk = limbSwing * 0.7F;
        float amp = Math.min(1F, limbSwingAmount * 1.5F);
        float t = age * 0.28F;

        // ноги: хромота, правая задняя почти не гнётся
        thighFL.rotateAngleX = MathHelper.cos(walk) * 0.9F * amp;
        thighFR.rotateAngleX = -0.3F + MathHelper.cos(walk + (float) Math.PI) * 0.7F * amp + twitch(t * 3F, 3F) * 0.12F * amp;
        thighRL.rotateAngleX = -0.5F + MathHelper.cos(walk + (float) Math.PI) * 0.8F * amp;
        thighRR.rotateAngleX = MathHelper.cos(walk) * 0.35F * amp;
        shinFL.rotateAngleX = Math.max(0F, -MathHelper.cos(walk)) * 0.6F * amp;
        shinFR.rotateAngleX = 0.7F + Math.max(0F, MathHelper.cos(walk)) * 0.5F * amp;
        shinRL.rotateAngleX = 1.0F + Math.max(0F, MathHelper.cos(walk)) * 0.5F * amp;

        // тело подрагивает и хромает
        body.rotateAngleZ = 0.06F + MathHelper.cos(walk) * 0.07F * amp + twitch(t, 11F) * 0.04F;
        body.rotateAngleX = twitch(t * 0.8F, 17F) * 0.05F;
        body.rotationPointY = 14F + Math.abs(MathHelper.cos(walk)) * 0.7F * amp;
        shoulder.rotateAngleZ = twitch(t * 1.5F, 23F) * 0.06F;
        belly.rotateAngleX = twitch(t * 1.2F, 29F) * 0.08F;

        // голова мотается, челюсть ходит
        head.rotateAngleX = 0.25F + pitch * 0.0174533F * 0.4F + twitch(t * 1.2F, 35F) * 0.18F;
        head.rotateAngleY = 0.12F + yaw * 0.0174533F * 0.5F + twitch(t * 1.4F, 41F) * 0.15F;
        head.rotateAngleZ = 0.22F + twitch(t * 1.1F, 47F) * 0.12F;
        jaw.rotateAngleX = 0.3F + (twitch(t * 2.2F, 53F) + 1F) * 0.2F;
        earL.rotateAngleZ = -1.0F + twitch(t * 2.5F, 59F) * 0.3F;
        earR.rotateAngleZ = 0.8F + twitch(t * 2.9F, 65F) * 0.35F;

        // хвост, щупальца и лишние конечности
        tail.rotateAngleX = 0.9F + twitch(t * 1.3F, 71F) * 0.4F;
        tentL1.rotateAngleZ = 0.9F + twitch(t * 2F, 77F) * 0.4F;
        tentL1.rotateAngleX = 0.4F + twitch(t * 1.7F, 83F) * 0.4F;
        tentL2.rotateAngleX = 0.4F + twitch(t * 2.4F, 89F) * 0.5F;
        tentR1.rotateAngleZ = -0.9F + twitch(t * 2F, 95F) * 0.4F;
        tentR1.rotateAngleX = -0.3F + twitch(t * 1.7F, 101F) * 0.4F;
        tentR2.rotateAngleX = 0.4F + twitch(t * 2.4F, 107F) * 0.5F;
        xlegA.rotateAngleX = twitch(t * 2F, 113F) * 0.5F;
        xlegA.rotateAngleZ = -0.6F + twitch(t * 1.6F, 119F) * 0.3F;
        xlegB.rotateAngleX = 0.5F + twitch(t * 2.6F, 125F) * 0.6F;
        xlegC.rotateAngleX = 0.2F + twitch(t * 2.2F, 131F) * 0.6F;
    }
}

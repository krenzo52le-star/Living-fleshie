package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityPermadus;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Рисует Пермадуса собственной моделью. */
public class RenderPermadus extends RenderLiving<EntityPermadus> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/permadus.png");

    public RenderPermadus(RenderManager manager) {
        super(manager, new ModelPermadus(), 1.0F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityPermadus entity) {
        return TEXTURE;
    }
}

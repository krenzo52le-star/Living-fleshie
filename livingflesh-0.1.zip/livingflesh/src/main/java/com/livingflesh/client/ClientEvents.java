package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.ModBlocks;
import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.entity.EntityInfectedCow;
import com.livingflesh.entity.EntityInfectedPig;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID, value = Side.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onModelRegistry(ModelRegistryEvent event) {
        registerItemModel(ModBlocks.FLESH_BLOCK);
        registerItemModel(ModBlocks.FLESH_CORE);
        registerItemModel(ModBlocks.FLESH_STALK);
        registerItemModel(ModBlocks.INFECTED_GRASS);
        registerItemModel(ModBlocks.INFECTED_LOG);
        registerItemModel(ModBlocks.INFECTED_LEAVES);
        registerItemModel(ModBlocks.INFECTED_STONE);
        registerItemModel(ModBlocks.FLESH_VINE);
        registerItemModel(ModBlocks.INFECTED_ORE);
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.INFECTED_INGOT, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.INFECTED_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.ENCYCLOPEDIA, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.ENCYCLOPEDIA.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.PERMADUS_CORE, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.PERMADUS_CORE.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.REINFORCED_WEB, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.REINFORCED_WEB.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.REINFORCED_BASE, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.REINFORCED_BASE.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.CHARGED_INGOT, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.CHARGED_INGOT.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.INFECTION_SWORD, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.INFECTION_SWORD.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.FLESH_BONE, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.FLESH_BONE.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(com.livingflesh.ModItems.DEAD_FLESH, 0,
                new ModelResourceLocation(com.livingflesh.ModItems.DEAD_FLESH.getRegistryName(), "inventory"));
        for (Item egg : new Item[]{com.livingflesh.ModItems.EGG_FLESH_PIECE, com.livingflesh.ModItems.EGG_INFECTED_COW, com.livingflesh.ModItems.EGG_INFECTED_PIG, com.livingflesh.ModItems.EGG_INFECTED_ZOMBIE, com.livingflesh.ModItems.EGG_INFECTED_SHEEP, com.livingflesh.ModItems.EGG_INFECTED_CHICKEN, com.livingflesh.ModItems.EGG_INFECTED_VILLAGER, com.livingflesh.ModItems.EGG_PERMADUS, com.livingflesh.ModItems.EGG_RABID_COW, com.livingflesh.ModItems.EGG_ARACHNEIDEF}) {
            ModelLoader.setCustomModelResourceLocation(egg, 0, new ModelResourceLocation(egg.getRegistryName(), "inventory"));
        }
        RenderingRegistry.registerEntityRenderingHandler(EntityFleshPiece.class, RenderFleshPiece::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInfectedCow.class, RenderInfectedCow::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInfectedPig.class, RenderInfectedPig::new);
        RenderingRegistry.registerEntityRenderingHandler(com.livingflesh.entity.EntityInfectedZombie.class, RenderInfectedZombie::new);
        RenderingRegistry.registerEntityRenderingHandler(com.livingflesh.entity.EntityInfectedSheep.class, RenderInfectedSheep::new);
        RenderingRegistry.registerEntityRenderingHandler(com.livingflesh.entity.EntityInfectedChicken.class, RenderInfectedChicken::new);
        RenderingRegistry.registerEntityRenderingHandler(com.livingflesh.entity.EntityInfectedVillager.class, RenderInfectedVillager::new);
        RenderingRegistry.registerEntityRenderingHandler(com.livingflesh.entity.EntityPermadus.class, RenderPermadus::new);
        RenderingRegistry.registerEntityRenderingHandler(com.livingflesh.entity.EntityArachneidef.class, RenderArachneidef::new);
        RenderingRegistry.registerEntityRenderingHandler(com.livingflesh.entity.EntityRabidCow.class, RenderRabidCow::new);
    }

    private static void registerItemModel(Block block) {
        ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(block), 0,
                new ModelResourceLocation(block.getRegistryName(), "inventory"));
    }
}

package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.ModBlocks;
import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.entity.EntityInfectedCow;
import com.livingflesh.entity.EntityInfectedPig;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID, value = Side.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onModelRegistry(ModelRegistryEvent event) {
        registerItemModel(ModBlocks.FLESH_BLOCK);
        registerItemModel(ModBlocks.FLESH_CORE);
        RenderingRegistry.registerEntityRenderingHandler(EntityFleshPiece.class, RenderFleshPiece::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInfectedCow.class, RenderInfectedCow::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityInfectedPig.class, RenderInfectedPig::new);
    }

    private static void registerItemModel(Block block) {
        ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(block), 0,
                new ModelResourceLocation(block.getRegistryName(), "inventory"));
    }
}

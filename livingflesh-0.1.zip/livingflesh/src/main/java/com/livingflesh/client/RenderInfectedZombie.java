package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderZombie;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.util.ResourceLocation;

/** Ванильная модель зомби с заражённым скином. */
public class RenderInfectedZombie extends RenderZombie {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_zombie.png");

    public RenderInfectedZombie(RenderManager manager) {
        super(manager);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityZombie entity) {
        return TEXTURE;
    }
}

package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityInfectedZombie;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Рисует заражённого зомби собственной моделью. */
public class RenderInfectedZombie extends RenderLiving<EntityInfectedZombie> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_zombie.png");

    public RenderInfectedZombie(RenderManager manager) {
        super(manager, new ModelInfectedZombie(), 0.5F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityInfectedZombie entity) {
        return TEXTURE;
    }
}

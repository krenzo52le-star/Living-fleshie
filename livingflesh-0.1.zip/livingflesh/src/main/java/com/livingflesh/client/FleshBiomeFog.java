package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.ModBlocks;
import com.livingflesh.util.Names;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

import java.util.Random;

/**
 * «Биом плоти»: если вокруг игрока достаточно заражённых блоков (плоть сильно разрослась), местность считается
 * биомом плоти: плавно появляется красный туман. Считается на клиенте по блокам вокруг игрока, поэтому
 * работает и в одиночной игре, и на сервере без дополнительных пакетов.
 */
@Mod.EventBusSubscriber(modid = LivingFleshMod.MODID, value = Side.CLIENT)
public class FleshBiomeFog {
    private static final Random RAND = new Random();
    private static final int SAMPLES = 160;
    private static final float RATIO_START = 0.22F; // доля заражённых среди твёрдых блоков, с которой начинается туман
    private static final float RATIO_FULL = 0.55F;  // и при которой туман максимальный

    private static float target = 0F;
    private static float intensity = 0F;
    private static int counter = 0;
    private static boolean announced = false;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = mc.player;
        World world = mc.world;
        if (player == null || world == null || mc.isGamePaused() || world.provider.getDimension() != 0) {
            target = 0F;
            intensity = Math.max(0F, intensity - 0.02F);
            return;
        }
        if (counter++ % 5 == 0) {
            target = measure(world, player);
        }
        // плавно подходим к цели: входить в туман медленно, выходить чуть быстрее
        if (intensity < target) {
            intensity = Math.min(target, intensity + 0.015F);
        } else {
            intensity = Math.max(target, intensity - 0.02F);
        }
        if (intensity > 0.5F && !announced) {
            announced = true;
            mc.ingameGUI.setOverlayMessage(Names.tr("message.livingflesh.biome_enter", "§cБиом плоти"), false);
        } else if (intensity < 0.15F) {
            announced = false;
        }
    }

    /** Возвращает 0..1: насколько местность вокруг игрока заражена. */
    private static float measure(World world, EntityPlayer player) {
        BlockPos pos = player.getPosition();
        boolean underground = player.posY < world.getHeight(pos).getY() - 4;
        float infected = 0F;
        int solid = 0;
        for (int i = 0; i < SAMPLES; i++) {
            int x = pos.getX() + RAND.nextInt(29) - 14;
            int z = pos.getZ() + RAND.nextInt(29) - 14;
            int y;
            if (underground) {
                y = pos.getY() + RAND.nextInt(15) - 7;
            } else {
                y = world.getHeight(new BlockPos(x, 0, z)).getY() - 2 + RAND.nextInt(4);
            }
            BlockPos p = new BlockPos(x, y, z);
            if (!world.isBlockLoaded(p)) {
                continue;
            }
            Block block = world.getBlockState(p).getBlock();
            if (world.isAirBlock(p)) {
                continue;
            }
            solid++;
            if (block == ModBlocks.FLESH_BLOCK || block == ModBlocks.FLESH_CORE
                    || block == ModBlocks.FLESH_STALK || block == ModBlocks.FLESH_VINE) {
                infected += 1F;
            } else if (block == ModBlocks.INFECTED_GRASS || block == ModBlocks.INFECTED_STONE
                    || block == ModBlocks.INFECTED_LOG || block == ModBlocks.INFECTED_LEAVES) {
                infected += 0.6F;
            }
        }
        if (solid < 20) {
            return 0F;
        }
        float ratio = infected / solid;
        float t = (ratio - RATIO_START) / (RATIO_FULL - RATIO_START);
        return Math.max(0F, Math.min(1F, t));
    }

    private static boolean active(EntityViewRenderEvent event) {
        return intensity > 0.03F && event.getEntity() != null
                && !event.getEntity().isInsideOfMaterial(Material.WATER)
                && !event.getEntity().isInsideOfMaterial(Material.LAVA);
    }

    @SubscribeEvent
    public static void onFogColor(EntityViewRenderEvent.FogColors event) {
        if (!active(event)) {
            return;
        }
        float k = Math.min(1F, intensity * 1.2F);
        event.setRed(event.getRed() + (0.42F - event.getRed()) * k);
        event.setGreen(event.getGreen() + (0.04F - event.getGreen()) * k);
        event.setBlue(event.getBlue() + (0.06F - event.getBlue()) * k);
    }

    @SubscribeEvent
    public static void onFogDensity(EntityViewRenderEvent.FogDensity event) {
        if (!active(event)) {
            return;
        }
        GlStateManager.setFog(GlStateManager.FogMode.EXP);
        event.setDensity(0.012F + 0.05F * intensity);
        event.setCanceled(true);
    }
}

package com.livingflesh.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/** Простая кубическая модель куска плоти в стиле ванильных мобов (текстура 32x16). */
public class ModelFleshPiece extends ModelBase {
    private final ModelRenderer body;

    public ModelFleshPiece() {
        this.textureWidth = 32;
        this.textureHeight = 16;
        this.body = new ModelRenderer(this, 0, 0);
        this.body.addBox(-4.0F, -6.0F, -4.0F, 8, 6, 8);
        this.body.setRotationPoint(0.0F, 24.0F, 0.0F);
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                       float netHeadYaw, float headPitch, float scale) {
        this.body.render(scale);
    }
}

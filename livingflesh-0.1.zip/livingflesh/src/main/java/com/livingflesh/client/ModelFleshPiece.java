package com.livingflesh.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/**
 * Модель разносчика инфекции: быстрое насекомоподобное существо размером с курицу, похожее на паука,
 * но кривое: восемь ног разной длины и толщины, лишние отростки, опухоли и жвалы. Бежит рывками, дёргается,
 * в прыжке растопыривает ноги. Земля находится на y = 24, лицо смотрит в сторону -z.
 */
public class ModelFleshPiece extends ModelBase {
    private static final int LEGS = 8;
    private final ModelRenderer thorax;
    private final ModelRenderer abdomen;
    private final ModelRenderer head;
    private final ModelRenderer mandL;
    private final ModelRenderer mandR;
    private final ModelRenderer tail1;
    private final ModelRenderer tail2;
    private final ModelRenderer[] antenna = new ModelRenderer[4]; // два уса по два сегмента
    private final ModelRenderer[] upper = new ModelRenderer[LEGS];
    private final ModelRenderer[] lower = new ModelRenderer[LEGS];
    private final float[] side = new float[LEGS];
    private final float[] spread = new float[LEGS];
    private final float[] bend = new float[LEGS];
    private final float[] baseY = new float[LEGS];

    public ModelFleshPiece() {
        this.textureWidth = 64;
        this.textureHeight = 64;

        thorax = new ModelRenderer(this, 30, 0);
        thorax.addBox(-3F, -3F, -3F, 6, 5, 6);
        thorax.setRotationPoint(0F, 16F, 0F);

        abdomen = new ModelRenderer(this, 0, 0);
        abdomen.addBox(-3.5F, -2.5F, 0F, 7, 6, 8);
        abdomen.setRotationPoint(0F, 0F, 2.5F);
        thorax.addChild(abdomen);
        box(18, 14, 2.5F, -3.5F, 2F, 3, 3, 3, abdomen);   // опухоль на спине
        box(30, 14, -4.5F, -1F, 4F, 2, 3, 3, abdomen);    // опухоль на боку
        box(18, 14, 0.5F, -5F, -1F, 3, 2, 3, thorax);     // горб на груди

        head = new ModelRenderer(this, 0, 14);
        head.addBox(-2.5F, -2F, -4F, 5, 4, 4);
        head.setRotationPoint(0F, 0.5F, -3F);
        thorax.addChild(head);
        mandL = new ModelRenderer(this, 40, 14);
        mandL.addBox(-0.5F, 0F, -3F, 1, 1, 3);
        mandL.setRotationPoint(1.5F, 1.2F, -4F);
        head.addChild(mandL);
        mandR = new ModelRenderer(this, 40, 14);
        mandR.addBox(-0.5F, 0F, -3F, 1, 1, 3);
        mandR.setRotationPoint(-1.5F, 1.2F, -4F);
        head.addChild(mandR);

        // усики: два сегмента на каждый, торчат вверх и вперёд
        for (int i = 0; i < 2; i++) {
            float sx = i == 0 ? 1.2F : -1.2F;
            antenna[i * 2] = new ModelRenderer(this, 54, 0);
            antenna[i * 2].addBox(-0.5F, -4F, -0.5F, 1, 4, 1);
            antenna[i * 2].setRotationPoint(sx, -1.8F, -3F);
            antenna[i * 2].rotateAngleX = 0.8F;
            antenna[i * 2].rotateAngleZ = i == 0 ? 0.35F : -0.35F;
            head.addChild(antenna[i * 2]);
            antenna[i * 2 + 1] = new ModelRenderer(this, 54, 0);
            antenna[i * 2 + 1].addBox(-0.5F, -5F, -0.5F, 1, 5, 1);
            antenna[i * 2 + 1].setRotationPoint(0F, -4F, 0F);
            antenna[i * 2 + 1].rotateAngleX = 0.7F;
            antenna[i * 2].addChild(antenna[i * 2 + 1]);
        }

        // шипы на спине
        spike(-1F, -3F, -1.5F, 0.3F, 0.2F);
        spike(1.5F, -3F, 0.5F, -0.2F, -0.4F);
        spike(-2F, -3F, 2F, 0.4F, 0.5F);

        // хвостик из двух сегментов
        tail1 = new ModelRenderer(this, 54, 0);
        tail1.addBox(-0.5F, 0F, -0.5F, 1, 5, 1);
        tail1.setRotationPoint(0F, 0F, 8F);
        tail1.rotateAngleX = 1.9F;
        abdomen.addChild(tail1);
        tail2 = new ModelRenderer(this, 54, 0);
        tail2.addBox(-0.5F, 0F, -0.5F, 1, 4, 1);
        tail2.setRotationPoint(0F, 5F, 0F);
        tail2.rotateAngleX = -0.8F;
        tail1.addChild(tail2);

        // лишние короткие отростки по бокам брюшка
        stub(3.5F, 1F, 4F, 1.0F);
        stub(-3.5F, 0F, 6F, -1.3F);

        // восемь ног разной длины и толщины: сторона, z, верх, низ, развал, сгиб, толщина
        float[][] legs = {            {1F, -2.5F, 4F, 6F, 1.1F, 0.9F, 1F},
            {-1F, -2.5F, 5F, 6F, 1.0F, 0.8F, 1F},
            {1F, -0.8F, 4F, 7F, 1.2F, 1.0F, 1F},
            {-1F, -0.8F, 3F, 4F, 1.3F, 0.7F, 2F},
            {1F, 0.9F, 5F, 6F, 1.1F, 0.9F, 1F},
            {-1F, 0.9F, 4F, 8F, 1.2F, 1.1F, 1F},
            {1F, 2.6F, 4F, 5F, 1.0F, 0.8F, 1F},
            {-1F, 2.6F, 6F, 6F, 0.9F, 0.7F, 1F}
        };
        for (int i = 0; i < LEGS; i++) {
            float[] p = legs[i];
            int t = (int) p[6];
            side[i] = p[0];
            spread[i] = p[4];
            bend[i] = p[5];
            upper[i] = new ModelRenderer(this, 54, 0);
            upper[i].addBox(-t / 2F, 0F, -t / 2F, t, (int) p[2], t);
            upper[i].setRotationPoint(p[0] * 3F, -0.5F, p[1]);
            thorax.addChild(upper[i]);
            lower[i] = new ModelRenderer(this, 54, 0);
            lower[i].addBox(-t / 2F, 0F, -t / 2F, t, (int) p[3], t);
            lower[i].setRotationPoint(0F, p[2], 0F);
            upper[i].addChild(lower[i]);
            baseY[i] = (i / 2 - 1.5F) * 0.5F * p[0] * -1F; // передние ноги вперёд, задние назад
        }
    }

    private ModelRenderer box(int u, int v, float x, float y, float z, int w, int h, int d, ModelRenderer parent) {
        ModelRenderer r = new ModelRenderer(this, u, v);
        r.addBox(x, y, z, w, h, d);
        parent.addChild(r);
        return r;
    }

    private void spike(float x, float y, float z, float rx, float rz) {
        ModelRenderer s = new ModelRenderer(this, 54, 0);
        s.addBox(-0.5F, -3F, -0.5F, 1, 3, 1);
        s.setRotationPoint(x, y, z);
        s.rotateAngleX = rx;
        s.rotateAngleZ = rz;
        thorax.addChild(s);
    }

    private void stub(float x, float y, float z, float rz) {
        ModelRenderer s = new ModelRenderer(this, 54, 0);
        s.addBox(-0.5F, 0F, -0.5F, 1, 3, 1);
        s.setRotationPoint(x, y, z);
        s.rotateAngleZ = rz;
        abdomen.addChild(s);
    }

    private static float hash(float n) {
        float s = MathHelper.sin(n * 12.9898F) * 43758.547F;
        return (s - (float) Math.floor(s)) * 2F - 1F;
    }

    /** Рваный сигнал: резко щёлкает к новому значению и держится до следующего щелчка. */
    private static float twitch(float t, float seed) {
        float step = (float) Math.floor(t);
        float f = t - step;
        float k = Math.min(1F, f * 5F);
        k = k * k * (3F - 2F * k);
        return hash(step + seed) * (1F - k) + hash(step + 1F + seed) * k;
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, age, yaw, pitch, scale, entity);
        thorax.render(scale);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale, Entity entity) {
        boolean air = entity != null && !entity.onGround;
        float amp = Math.min(1F, limbSwingAmount * 1.8F);
        float walk = limbSwing * 1.6F;
        float t = age * 0.5F;

        // тело подёргивается и приседает
        thorax.rotateAngleX = twitch(t, 3F) * 0.12F + (air ? -0.35F : 0F);
        thorax.rotateAngleZ = twitch(t * 0.8F, 8F) * 0.1F;
        thorax.rotateAngleY = twitch(t * 0.7F, 14F) * 0.08F + MathHelper.cos(walk) * 0.1F * amp;
        thorax.rotationPointY = 16F + MathHelper.sin(walk * 2F) * 0.8F * amp;
        abdomen.rotateAngleX = 0.2F + twitch(t * 1.1F, 21F) * 0.15F;
        abdomen.rotateAngleZ = twitch(t, 27F) * 0.1F;
        head.rotateAngleY = yaw * 0.0174533F * 0.5F + twitch(t * 1.4F, 33F) * 0.2F;
        head.rotateAngleX = pitch * 0.0174533F * 0.5F + twitch(t * 1.2F, 39F) * 0.15F;
        head.rotateAngleZ = 0.15F + twitch(t, 45F) * 0.12F;
        float open = (twitch(t * 2.2F, 51F) + 1F) * 0.25F + (air ? 0.5F : 0F);
        mandL.rotateAngleY = 0.3F + open;
        mandR.rotateAngleY = -0.3F - open;
        tail1.rotateAngleX = 1.9F + twitch(t * 1.3F, 57F) * 0.4F;
        tail2.rotateAngleX = -0.8F + twitch(t * 1.6F, 63F) * 0.5F;
        for (int i = 0; i < 2; i++) {
            float sg = i == 0 ? 1F : -1F;
            antenna[i * 2].rotateAngleX = 0.8F + twitch(t * 2.5F + i, 80F + i) * 0.45F + (air ? -0.4F : 0F);
            antenna[i * 2].rotateAngleZ = sg * 0.35F + twitch(t * 2F + i, 90F + i) * 0.35F;
            antenna[i * 2 + 1].rotateAngleX = 0.7F + twitch(t * 3F + i, 100F + i) * 0.5F;
        }

        for (int i = 0; i < LEGS; i++) {
            float phase = (i % 2 == 0 ? 0F : (float) Math.PI) + (i / 2) * 1.3F;
            float step = MathHelper.cos(walk + phase);
            float lift = Math.max(0F, MathHelper.sin(walk + phase));
            float jitter = twitch(t * 1.5F + i, 70F + i) * 0.18F;
            float out = spread[i] + (air ? 0.7F : 0F) - lift * 0.35F * amp;
            upper[i].rotateAngleZ = -side[i] * out + jitter * 0.5F;
            upper[i].rotateAngleY = baseY[i] + side[i] * step * 0.55F * amp + jitter * 0.4F;
            lower[i].rotateAngleZ = side[i] * (bend[i] + lift * 0.4F * amp) + jitter * 0.4F;
        }
    }
}

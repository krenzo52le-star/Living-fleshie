package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityArachneidef;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Рисует Арахнейдефа собственной моделью. */
public class RenderArachneidef extends RenderLiving<EntityArachneidef> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/arachneidef.png");

    public RenderArachneidef(RenderManager manager) {
        super(manager, new ModelArachneidef(), 1.3F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityArachneidef entity) {
        return TEXTURE;
    }
}

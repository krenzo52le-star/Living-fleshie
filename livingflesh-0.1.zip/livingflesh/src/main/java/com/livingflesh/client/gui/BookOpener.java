package com.livingflesh.client.gui;

import net.minecraft.client.Minecraft;

/** Отдельный класс, чтобы серверный код предмета не трогал клиентские классы. */
public final class BookOpener {
    private BookOpener() {
    }

    public static void open() {
        Minecraft.getMinecraft().displayGuiScreen(new GuiEncyclopedia());
    }
}

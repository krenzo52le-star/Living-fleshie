package com.livingflesh.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/**
 * Модель заражённого зомби (сгенерирована скриптом): сутулый, с вскрытой грудью и рёбрами, костяным гребнем на спине,
 * опухолями, свисающей челюстью, кривыми рогами, руками разной длины (левая огромная, правая тонкая),
 * лишними конечностями и двумя щупальцами. Ходит враскачку и дёргается.
 * Земля находится на y = 24, лицо смотрит в сторону -z.
 */
public class ModelInfectedZombie extends ModelBase {
    private final ModelRenderer thighL;
    private final ModelRenderer shinL;
    private final ModelRenderer footL;
    private final ModelRenderer thighR;
    private final ModelRenderer shinR;
    private final ModelRenderer footR;
    private final ModelRenderer torso;
    private final ModelRenderer spine;
    private final ModelRenderer sp1;
    private final ModelRenderer sp2;
    private final ModelRenderer sp3;
    private final ModelRenderer shoulder;
    private final ModelRenderer belly;
    private final ModelRenderer rib1;
    private final ModelRenderer rib2;
    private final ModelRenderer rib3;
    private final ModelRenderer head;
    private final ModelRenderer jaw;
    private final ModelRenderer teethU;
    private final ModelRenderer teethL;
    private final ModelRenderer cheek;
    private final ModelRenderer hornA;
    private final ModelRenderer hornB;
    private final ModelRenderer upperL;
    private final ModelRenderer foreL;
    private final ModelRenderer clawL1;
    private final ModelRenderer clawL2;
    private final ModelRenderer clawL3;
    private final ModelRenderer upperR;
    private final ModelRenderer foreR;
    private final ModelRenderer clawR1;
    private final ModelRenderer clawR2;
    private final ModelRenderer xarmA;
    private final ModelRenderer xarmA2;
    private final ModelRenderer xarmB;
    private final ModelRenderer tentL1;
    private final ModelRenderer tentL2;
    private final ModelRenderer tentR1;
    private final ModelRenderer tentR2;

    public ModelInfectedZombie() {
        this.textureWidth = 128;
        this.textureHeight = 128;

        thighL = new ModelRenderer(this, 0, 17);
        thighL.addBox(-2F, 0F, -2F, 4, 6, 4);
        thighL.setRotationPoint(2.8F, 12F, 0F);
        thighL.rotateAngleX = 0F; thighL.rotateAngleY = 0F; thighL.rotateAngleZ = -0.05F;
        shinL = new ModelRenderer(this, 40, 17);
        shinL.addBox(-2F, 0F, -2F, 4, 6, 4);
        shinL.setRotationPoint(0F, 6F, 0F);
        shinL.rotateAngleX = 0.1F; shinL.rotateAngleY = 0F; shinL.rotateAngleZ = 0F;
        thighL.addChild(shinL);
        footL = new ModelRenderer(this, 76, 17);
        footL.addBox(-2F, 4F, -4F, 4, 2, 6);
        footL.setRotationPoint(0F, 0F, 0F);
        shinL.addChild(footL);
        thighR = new ModelRenderer(this, 0, 17);
        thighR.addBox(-1.5F, 0F, -1.5F, 3, 7, 3);
        thighR.setRotationPoint(-2.8F, 12F, 0F);
        thighR.rotateAngleX = -0.45F; thighR.rotateAngleY = 0F; thighR.rotateAngleZ = 0.1F;
        shinR = new ModelRenderer(this, 40, 17);
        shinR.addBox(-1.5F, 0F, -1.5F, 3, 6, 3);
        shinR.setRotationPoint(0F, 7F, 0F);
        shinR.rotateAngleX = 0.9F; shinR.rotateAngleY = 0F; shinR.rotateAngleZ = 0F;
        thighR.addChild(shinR);
        footR = new ModelRenderer(this, 76, 17);
        footR.addBox(-2F, 4F, -4F, 4, 2, 6);
        footR.setRotationPoint(0F, 0F, 0F);
        footR.rotateAngleX = 0F; footR.rotateAngleY = 0.3F; footR.rotateAngleZ = 0F;
        shinR.addChild(footR);
        torso = new ModelRenderer(this, 0, 0);
        torso.addBox(-4.5F, -12F, -2.5F, 9, 12, 5);
        torso.setRotationPoint(0F, 12F, 0F);
        torso.rotateAngleX = 0.35F; torso.rotateAngleY = 0F; torso.rotateAngleZ = 0.1F;
        spine = new ModelRenderer(this, 60, 0);
        spine.addBox(-1F, -12F, 2.5F, 2, 11, 2);
        spine.setRotationPoint(0F, 0F, 0F);
        torso.addChild(spine);
        sp1 = new ModelRenderer(this, 116, 17);
        sp1.addBox(-0.5F, -4F, 2.7F, 1, 4, 1);
        sp1.setRotationPoint(0F, -9F, 2F);
        sp1.rotateAngleX = 0.5F; sp1.rotateAngleY = 0F; sp1.rotateAngleZ = 0.1F;
        torso.addChild(sp1);
        sp2 = new ModelRenderer(this, 116, 17);
        sp2.addBox(-0.5F, -4F, 2.7F, 1, 4, 1);
        sp2.setRotationPoint(0F, -6F, 2F);
        sp2.rotateAngleX = 0.6F; sp2.rotateAngleY = 0F; sp2.rotateAngleZ = -0.2F;
        torso.addChild(sp2);
        sp3 = new ModelRenderer(this, 116, 17);
        sp3.addBox(-0.5F, -4F, 2.7F, 1, 4, 1);
        sp3.setRotationPoint(0F, -3F, 2F);
        sp3.rotateAngleX = 0.5F; sp3.rotateAngleY = 0F; sp3.rotateAngleZ = 0.2F;
        torso.addChild(sp3);
        shoulder = new ModelRenderer(this, 104, 0);
        shoulder.addBox(4.5F, -13F, -3F, 5, 5, 6);
        shoulder.setRotationPoint(0F, 0F, 0F);
        torso.addChild(shoulder);
        belly = new ModelRenderer(this, 104, 17);
        belly.addBox(-2F, -4F, -4.5F, 4, 4, 2);
        belly.setRotationPoint(0F, 0F, 0F);
        torso.addChild(belly);
        rib1 = new ModelRenderer(this, 0, 28);
        rib1.addBox(-4F, -9F, -3.4F, 8, 1, 1);
        rib1.setRotationPoint(0F, 0F, 0F);
        torso.addChild(rib1);
        rib2 = new ModelRenderer(this, 0, 28);
        rib2.addBox(-4F, -7F, -3.4F, 8, 1, 1);
        rib2.setRotationPoint(0F, 0F, 0F);
        torso.addChild(rib2);
        rib3 = new ModelRenderer(this, 0, 28);
        rib3.addBox(-3.5F, -5F, -3.4F, 7, 1, 1);
        rib3.setRotationPoint(0F, 0F, 0F);
        torso.addChild(rib3);
        head = new ModelRenderer(this, 28, 0);
        head.addBox(-4F, -8F, -4F, 8, 8, 8);
        head.setRotationPoint(0F, -12F, -1F);
        head.rotateAngleX = 0.5F; head.rotateAngleY = 0.1F; head.rotateAngleZ = 0.25F;
        torso.addChild(head);
        jaw = new ModelRenderer(this, 16, 17);
        jaw.addBox(-3F, 0F, -4F, 6, 4, 6);
        jaw.setRotationPoint(0F, 0F, 0F);
        jaw.rotateAngleX = 0.5F; jaw.rotateAngleY = 0F; jaw.rotateAngleZ = 0F;
        head.addChild(jaw);
        teethU = new ModelRenderer(this, 18, 28);
        teethU.addBox(-3F, -0.5F, -4.4F, 6, 1, 1);
        teethU.setRotationPoint(0F, 0F, 0F);
        head.addChild(teethU);
        teethL = new ModelRenderer(this, 18, 28);
        teethL.addBox(-3F, 0.2F, -4.4F, 6, 1, 1);
        teethL.setRotationPoint(0F, 0F, 0F);
        jaw.addChild(teethL);
        cheek = new ModelRenderer(this, 64, 17);
        cheek.addBox(-5.5F, -4F, -3F, 2, 4, 4);
        cheek.setRotationPoint(0F, 0F, 0F);
        head.addChild(cheek);
        hornA = new ModelRenderer(this, 116, 17);
        hornA.addBox(-0.5F, -4F, -0.5F, 1, 4, 1);
        hornA.setRotationPoint(2F, -8F, -1F);
        hornA.rotateAngleX = 0F; hornA.rotateAngleY = 0F; hornA.rotateAngleZ = 0.45F;
        head.addChild(hornA);
        hornB = new ModelRenderer(this, 116, 17);
        hornB.addBox(-0.5F, -3F, -0.5F, 1, 3, 1);
        hornB.setRotationPoint(-2.5F, -8F, -2F);
        hornB.rotateAngleX = 0.2F; hornB.rotateAngleY = 0F; hornB.rotateAngleZ = -0.5F;
        head.addChild(hornB);
        upperL = new ModelRenderer(this, 68, 0);
        upperL.addBox(-2.5F, 0F, -2.5F, 5, 8, 5);
        upperL.setRotationPoint(7F, -10F, 0F);
        upperL.rotateAngleX = -1.4F; upperL.rotateAngleY = 0F; upperL.rotateAngleZ = -0.1F;
        torso.addChild(upperL);
        foreL = new ModelRenderer(this, 88, 0);
        foreL.addBox(-2F, 0F, -2F, 4, 9, 4);
        foreL.setRotationPoint(0F, 8F, 0F);
        foreL.rotateAngleX = -0.2F; foreL.rotateAngleY = 0F; foreL.rotateAngleZ = 0F;
        upperL.addChild(foreL);
        clawL1 = new ModelRenderer(this, 116, 17);
        clawL1.addBox(-1.5F, 9F, -1.5F, 1, 3, 1);
        clawL1.setRotationPoint(0F, 0F, 0F);
        foreL.addChild(clawL1);
        clawL2 = new ModelRenderer(this, 116, 17);
        clawL2.addBox(0.5F, 9F, -1.5F, 1, 3, 1);
        clawL2.setRotationPoint(0F, 0F, 0F);
        foreL.addChild(clawL2);
        clawL3 = new ModelRenderer(this, 116, 17);
        clawL3.addBox(-0.5F, 9F, 1F, 1, 3, 1);
        clawL3.setRotationPoint(0F, 0F, 0F);
        foreL.addChild(clawL3);
        upperR = new ModelRenderer(this, 68, 0);
        upperR.addBox(-1.5F, 0F, -1.5F, 3, 6, 3);
        upperR.setRotationPoint(-5.5F, -9F, 0F);
        upperR.rotateAngleX = -1.0F; upperR.rotateAngleY = 0F; upperR.rotateAngleZ = 0.15F;
        torso.addChild(upperR);
        foreR = new ModelRenderer(this, 88, 0);
        foreR.addBox(-1F, 0F, -1F, 2, 6, 2);
        foreR.setRotationPoint(0F, 6F, 0F);
        foreR.rotateAngleX = -0.9F; foreR.rotateAngleY = 0F; foreR.rotateAngleZ = 0F;
        upperR.addChild(foreR);
        clawR1 = new ModelRenderer(this, 116, 17);
        clawR1.addBox(-1F, 6F, -1F, 1, 3, 1);
        clawR1.setRotationPoint(0F, 0F, 0F);
        foreR.addChild(clawR1);
        clawR2 = new ModelRenderer(this, 116, 17);
        clawR2.addBox(0F, 6F, -1F, 1, 3, 1);
        clawR2.setRotationPoint(0F, 0F, 0F);
        foreR.addChild(clawR2);
        xarmA = new ModelRenderer(this, 56, 17);
        xarmA.addBox(-1F, 0F, -1F, 2, 7, 2);
        xarmA.setRotationPoint(-4.5F, -4F, -1F);
        xarmA.rotateAngleX = 0.1F; xarmA.rotateAngleY = 0F; xarmA.rotateAngleZ = -0.5F;
        torso.addChild(xarmA);
        xarmA2 = new ModelRenderer(this, 56, 17);
        xarmA2.addBox(-1F, 0F, -1F, 2, 6, 2);
        xarmA2.setRotationPoint(0F, 7F, 0F);
        xarmA2.rotateAngleX = 0.5F; xarmA2.rotateAngleY = 0F; xarmA2.rotateAngleZ = -0.2F;
        xarmA.addChild(xarmA2);
        xarmB = new ModelRenderer(this, 56, 17);
        xarmB.addBox(-1F, 0F, -1F, 2, 6, 2);
        xarmB.setRotationPoint(3F, -10F, 2.5F);
        xarmB.rotateAngleX = 0.6F; xarmB.rotateAngleY = 0F; xarmB.rotateAngleZ = 1.0F;
        torso.addChild(xarmB);
        tentL1 = new ModelRenderer(this, 96, 17);
        tentL1.addBox(-1F, 0F, -1F, 2, 6, 2);
        tentL1.setRotationPoint(2F, -11F, 2.5F);
        tentL1.rotateAngleX = 0.9F; tentL1.rotateAngleY = 0F; tentL1.rotateAngleZ = 0.5F;
        torso.addChild(tentL1);
        tentL2 = new ModelRenderer(this, 96, 17);
        tentL2.addBox(-1F, 0F, -1F, 2, 5, 2);
        tentL2.setRotationPoint(0F, 6F, 0F);
        tentL2.rotateAngleX = 0.4F; tentL2.rotateAngleY = 0F; tentL2.rotateAngleZ = 0.2F;
        tentL1.addChild(tentL2);
        tentR1 = new ModelRenderer(this, 96, 17);
        tentR1.addBox(-1F, 0F, -1F, 2, 6, 2);
        tentR1.setRotationPoint(-2F, -8F, 2.5F);
        tentR1.rotateAngleX = 0.7F; tentR1.rotateAngleY = 0F; tentR1.rotateAngleZ = -0.6F;
        torso.addChild(tentR1);
        tentR2 = new ModelRenderer(this, 96, 17);
        tentR2.addBox(-1F, 0F, -1F, 2, 5, 2);
        tentR2.setRotationPoint(0F, 6F, 0F);
        tentR2.rotateAngleX = 0.4F; tentR2.rotateAngleY = 0F; tentR2.rotateAngleZ = -0.2F;
        tentR1.addChild(tentR2);
    }

    private static float hash(float n) {
        float s = MathHelper.sin(n * 12.9898F) * 43758.547F;
        return (s - (float) Math.floor(s)) * 2F - 1F;
    }

    /** Рваный сигнал: резко щёлкает к новому значению и держится до следующего щелчка. */
    private static float twitch(float t, float seed) {
        float step = (float) Math.floor(t);
        float f = t - step;
        float k = Math.min(1F, f * 5F);
        k = k * k * (3F - 2F * k);
        return hash(step + seed) * (1F - k) + hash(step + 1F + seed) * k;
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, age, yaw, pitch, scale, entity);
        thighL.render(scale);
        thighR.render(scale);
        torso.render(scale);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale, Entity entity) {
        float walk = limbSwing * 0.6F;
        float amp = Math.min(1F, limbSwingAmount * 1.5F);
        float t = age * 0.3F;

        // походка враскачку: левая нога тяжёлая, правая подгибается
        thighL.rotateAngleX = MathHelper.cos(walk) * 0.9F * amp;
        thighR.rotateAngleX = -0.45F + MathHelper.cos(walk + (float) Math.PI) * 0.6F * amp;
        shinL.rotateAngleX = 0.1F + Math.max(0F, -MathHelper.cos(walk)) * 0.6F * amp;
        shinR.rotateAngleX = 0.9F + Math.max(0F, MathHelper.cos(walk)) * 0.5F * amp;
        footR.rotateAngleY = 0.3F + twitch(t * 2F, 3F) * 0.15F * amp;

        // тело кренится и дёргается
        torso.rotateAngleX = 0.35F + twitch(t, 9F) * 0.07F + MathHelper.cos(walk * 2F) * 0.04F * amp;
        torso.rotateAngleZ = 0.1F + MathHelper.cos(walk) * 0.1F * amp + twitch(t * 0.8F, 15F) * 0.05F;
        torso.rotateAngleY = twitch(t * 0.7F, 21F) * 0.1F + MathHelper.cos(walk) * 0.12F * amp;
        torso.rotationPointY = 12F + Math.abs(MathHelper.cos(walk)) * 0.8F * amp;
        shoulder.rotateAngleZ = twitch(t * 1.4F, 27F) * 0.07F;
        belly.rotateAngleX = twitch(t * 1.1F, 33F) * 0.1F;

        // голова мотается, челюсть ходит
        head.rotateAngleX = 0.5F + pitch * 0.0174533F * 0.4F + twitch(t * 1.2F, 39F) * 0.2F;
        head.rotateAngleY = 0.1F + yaw * 0.0174533F * 0.5F + twitch(t * 1.4F, 45F) * 0.2F;
        head.rotateAngleZ = 0.25F + twitch(t * 1.1F, 51F) * 0.15F;
        jaw.rotateAngleX = 0.5F + (twitch(t * 2.2F, 57F) + 1F) * 0.35F;

        // руки вытянуты вперёд и подёргиваются
        upperL.rotateAngleX = -1.4F + twitch(t * 1.3F, 63F) * 0.2F + MathHelper.sin(age * 0.067F) * 0.05F;
        upperL.rotateAngleZ = -0.1F + twitch(t, 69F) * 0.1F;
        foreL.rotateAngleX = -0.2F + twitch(t * 1.6F, 75F) * 0.25F;
        upperR.rotateAngleX = -1.0F + twitch(t * 1.5F, 81F) * 0.3F;
        foreR.rotateAngleX = -0.9F + twitch(t * 2F, 87F) * 0.4F;

        // лишние конечности и щупальца
        xarmA.rotateAngleX = 0.1F + twitch(t * 2F, 93F) * 0.5F;
        xarmA2.rotateAngleX = 0.5F + twitch(t * 2.6F, 99F) * 0.6F;
        xarmB.rotateAngleX = 0.6F + twitch(t * 2.2F, 105F) * 0.6F;
        xarmB.rotateAngleZ = 1.0F + twitch(t * 1.8F, 111F) * 0.4F;
        tentL1.rotateAngleX = 0.9F + twitch(t * 1.9F, 117F) * 0.4F;
        tentL1.rotateAngleZ = 0.5F + twitch(t * 1.5F, 123F) * 0.4F;
        tentL2.rotateAngleX = 0.4F + twitch(t * 2.4F, 129F) * 0.5F;
        tentR1.rotateAngleX = 0.7F + twitch(t * 1.9F, 135F) * 0.4F;
        tentR1.rotateAngleZ = -0.6F + twitch(t * 1.5F, 141F) * 0.4F;
        tentR2.rotateAngleX = 0.4F + twitch(t * 2.4F, 147F) * 0.5F;
    }
}

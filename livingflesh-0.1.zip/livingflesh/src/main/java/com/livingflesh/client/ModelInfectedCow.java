package com.livingflesh.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/**
 * Модель заражённой коровы (сгенерирована скриптом): сутулое тело с открытыми рёбрами и костяным гребнем,
 * опухоли, длинная шея и тяжёлая голова с кривыми рогами, ноги разной длины (одна коротко-толстая, задняя
 * выгнута назад), два щупальца на спине и костяной хвост. Движется рывками.
 * Земля находится на y = 24, лицо смотрит в сторону -z.
 */
public class ModelInfectedCow extends ModelBase {
    private final ModelRenderer body;
    private final ModelRenderer thighFL;
    private final ModelRenderer shinFL;
    private final ModelRenderer hoofFL;
    private final ModelRenderer thighFR;
    private final ModelRenderer shinFR;
    private final ModelRenderer clawFR;
    private final ModelRenderer thighRL;
    private final ModelRenderer shinRL;
    private final ModelRenderer hoofRL;
    private final ModelRenderer thighRR;
    private final ModelRenderer shinRR;
    private final ModelRenderer spine;
    private final ModelRenderer sp1;
    private final ModelRenderer sp2;
    private final ModelRenderer sp3;
    private final ModelRenderer shoulder;
    private final ModelRenderer belly;
    private final ModelRenderer hip;
    private final ModelRenderer neck;
    private final ModelRenderer head;
    private final ModelRenderer snout;
    private final ModelRenderer jaw;
    private final ModelRenderer teethU;
    private final ModelRenderer teethL;
    private final ModelRenderer hornL;
    private final ModelRenderer hornR;
    private final ModelRenderer earL;
    private final ModelRenderer earR;
    private final ModelRenderer eye;
    private final ModelRenderer tail;
    private final ModelRenderer tailTip;
    private final ModelRenderer tentL1;
    private final ModelRenderer tentL2;
    private final ModelRenderer tentR1;
    private final ModelRenderer tentR2;
    private final ModelRenderer xlegA;
    private final ModelRenderer xlegB;
    private final ModelRenderer xlegC;

    public ModelInfectedCow() {
        this.textureWidth = 128;
        this.textureHeight = 128;

        body = new ModelRenderer(this, 0, 0);
        body.addBox(-6F, -5F, -8F, 12, 10, 18);
        body.setRotationPoint(0F, 8F, 0F);
        thighFL = new ModelRenderer(this, 0, 28);
        thighFL.addBox(-2F, 0F, -2F, 4, 6, 4);
        thighFL.setRotationPoint(4.5F, 12F, -5F);
        shinFL = new ModelRenderer(this, 24, 28);
        shinFL.addBox(-1.5F, 0F, -1.5F, 3, 6, 3);
        shinFL.setRotationPoint(0F, 6F, 0F);
        thighFL.addChild(shinFL);
        hoofFL = new ModelRenderer(this, 54, 41);
        hoofFL.addBox(-2F, 4F, -3F, 4, 2, 5);
        hoofFL.setRotationPoint(0F, 0F, 0F);
        shinFL.addChild(hoofFL);
        thighFR = new ModelRenderer(this, 0, 28);
        thighFR.addBox(-1.5F, 0F, -1.5F, 3, 7, 3);
        thighFR.setRotationPoint(-4.5F, 12F, -5F);
        thighFR.rotateAngleX = -0.35F; thighFR.rotateAngleY = 0F; thighFR.rotateAngleZ = 0.08F;
        shinFR = new ModelRenderer(this, 24, 28);
        shinFR.addBox(-1.5F, 0F, -1.5F, 3, 6, 3);
        shinFR.setRotationPoint(0F, 7F, 0F);
        shinFR.rotateAngleX = 0.8F; shinFR.rotateAngleY = 0F; shinFR.rotateAngleZ = -0.08F;
        thighFR.addChild(shinFR);
        clawFR = new ModelRenderer(this, 110, 41);
        clawFR.addBox(-0.5F, 4F, -3F, 1, 3, 1);
        clawFR.setRotationPoint(0F, 0F, 0F);
        shinFR.addChild(clawFR);
        thighRL = new ModelRenderer(this, 0, 28);
        thighRL.addBox(-2.5F, 0F, -2F, 5, 7, 5);
        thighRL.setRotationPoint(4.5F, 12F, 7F);
        thighRL.rotateAngleX = -0.5F; thighRL.rotateAngleY = 0F; thighRL.rotateAngleZ = 0F;
        shinRL = new ModelRenderer(this, 24, 28);
        shinRL.addBox(-1.5F, 0F, -1.5F, 3, 6, 3);
        shinRL.setRotationPoint(0F, 7F, 0F);
        shinRL.rotateAngleX = 1.0F; shinRL.rotateAngleY = 0F; shinRL.rotateAngleZ = 0F;
        thighRL.addChild(shinRL);
        hoofRL = new ModelRenderer(this, 54, 41);
        hoofRL.addBox(-2F, 4F, -3F, 4, 2, 5);
        hoofRL.setRotationPoint(0F, 0F, 0F);
        shinRL.addChild(hoofRL);
        thighRR = new ModelRenderer(this, 0, 28);
        thighRR.addBox(-3F, 0F, -3F, 6, 6, 6);
        thighRR.setRotationPoint(-4.5F, 12F, 7F);
        shinRR = new ModelRenderer(this, 24, 28);
        shinRR.addBox(-2.5F, 0F, -2.5F, 5, 6, 5);
        shinRR.setRotationPoint(0F, 6F, 0F);
        thighRR.addChild(shinRR);
        spine = new ModelRenderer(this, 60, 0);
        spine.addBox(-1.5F, -8F, -6F, 3, 3, 14);
        spine.setRotationPoint(0F, 0F, 0F);
        body.addChild(spine);
        sp1 = new ModelRenderer(this, 110, 41);
        sp1.addBox(-0.5F, -11F, -4F, 1, 3, 1);
        sp1.setRotationPoint(0F, 0F, 0F);
        sp1.rotateAngleX = 0.2F; sp1.rotateAngleY = 0F; sp1.rotateAngleZ = 0.1F;
        body.addChild(sp1);
        sp2 = new ModelRenderer(this, 110, 41);
        sp2.addBox(-0.5F, -11F, 0F, 1, 3, 1);
        sp2.setRotationPoint(0F, 0F, 0F);
        sp2.rotateAngleX = -0.1F; sp2.rotateAngleY = 0F; sp2.rotateAngleZ = -0.2F;
        body.addChild(sp2);
        sp3 = new ModelRenderer(this, 110, 41);
        sp3.addBox(-0.5F, -11F, 4F, 1, 3, 1);
        sp3.setRotationPoint(0F, 0F, 0F);
        sp3.rotateAngleX = 0.25F; sp3.rotateAngleY = 0F; sp3.rotateAngleZ = 0.2F;
        body.addChild(sp3);
        shoulder = new ModelRenderer(this, 44, 28);
        shoulder.addBox(3F, -8F, -8F, 6, 5, 6);
        shoulder.setRotationPoint(0F, 0F, 0F);
        body.addChild(shoulder);
        belly = new ModelRenderer(this, 68, 28);
        belly.addBox(-3F, 5F, 0F, 5, 4, 7);
        belly.setRotationPoint(0F, 0F, 0F);
        body.addChild(belly);
        hip = new ModelRenderer(this, 44, 28);
        hip.addBox(-9F, -4F, 5F, 3, 5, 5);
        hip.setRotationPoint(0F, 0F, 0F);
        body.addChild(hip);
        neck = new ModelRenderer(this, 92, 28);
        neck.addBox(-3.5F, -3.5F, -4F, 7, 7, 4);
        neck.setRotationPoint(0F, -1F, -8F);
        neck.rotateAngleX = 0.25F; neck.rotateAngleY = 0F; neck.rotateAngleZ = 0F;
        body.addChild(neck);
        head = new ModelRenderer(this, 94, 0);
        head.addBox(-5F, -4.5F, -7F, 10, 9, 7);
        head.setRotationPoint(0F, 0F, -4F);
        head.rotateAngleX = 0.15F; head.rotateAngleY = 0.15F; head.rotateAngleZ = 0.2F;
        neck.addChild(head);
        snout = new ModelRenderer(this, 76, 41);
        snout.addBox(-3F, 0.5F, -9F, 6, 4, 2);
        snout.setRotationPoint(0F, 0F, 0F);
        head.addChild(snout);
        jaw = new ModelRenderer(this, 0, 41);
        jaw.addBox(-3.5F, 0F, -8F, 7, 3, 8);
        jaw.setRotationPoint(0F, 3.5F, 0F);
        jaw.rotateAngleX = 0.7F; jaw.rotateAngleY = 0F; jaw.rotateAngleZ = 0F;
        head.addChild(jaw);
        teethU = new ModelRenderer(this, 114, 41);
        teethU.addBox(-3F, 4.5F, -9F, 6, 1, 1);
        teethU.setRotationPoint(0F, 0F, 0F);
        head.addChild(teethU);
        teethL = new ModelRenderer(this, 114, 41);
        teethL.addBox(-3F, -1F, -8.5F, 6, 1, 1);
        teethL.setRotationPoint(0F, 0F, 0F);
        jaw.addChild(teethL);
        hornL = new ModelRenderer(this, 38, 41);
        hornL.addBox(-1F, -7F, -1F, 2, 7, 2);
        hornL.setRotationPoint(4F, -4F, -2F);
        hornL.rotateAngleX = 0F; hornL.rotateAngleY = 0F; hornL.rotateAngleZ = -0.6F;
        head.addChild(hornL);
        hornR = new ModelRenderer(this, 38, 41);
        hornR.addBox(-1F, -3F, -1F, 2, 3, 2);
        hornR.setRotationPoint(-4F, -4F, -2F);
        hornR.rotateAngleX = 0F; hornR.rotateAngleY = 0F; hornR.rotateAngleZ = 0.9F;
        head.addChild(hornR);
        earL = new ModelRenderer(this, 92, 41);
        earL.addBox(-1.5F, 0F, -0.5F, 3, 4, 1);
        earL.setRotationPoint(5F, -3F, -1F);
        earL.rotateAngleX = 0F; earL.rotateAngleY = 0F; earL.rotateAngleZ = -1.2F;
        head.addChild(earL);
        earR = new ModelRenderer(this, 92, 41);
        earR.addBox(-1.5F, 0F, -0.5F, 3, 2, 1);
        earR.setRotationPoint(-5F, -3F, -1F);
        earR.rotateAngleX = 0F; earR.rotateAngleY = 0F; earR.rotateAngleZ = 1.0F;
        head.addChild(earR);
        eye = new ModelRenderer(this, 100, 41);
        eye.addBox(3.5F, -3.5F, -7.6F, 3, 3, 2);
        eye.setRotationPoint(0F, 0F, 0F);
        head.addChild(eye);
        tail = new ModelRenderer(this, 72, 41);
        tail.addBox(-0.5F, 0F, -0.5F, 1, 6, 1);
        tail.setRotationPoint(0F, -3F, 10F);
        tail.rotateAngleX = 0.8F; tail.rotateAngleY = 0F; tail.rotateAngleZ = 0F;
        body.addChild(tail);
        tailTip = new ModelRenderer(this, 110, 41);
        tailTip.addBox(-0.5F, 6F, -0.5F, 1, 3, 1);
        tailTip.setRotationPoint(0F, 0F, 0F);
        tail.addChild(tailTip);
        tentL1 = new ModelRenderer(this, 46, 41);
        tentL1.addBox(-1F, 0F, -1F, 2, 6, 2);
        tentL1.setRotationPoint(3F, -5F, 3F);
        tentL1.rotateAngleX = 0.3F; tentL1.rotateAngleY = 0F; tentL1.rotateAngleZ = 0.8F;
        body.addChild(tentL1);
        tentL2 = new ModelRenderer(this, 46, 41);
        tentL2.addBox(-1F, 0F, -1F, 2, 5, 2);
        tentL2.setRotationPoint(0F, 6F, 0F);
        tentL2.rotateAngleX = 0.4F; tentL2.rotateAngleY = 0F; tentL2.rotateAngleZ = 0.2F;
        tentL1.addChild(tentL2);
        tentR1 = new ModelRenderer(this, 46, 41);
        tentR1.addBox(-1F, 0F, -1F, 2, 6, 2);
        tentR1.setRotationPoint(-3F, -5F, 5F);
        tentR1.rotateAngleX = -0.2F; tentR1.rotateAngleY = 0F; tentR1.rotateAngleZ = -0.9F;
        body.addChild(tentR1);
        tentR2 = new ModelRenderer(this, 46, 41);
        tentR2.addBox(-1F, 0F, -1F, 2, 5, 2);
        tentR2.setRotationPoint(0F, 6F, 0F);
        tentR2.rotateAngleX = 0.4F; tentR2.rotateAngleY = 0F; tentR2.rotateAngleZ = -0.2F;
        tentR1.addChild(tentR2);
        xlegA = new ModelRenderer(this, 30, 41);
        xlegA.addBox(-1F, 0F, -1F, 2, 8, 2);
        xlegA.setRotationPoint(-6F, 3F, -2F);
        xlegA.rotateAngleX = 0F; xlegA.rotateAngleY = 0F; xlegA.rotateAngleZ = -0.6F;
        body.addChild(xlegA);
        xlegB = new ModelRenderer(this, 30, 41);
        xlegB.addBox(-1F, 0F, -1F, 2, 6, 2);
        xlegB.setRotationPoint(0F, 8F, 0F);
        xlegB.rotateAngleX = 0.5F; xlegB.rotateAngleY = 0F; xlegB.rotateAngleZ = 0.3F;
        xlegA.addChild(xlegB);
        xlegC = new ModelRenderer(this, 30, 41);
        xlegC.addBox(-1F, 0F, -1F, 2, 5, 2);
        xlegC.setRotationPoint(6F, -2F, 6F);
        xlegC.rotateAngleX = 0.2F; xlegC.rotateAngleY = 0F; xlegC.rotateAngleZ = 1.3F;
        body.addChild(xlegC);
    }

    private static float hash(float n) {
        float s = MathHelper.sin(n * 12.9898F) * 43758.547F;
        return (s - (float) Math.floor(s)) * 2F - 1F;
    }

    /** Рваный сигнал: резко щёлкает к новому значению и держится до следующего щелчка. */
    private static float twitch(float t, float seed) {
        float step = (float) Math.floor(t);
        float f = t - step;
        float k = Math.min(1F, f * 5F);
        k = k * k * (3F - 2F * k);
        return hash(step + seed) * (1F - k) + hash(step + 1F + seed) * k;
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, age, yaw, pitch, scale, entity);
        body.render(scale);
        thighFL.render(scale);
        thighFR.render(scale);
        thighRL.render(scale);
        thighRR.render(scale);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale, Entity entity) {
        float walk = limbSwing * 0.6662F;
        float amp = Math.min(1F, limbSwingAmount * 1.5F);
        float t = age * 0.22F;

        // ноги: хромая ходьба, короткая правая задняя почти не гнётся
        thighFL.rotateAngleX = MathHelper.cos(walk) * 1.0F * amp;
        thighFR.rotateAngleX = MathHelper.cos(walk + (float) Math.PI) * 0.8F * amp + twitch(t * 3F, 3F) * 0.15F * amp;
        thighRL.rotateAngleX = -0.5F + MathHelper.cos(walk + (float) Math.PI) * 0.9F * amp;
        thighRR.rotateAngleX = MathHelper.cos(walk) * 0.35F * amp;
        shinFL.rotateAngleX = Math.max(0F, -MathHelper.cos(walk)) * 0.6F * amp;
        shinFR.rotateAngleX = Math.max(0F, MathHelper.cos(walk)) * 0.5F * amp;
        shinRL.rotateAngleX = 1.0F + Math.max(0F, MathHelper.cos(walk)) * 0.5F * amp;

        // тело подрагивает и хромает
        body.rotateAngleZ = MathHelper.cos(walk) * 0.07F * amp + twitch(t, 11F) * 0.04F;
        body.rotateAngleX = twitch(t * 0.8F, 17F) * 0.05F;
        body.rotationPointY = 8F + Math.abs(MathHelper.cos(walk)) * 0.8F * amp;
        shoulder.rotateAngleZ = twitch(t * 1.5F, 23F) * 0.06F;
        belly.rotateAngleX = twitch(t * 1.2F, 29F) * 0.08F;

        // шея и голова
        neck.rotateAngleX = 0.25F + pitch * 0.0174533F * 0.3F + twitch(t * 1.1F, 35F) * 0.12F;
        neck.rotateAngleY = yaw * 0.0174533F * 0.4F + twitch(t * 0.9F, 41F) * 0.12F;
        head.rotateAngleX = 0.15F + twitch(t * 1.4F, 47F) * 0.15F;
        head.rotateAngleZ = 0.2F + twitch(t * 1.2F, 53F) * 0.1F;
        jaw.rotateAngleX = 0.45F + (twitch(t * 2.2F, 59F) + 1F) * 0.3F;

        // хвост и щупальца
        tail.rotateAngleX = 0.8F + twitch(t * 1.3F, 65F) * 0.4F;
        tentL1.rotateAngleZ = 0.8F + twitch(t * 2F, 71F) * 0.4F;
        tentL1.rotateAngleX = 0.3F + twitch(t * 1.7F, 77F) * 0.4F;
        tentL2.rotateAngleX = 0.4F + twitch(t * 2.4F, 83F) * 0.5F;
        tentR1.rotateAngleZ = -0.9F + twitch(t * 2F, 89F) * 0.4F;
        tentR1.rotateAngleX = -0.2F + twitch(t * 1.7F, 95F) * 0.4F;
        tentR2.rotateAngleX = 0.4F + twitch(t * 2.4F, 101F) * 0.5F;
        xlegA.rotateAngleX = twitch(t * 2F, 107F) * 0.5F;
        xlegA.rotateAngleZ = -0.6F + twitch(t * 1.6F, 113F) * 0.3F;
        xlegB.rotateAngleX = 0.5F + twitch(t * 2.6F, 119F) * 0.6F;
        xlegC.rotateAngleX = 0.2F + twitch(t * 2.2F, 125F) * 0.6F;
        earL.rotateAngleZ = -1.2F + twitch(t * 2.5F, 131F) * 0.3F;
        earR.rotateAngleZ = 1.0F + twitch(t * 2.9F, 137F) * 0.35F;
    }
}

package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityInfectedPig;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Рисует заражённую свинью собственной моделью. */
public class RenderInfectedPig extends RenderLiving<EntityInfectedPig> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_pig.png");

    public RenderInfectedPig(RenderManager manager) {
        super(manager, new ModelInfectedPig(), 0.5F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityInfectedPig entity) {
        return TEXTURE;
    }
}

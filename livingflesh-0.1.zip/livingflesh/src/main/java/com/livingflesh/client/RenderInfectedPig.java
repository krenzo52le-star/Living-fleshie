package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPig;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.util.ResourceLocation;

/** Ванильная модель свиньи с заражённым скином. */
public class RenderInfectedPig extends RenderPig {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_pig.png");

    public RenderInfectedPig(RenderManager manager) {
        super(manager);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityPig entity) {
        return TEXTURE;
    }
}

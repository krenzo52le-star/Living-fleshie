package com.livingflesh.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

/**
 * Модель заражённого жителя. Сгенерирована скриптом по описанию частей: сутулое тело, свисающая голова с большим носом,
 * подвижная челюсть, пасть в груди, длинные руки с когтями и два щупальца на спине.
 * Земля находится на y = 24, лицевая сторона смотрит в сторону -z.
 */
public class ModelInfectedVillager extends ModelBase {
    /** Общий размер: исходная модель крупная, уменьшаем до роста жителя (около 2 блоков). */
    private static final float MODEL_SCALE = 0.75F;

    private final ModelRenderer root = new ModelRenderer(this, 0, 0);
    private final ModelRenderer thighL;
    private final ModelRenderer shinL;
    private final ModelRenderer footL;
    private final ModelRenderer thighR;
    private final ModelRenderer shinR;
    private final ModelRenderer footR;
    private final ModelRenderer pelvis;
    private final ModelRenderer body;
    private final ModelRenderer lowerTorso;
    private final ModelRenderer chest;
    private final ModelRenderer chestBox;
    private final ModelRenderer mouthC;
    private final ModelRenderer toothCT0;
    private final ModelRenderer toothCB0;
    private final ModelRenderer toothCT1;
    private final ModelRenderer toothCB1;
    private final ModelRenderer toothCT2;
    private final ModelRenderer toothCB2;
    private final ModelRenderer rib0;
    private final ModelRenderer rib1;
    private final ModelRenderer rib2;
    private final ModelRenderer lump1;
    private final ModelRenderer lump2;
    private final ModelRenderer lump3;
    private final ModelRenderer neck;
    private final ModelRenderer head;
    private final ModelRenderer nose;
    private final ModelRenderer spike1;
    private final ModelRenderer spike2;
    private final ModelRenderer jaw;
    private final ModelRenderer toothJ0;
    private final ModelRenderer toothJ1;
    private final ModelRenderer toothJ2;
    private final ModelRenderer upperL;
    private final ModelRenderer foreL;
    private final ModelRenderer handL;
    private final ModelRenderer clawL0;
    private final ModelRenderer clawL1;
    private final ModelRenderer clawL2;
    private final ModelRenderer upperR;
    private final ModelRenderer foreR;
    private final ModelRenderer handR;
    private final ModelRenderer clawR0;
    private final ModelRenderer clawR1;
    private final ModelRenderer clawR2;
    private final ModelRenderer tentL0;
    private final ModelRenderer tentL1;
    private final ModelRenderer tentL2;
    private final ModelRenderer tentL3;
    private final ModelRenderer tentL4;
    private final ModelRenderer tentR0;
    private final ModelRenderer tentR1;
    private final ModelRenderer tentR2;
    private final ModelRenderer tentR3;
    private final ModelRenderer tentR4;

    public ModelInfectedVillager() {
        this.textureWidth = 128;
        this.textureHeight = 128;
        root.setRotationPoint(0.0F, 8.0F, 0.0F); // 24 / 0.75 - 24: после уменьшения ноги остаются на земле
        thighL = part(0, 12, -1.5F, 0F, -1.5F, 3, 6, 3, 2.6F, 12F, 0F);
        thighL.rotateAngleX = -0.35F; thighL.rotateAngleY = 0F; thighL.rotateAngleZ = 0F;
        shinL = part(50, 12, -1.5F, 0F, -1.5F, 3, 5, 3, 0F, 6F, 0F);
        shinL.rotateAngleX = 0.7F; shinL.rotateAngleY = 0F; shinL.rotateAngleZ = 0F;
        footL = part(74, 12, -2F, 0F, -4F, 4, 1, 6, 0F, 5F, 0F);
        footL.rotateAngleX = -0.35F; footL.rotateAngleY = 0F; footL.rotateAngleZ = 0F;
        thighR = part(12, 12, -1.5F, 0F, -1.5F, 3, 6, 3, -2.6F, 12F, 0F);
        thighR.rotateAngleX = -0.35F; thighR.rotateAngleY = 0F; thighR.rotateAngleZ = 0F;
        shinR = part(62, 12, -1.5F, 0F, -1.5F, 3, 5, 3, 0F, 6F, 0F);
        shinR.rotateAngleX = 0.7F; shinR.rotateAngleY = 0F; shinR.rotateAngleZ = 0F;
        footR = part(94, 12, -2F, 0F, -4F, 4, 1, 6, 0F, 5F, 0F);
        footR.rotateAngleX = -0.35F; footR.rotateAngleY = 0F; footR.rotateAngleZ = 0F;
        pelvis = part(24, 12, -4F, -3F, -2.5F, 8, 4, 5, 0F, 12F, 0F);
        body = new ModelRenderer(this, 0, 0);
        body.setRotationPoint(0F, 9F, 0F);
        body.rotateAngleX = 0.25F; body.rotateAngleY = 0F; body.rotateAngleZ = 0F;
        lowerTorso = part(100, 0, -3.5F, -6F, -2F, 7, 6, 4, 0F, 0F, 0F);
        chest = new ModelRenderer(this, 0, 0);
        chest.setRotationPoint(0F, -6F, 0F);
        chest.rotateAngleX = 0.3F; chest.rotateAngleY = 0F; chest.rotateAngleZ = 0F;
        chestBox = part(0, 0, -4.5F, -7F, -2.5F, 9, 7, 5, 0F, 0F, 0F);
        mouthC = part(22, 28, -2.5F, -5F, -3.2F, 5, 3, 1, 0F, 0F, 0F);
        toothCT0 = part(66, 28, -2.5F, -5.8F, -3.4F, 1, 1, 1, 0F, 0F, 0F);
        toothCB0 = part(70, 28, -2.25F, -2.3F, -3.4F, 1, 1, 1, 0F, 0F, 0F);
        toothCT1 = part(74, 28, -1F, -5.8F, -3.4F, 1, 1, 1, 0F, 0F, 0F);
        toothCB1 = part(78, 28, -0.75F, -2.3F, -3.4F, 1, 1, 1, 0F, 0F, 0F);
        toothCT2 = part(82, 28, 0.5F, -5.8F, -3.4F, 1, 1, 1, 0F, 0F, 0F);
        toothCB2 = part(86, 28, 0.75F, -2.3F, -3.4F, 1, 1, 1, 0F, 0F, 0F);
        rib0 = part(90, 28, -3.5F, -6.5F, -3.5F, 7, 1, 1, 0F, 0F, 0F);
        rib1 = part(106, 28, -3.5F, -4.3F, -3F, 7, 1, 1, 0F, 0F, 0F);
        rib2 = part(0, 34, -3.5F, -2.1F, -3.5F, 7, 1, 1, 0F, 0F, 0F);
        lump1 = part(114, 12, -2.5F, -7F, 2.5F, 4, 4, 3, 0F, 0F, 0F);
        lump2 = part(68, 21, 1F, -3.5F, 2.5F, 3, 3, 3, 0F, 0F, 0F);
        lump3 = part(12, 28, -3.5F, -2.5F, 2.5F, 3, 3, 2, 0F, 0F, 0F);
        neck = part(80, 21, -1.5F, -3F, -1.5F, 3, 3, 3, 0F, -7F, 0F);
        neck.rotateAngleX = 0.5F; neck.rotateAngleY = 0F; neck.rotateAngleZ = 0F;
        head = part(28, 0, -3F, -6F, -3F, 6, 6, 6, 0F, -3F, 0F);
        head.rotateAngleX = 0.45F; head.rotateAngleY = 0F; head.rotateAngleZ = 0F;
        nose = part(92, 21, -1F, -3F, -5F, 2, 4, 2, 0F, 0F, 0F);
        spike1 = part(34, 28, -2.5F, -9F, -1F, 1, 3, 1, 0F, 0F, 0F);
        spike1.rotateAngleX = 0F; spike1.rotateAngleY = 0F; spike1.rotateAngleZ = -0.2F;
        spike2 = part(38, 28, 1.5F, -8F, 1F, 1, 3, 1, 0F, 0F, 0F);
        spike2.rotateAngleX = 0F; spike2.rotateAngleY = 0F; spike2.rotateAngleZ = 0.25F;
        jaw = part(0, 21, -2.5F, 0F, -5.5F, 5, 2, 5, 0F, -1.5F, 2F);
        jaw.rotateAngleX = 0.15F; jaw.rotateAngleY = 0F; jaw.rotateAngleZ = 0F;
        toothJ0 = part(16, 34, -2.5F, -1F, -5.6F, 1, 1, 1, 0F, 0F, 0F);
        toothJ1 = part(20, 34, -1F, -1F, -5.6F, 1, 1, 1, 0F, 0F, 0F);
        toothJ2 = part(24, 34, 0.5F, -1F, -5.6F, 1, 1, 1, 0F, 0F, 0F);
        upperL = part(76, 0, -1.5F, 0F, -1.5F, 3, 8, 3, 5.8F, -5.5F, 0F);
        upperL.rotateAngleX = -0.25F; upperL.rotateAngleY = 0F; upperL.rotateAngleZ = 0.12F;
        foreL = part(52, 0, -1.5F, 0F, -1.5F, 3, 9, 3, 0F, 8F, 0F);
        foreL.rotateAngleX = -0.55F; foreL.rotateAngleY = 0F; foreL.rotateAngleZ = 0F;
        handL = part(100, 21, -1.5F, 0F, -1.5F, 3, 3, 3, 0F, 9F, 0F);
        clawL0 = part(42, 28, -1.5F, 3F, -0.5F, 1, 3, 1, 0F, 0F, 0F);
        clawL0.rotateAngleX = -0.15F; clawL0.rotateAngleY = 0F; clawL0.rotateAngleZ = 0F;
        clawL1 = part(46, 28, -0.5F, 3F, -0.5F, 1, 3, 1, 0F, 0F, 0F);
        clawL2 = part(50, 28, 0.5F, 3F, -0.5F, 1, 3, 1, 0F, 0F, 0F);
        clawL2.rotateAngleX = 0.15F; clawL2.rotateAngleY = 0F; clawL2.rotateAngleZ = 0F;
        upperR = part(88, 0, -1.5F, 0F, -1.5F, 3, 8, 3, -5.8F, -5.5F, 0F);
        upperR.rotateAngleX = -0.25F; upperR.rotateAngleY = 0F; upperR.rotateAngleZ = -0.12F;
        foreR = part(64, 0, -1.5F, 0F, -1.5F, 3, 9, 3, 0F, 8F, 0F);
        foreR.rotateAngleX = -0.55F; foreR.rotateAngleY = 0F; foreR.rotateAngleZ = 0F;
        handR = part(112, 21, -1.5F, 0F, -1.5F, 3, 3, 3, 0F, 9F, 0F);
        clawR0 = part(54, 28, -1.5F, 3F, -0.5F, 1, 3, 1, 0F, 0F, 0F);
        clawR0.rotateAngleX = -0.15F; clawR0.rotateAngleY = 0F; clawR0.rotateAngleZ = 0F;
        clawR1 = part(58, 28, -0.5F, 3F, -0.5F, 1, 3, 1, 0F, 0F, 0F);
        clawR2 = part(62, 28, 0.5F, 3F, -0.5F, 1, 3, 1, 0F, 0F, 0F);
        clawR2.rotateAngleX = 0.15F; clawR2.rotateAngleY = 0F; clawR2.rotateAngleZ = 0F;
        tentL0 = part(20, 21, -1F, 0F, -1F, 2, 5, 2, 2.6F, -4.5F, 2.6F);
        tentL0.rotateAngleX = 0.55F; tentL0.rotateAngleY = 0F; tentL0.rotateAngleZ = 0.15F;
        tentL1 = part(28, 21, -1F, 0F, -1F, 2, 5, 2, 0F, 5F, 0F);
        tentL1.rotateAngleX = 0.12F; tentL1.rotateAngleY = 0F; tentL1.rotateAngleZ = 0F;
        tentL2 = part(36, 21, -1F, 0F, -1F, 2, 5, 2, 0F, 5F, 0F);
        tentL2.rotateAngleX = 0.12F; tentL2.rotateAngleY = 0F; tentL2.rotateAngleZ = 0F;
        tentL3 = part(124, 21, -0.5F, 0F, -0.5F, 1, 5, 1, 0F, 5F, 0F);
        tentL3.rotateAngleX = 0.12F; tentL3.rotateAngleY = 0F; tentL3.rotateAngleZ = 0F;
        tentL4 = part(0, 28, -0.5F, 0F, -0.5F, 1, 5, 1, 0F, 5F, 0F);
        tentL4.rotateAngleX = 0.12F; tentL4.rotateAngleY = 0F; tentL4.rotateAngleZ = 0F;
        tentR0 = part(44, 21, -1F, 0F, -1F, 2, 5, 2, -2.6F, -4.5F, 2.6F);
        tentR0.rotateAngleX = 0.55F; tentR0.rotateAngleY = 0F; tentR0.rotateAngleZ = -0.15F;
        tentR1 = part(52, 21, -1F, 0F, -1F, 2, 5, 2, 0F, 5F, 0F);
        tentR1.rotateAngleX = 0.12F; tentR1.rotateAngleY = 0F; tentR1.rotateAngleZ = 0F;
        tentR2 = part(60, 21, -1F, 0F, -1F, 2, 5, 2, 0F, 5F, 0F);
        tentR2.rotateAngleX = 0.12F; tentR2.rotateAngleY = 0F; tentR2.rotateAngleZ = 0F;
        tentR3 = part(4, 28, -0.5F, 0F, -0.5F, 1, 5, 1, 0F, 5F, 0F);
        tentR3.rotateAngleX = 0.12F; tentR3.rotateAngleY = 0F; tentR3.rotateAngleZ = 0F;
        tentR4 = part(8, 28, -0.5F, 0F, -0.5F, 1, 5, 1, 0F, 5F, 0F);
        tentR4.rotateAngleX = 0.12F; tentR4.rotateAngleY = 0F; tentR4.rotateAngleZ = 0F;
        root.addChild(thighL);
        thighL.addChild(shinL);
        shinL.addChild(footL);
        root.addChild(thighR);
        thighR.addChild(shinR);
        shinR.addChild(footR);
        root.addChild(pelvis);
        root.addChild(body);
        body.addChild(lowerTorso);
        body.addChild(chest);
        chest.addChild(chestBox);
        chest.addChild(mouthC);
        chest.addChild(toothCT0);
        chest.addChild(toothCB0);
        chest.addChild(toothCT1);
        chest.addChild(toothCB1);
        chest.addChild(toothCT2);
        chest.addChild(toothCB2);
        chest.addChild(rib0);
        chest.addChild(rib1);
        chest.addChild(rib2);
        chest.addChild(lump1);
        chest.addChild(lump2);
        chest.addChild(lump3);
        chest.addChild(neck);
        neck.addChild(head);
        head.addChild(nose);
        head.addChild(spike1);
        head.addChild(spike2);
        head.addChild(jaw);
        jaw.addChild(toothJ0);
        jaw.addChild(toothJ1);
        jaw.addChild(toothJ2);
        chest.addChild(upperL);
        upperL.addChild(foreL);
        foreL.addChild(handL);
        handL.addChild(clawL0);
        handL.addChild(clawL1);
        handL.addChild(clawL2);
        chest.addChild(upperR);
        upperR.addChild(foreR);
        foreR.addChild(handR);
        handR.addChild(clawR0);
        handR.addChild(clawR1);
        handR.addChild(clawR2);
        chest.addChild(tentL0);
        tentL0.addChild(tentL1);
        tentL1.addChild(tentL2);
        tentL2.addChild(tentL3);
        tentL3.addChild(tentL4);
        chest.addChild(tentR0);
        tentR0.addChild(tentR1);
        tentR1.addChild(tentR2);
        tentR2.addChild(tentR3);
        tentR3.addChild(tentR4);
    }

    private ModelRenderer part(int u, int v, float ox, float oy, float oz, int w, int h, int d, float x, float y, float z) {
        ModelRenderer r = new ModelRenderer(this, u, v);
        r.addBox(ox, oy, oz, w, h, d);
        r.setRotationPoint(x, y, z);
        return r;
    }

    @Override
    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
        setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);
        root.render(scale * MODEL_SCALE);
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entity) {
        float walk = limbSwing * 0.6662F;
        float amount = limbSwingAmount;
        float attack = MathHelper.sin(this.swingProgress * (float) Math.PI);

        // ноги: широкий шаг, колено сгибается на заднем махе
        float l = MathHelper.cos(walk) * 1.0F * amount;
        float r = MathHelper.cos(walk + (float) Math.PI) * 1.0F * amount;
        thighL.rotateAngleX = -0.35F + l;
        thighR.rotateAngleX = -0.35F + r;
        shinL.rotateAngleX = 0.7F + Math.max(0.0F, -l) * 0.9F;
        shinR.rotateAngleX = 0.7F + Math.max(0.0F, -r) * 0.9F;
        footL.rotateAngleX = -0.35F - shinL.rotateAngleX + 0.7F;
        footR.rotateAngleX = -0.35F - shinR.rotateAngleX + 0.7F;

        // корпус качается вместе с шагом и «дышит»
        body.rotateAngleX = 0.25F + MathHelper.sin(ageInTicks * 0.08F) * 0.02F + attack * 0.25F;
        body.rotateAngleY = MathHelper.cos(walk) * 0.12F * amount;
        chest.rotateAngleX = 0.3F + MathHelper.sin(ageInTicks * 0.08F + 1.0F) * 0.03F;

        // голова следит за целью
        neck.rotateAngleX = 0.5F + headPitch * 0.0087F;
        head.rotateAngleX = 0.45F + headPitch * 0.0087F;
        head.rotateAngleY = netHeadYaw * 0.0174533F * 0.8F;
        float wide = attack * 0.8F;
        jaw.rotateAngleX = 0.15F + (MathHelper.sin(ageInTicks * 0.15F) + 1.0F) * 0.05F + wide;

        // руки качаются в противофазе с ногами, при атаке поднимаются вперёд и бьют
        upperL.rotateAngleX = -0.25F + r * 0.6F - attack * 1.3F;
        upperR.rotateAngleX = -0.25F + l * 0.6F - attack * 1.3F;
        upperL.rotateAngleZ = 0.12F + MathHelper.cos(ageInTicks * 0.09F) * 0.03F;
        upperR.rotateAngleZ = -0.12F - MathHelper.cos(ageInTicks * 0.09F) * 0.03F;
        foreL.rotateAngleX = -0.55F - attack * 0.5F;
        foreR.rotateAngleX = -0.55F - attack * 0.5F;

        // щупальца на спине извиваются волной
        wave(new ModelRenderer[]{tentL0, tentL1, tentL2, tentL3, tentL4}, ageInTicks, 0.0F, 1.0F);
        wave(new ModelRenderer[]{tentR0, tentR1, tentR2, tentR3, tentR4}, ageInTicks, 1.7F, -1.0F);
    }

    private void wave(ModelRenderer[] chain, float age, float phase, float side) {
        for (int i = 0; i < chain.length; i++) {
            float t = age * 0.12F + phase + i * 0.8F;
            chain[i].rotateAngleX = (i == 0 ? 0.55F : 0.12F) + MathHelper.sin(t) * 0.22F;
            chain[i].rotateAngleZ = (i == 0 ? 0.15F * side : 0.0F) + MathHelper.cos(t) * 0.18F;
        }
    }
}

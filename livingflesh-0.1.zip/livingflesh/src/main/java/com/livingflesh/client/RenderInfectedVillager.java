package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityInfectedVillager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Рисует заражённого жителя собственной моделью. */
public class RenderInfectedVillager extends RenderLiving<EntityInfectedVillager> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_villager.png");

    public RenderInfectedVillager(RenderManager manager) {
        super(manager, new ModelInfectedVillager(), 0.55F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityInfectedVillager entity) {
        return TEXTURE;
    }
}

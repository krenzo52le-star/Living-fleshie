package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSheep;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.util.ResourceLocation;

/** Ванильная модель с заражённым скином. */
public class RenderInfectedSheep extends RenderSheep {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_sheep.png");

    public RenderInfectedSheep(RenderManager manager) {
        super(manager);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntitySheep entity) {
        return TEXTURE;
    }
}

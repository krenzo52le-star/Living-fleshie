package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityInfectedSheep;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Рисует заражённую овцу собственной моделью. */
public class RenderInfectedSheep extends RenderLiving<EntityInfectedSheep> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_sheep.png");

    public RenderInfectedSheep(RenderManager manager) {
        super(manager, new ModelInfectedSheep(), 0.5F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityInfectedSheep entity) {
        return TEXTURE;
    }
}

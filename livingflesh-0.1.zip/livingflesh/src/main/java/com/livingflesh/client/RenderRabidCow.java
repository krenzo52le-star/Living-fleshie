package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityRabidCow;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Рисует бешеную корову собственной моделью. */
public class RenderRabidCow extends RenderLiving<EntityRabidCow> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/rabid_cow.png");

    public RenderRabidCow(RenderManager manager) {
        super(manager, new ModelRabidCow(), 0.8F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityRabidCow entity) {
        return TEXTURE;
    }
}

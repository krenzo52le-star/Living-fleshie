package com.livingflesh.client.gui;

import com.livingflesh.ModBlocks;
import com.livingflesh.ModItems;
import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.entity.EntityInfectedCow;
import com.livingflesh.entity.EntityInfectedPig;
import com.livingflesh.stage.FleshStage;
import net.minecraft.entity.EntityLiving;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

/** Содержимое энциклопедии. Чтобы добавить статью, достаточно добавить одну строку в нужный раздел. */
public final class EncyclopediaData {
    public static final class Article {
        public final String title;
        /** Строки вида «Название|значение» для левой страницы. */
        public final List<String> info;
        public final String text;
        public final Function<World, EntityLiving> entity; // или null
        public final Supplier<ItemStack> icon;              // или null

        Article(String title, List<String> info, String text, Function<World, EntityLiving> entity, Supplier<ItemStack> icon) {
            this.title = title;
            this.info = info;
            this.text = text;
            this.entity = entity;
            this.icon = icon;
        }
    }

    public static final class Category {
        public final String title;
        public final String intro;
        public final List<Article> articles = new ArrayList<>();

        Category(String title, String intro) {
            this.title = title;
            this.intro = intro;
        }
    }

    public static final List<Category> CATEGORIES = new ArrayList<>();

    private static int pct(double v) {
        return (int) Math.round(v * 100.0D);
    }

    private static Article item(String title, String[] info, String text, Supplier<ItemStack> icon) {
        return new Article(title, Arrays.asList(info), text, null, icon);
    }

    private static Article mob(String title, String[] info, String text, Function<World, EntityLiving> entity) {
        return new Article(title, Arrays.asList(info), text, entity, null);
    }

    static {
        FleshStage s1 = FleshStage.INFECTION;
        FleshStage s2 = FleshStage.SPREAD;

        Category stages = new Category("Стадии", "Как заражение растёт вместе с миром.");
        stages.articles.add(item("Стадия 1: Заражение",
                new String[]{"Наступает|день " + s1.startDay,
                        "Рост плоти|медленный",
                        "Радиус|до " + s1.maxRadius + " блоков",
                        "Заражённые|+" + pct(s1.healthBonus) + "% здоровья, +" + pct(s1.damageBonus) + "% урона"},
                "На второй день в мире появляется ядро плоти: примерно в 100 блоках от игрока, на поверхности или глубоко под землёй. "
                        + "От него медленно расползается живая плоть, а из неё выбираются куски плоти и заражают животных.\n\n"
                        + "Пока заражённых мало и они держатся рядом с очагом, но уже опасны: бросаются на игрока и кусают.",
                () -> new ItemStack(ModBlocks.FLESH_CORE)));
        stages.articles.add(item("Стадия 2: Распространение",
                new String[]{"Наступает|день " + s2.startDay,
                        "Рост плоти|быстрый",
                        "Радиус|до " + s2.maxRadius + " блоков",
                        "Заражённые|+" + pct(s2.healthBonus) + "% здоровья, +" + pct(s2.damageBonus) + "% урона, +" + pct(s2.speedBonus) + "% скорости",
                        "По миру|" + pct(s2.worldInfectChance) + "% новых животных заражены"},
                "Плоть разрастается заметно быстрее, а заражённые животные начинают появляться по всему Верхнему миру, а не только возле ядра.\n\n"
                        + "Встреча с ними больше не случайность: путешествуя, ты рано или поздно наткнёшься на заражённую корову или свинью.",
                () -> new ItemStack(ModBlocks.FLESH_BLOCK)));
        stages.articles.add(item("Стадия 3",
                new String[]{"Наступает|день 9", "Заражённые|?"},
                "Данные отсутствуют.\n\nЗаписи об этой стадии не сохранились. Известно лишь, что на девятый день в мире появятся новые виды заражённых.",
                () -> new ItemStack(ModItems.ENCYCLOPEDIA)));
        stages.articles.add(item("Финальная стадия",
                new String[]{"Наступает|день 20", "Заражённые|?"},
                "Данные отсутствуют.\n\nО конце этой истории пока никто не вернулся рассказать.",
                () -> new ItemStack(ModItems.ENCYCLOPEDIA)));
        CATEGORIES.add(stages);

        Category infected = new Category("Заражённые", "Существа, которых изменила плоть.");
        infected.articles.add(mob("Кусок плоти",
                new String[]{"Размер|малый", "Здоровье|8", "Урон|2", "Поведение|охотится на игроков и животных", "Добыча|нет"},
                "Маленькое существо, выросшее из живой плоти. Расползается от ядра, ищет добычу и кусает.\n\n"
                        + "Если укусит животное, то заражает его: корова или свинья превращается в заражённую версию. "
                        + "Само по себе слабое, но в стае становится опасным.",
                EntityFleshPiece::new));
        infected.articles.add(mob("Заражённая корова",
                new String[]{"Размер|средний", "Здоровье|10 (+ бонус стадии)", "Урон|3 (+ бонус стадии)", "Добыча|говядина, кожа, мёртвая плоть (30%)"},
                "Обычная корова, которую захватила плоть. Больше не пасётся мирно: заметив игрока, идёт на него и кусает, а укус вызывает голод.\n\n"
                        + "Выглядит как корова с красными пятнами и наростами. Призывается своим яйцом.",
                EntityInfectedCow::new));
        infected.articles.add(mob("Заражённая свинья",
                new String[]{"Размер|средний", "Здоровье|10 (+ бонус стадии)", "Урон|3 (+ бонус стадии)", "Добыча|свинина, мёртвая плоть (30%)"},
                "Свинья, поражённая плотью. Быстрая и злая, бросается на игрока и кусает до голода.\n\n"
                        + "С заражённых животных падает мёртвая плоть, из которой делают энциклопедию.",
                EntityInfectedPig::new));
        CATEGORIES.add(infected);

        Category mech = new Category("Механики", "Как устроено заражение и что с ним делать.");
        mech.articles.add(item("Ядро плоти",
                new String[]{"Прочность|высокая (как у камня)", "Появляется|со стадии 1", "Место|поверхность или под землёй"},
                "Сердце очага. Появляется в радиусе около 100 блоков от игрока, на поверхности или под землёй, но не в воздухе. "
                        + "От него растёт плоть и спавнятся куски плоти.\n\n"
                        + "Ядро можно разрушить киркой. Очаг затихнет, но примерно через игровые сутки появится новое ядро.",
                () -> new ItemStack(ModBlocks.FLESH_CORE)));
        mech.articles.add(item("Живая плоть",
                new String[]{"Копается|лопатой", "На игрока|замедляет", "На животных|заражает"},
                "Основной блок заражения. Игрок, идущий по плоти, замедляется. Животные, наступившие на неё, с небольшим шансом заражаются.\n\n"
                        + "Растёт от ядра случайным блужданием по природной земле. Постройки игрока она не трогает.",
                () -> new ItemStack(ModBlocks.FLESH_BLOCK)));
        mech.articles.add(item("Заражённая природа",
                new String[]{"Трава|становится заражённой", "Камень|2 варианта вида", "Деревья|бревно и листва"},
                "Перед тем как стать плотью, трава и камень проходят промежуточную стадию заражения: часть заражённых блоков со временем дозревает до плоти.\n\n"
                        + "Деревья заражаются снизу вверх от заражённой земли. Листва больше не опадает, и с неё иногда падает мёртвая плоть.",
                () -> new ItemStack(ModBlocks.INFECTED_LOG)));
        mech.articles.add(item("Растения плоти",
                new String[]{"Стебель|2-5 блоков, растёт вверх", "Лоза|2-3 блока, свисает вниз", "Добыча|мёртвая плоть"},
                "На заражённой земле редко вырастают мясные стебли высотой в несколько блоков.\n\n"
                        + "Из заражённого камня, листвы и плоти свисают лозы. Сквозь них можно пройти, а если срезать верхний блок, упадёт вся лоза.",
                () -> new ItemStack(ModBlocks.FLESH_VINE)));
        mech.articles.add(item("Мёртвая плоть",
                new String[]{"С заражённых|30%", "С листвы и растений|редко", "Применение|энциклопедия"},
                "Добыча с заражённых существ и растений плоти. Пока из неё делают только энциклопедию: 2 мёртвой плоти и обычная книга.",
                () -> new ItemStack(ModItems.DEAD_FLESH)));
        mech.articles.add(item("Команды",
                new String[]{"Доступ|права оператора", "/flesh stage 0-2|выставить стадию", "/flesh core|создать ядро", "/flesh info|состояние"},
                "Для проверки и настройки.\n\n"
                        + "/flesh stage <0|1|2|auto>: сразу выставить стадию мира. auto возвращает автоматический ход по дням.\n"
                        + "/flesh core [расстояние]: создать ядро рядом с тобой.\n"
                        + "/flesh info: показать стадию, день и координаты ядер.",
                () -> new ItemStack(ModItems.ENCYCLOPEDIA)));
        CATEGORIES.add(mech);
    }

    private EncyclopediaData() {
    }
}

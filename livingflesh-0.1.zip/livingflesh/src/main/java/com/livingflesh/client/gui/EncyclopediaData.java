package com.livingflesh.client.gui;

import com.livingflesh.ModBlocks;
import com.livingflesh.ModItems;
import com.livingflesh.entity.EntityFleshPiece;
import com.livingflesh.entity.EntityInfectedChicken;
import com.livingflesh.entity.EntityInfectedCow;
import com.livingflesh.entity.EntityInfectedPig;
import com.livingflesh.entity.EntityInfectedSheep;
import com.livingflesh.entity.EntityInfectedVillager;
import com.livingflesh.entity.EntityPermadus;
import com.livingflesh.entity.EntityInfectedZombie;
import com.livingflesh.stage.FleshStage;
import net.minecraft.entity.EntityLiving;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

/** Содержимое энциклопедии. Чтобы добавить статью, достаточно добавить одну строку в нужный раздел. */
public final class EncyclopediaData {
    public static final class Article {
        public final String title;
        /** Строки вида «Название|значение» для левой страницы. */
        public final List<String> info;
        public final String text;
        public final Function<World, EntityLiving> entity; // или null
        public final Supplier<ItemStack> icon;              // или null

        Article(String title, List<String> info, String text, Function<World, EntityLiving> entity, Supplier<ItemStack> icon) {
            this.title = title;
            this.info = info;
            this.text = text;
            this.entity = entity;
            this.icon = icon;
        }
    }

    public static final class Category {
        public final String title;
        public final String intro;
        public final List<Article> articles = new ArrayList<>();
        /** Подкатегории (если есть, при открытии раздела сначала показывается их выбор). */
        public final List<Category> subs = new ArrayList<>();

        Category(String title, String intro) {
            this.title = title;
            this.intro = intro;
        }
    }

    public static final List<Category> CATEGORIES = new ArrayList<>();

    private static int pct(double v) {
        return (int) Math.round(v * 100.0D);
    }

    private static Article item(String title, String[] info, String text, Supplier<ItemStack> icon) {
        return new Article(title, Arrays.asList(info), text, null, icon);
    }

    private static Article mob(String title, String[] info, String text, Function<World, EntityLiving> entity) {
        return new Article(title, Arrays.asList(info), text, entity, null);
    }

    static {
        FleshStage s1 = FleshStage.INFECTION;
        FleshStage s2 = FleshStage.SPREAD;

        Category stages = new Category("Стадии", "Как заражение растёт вместе с миром.");
        stages.articles.add(item("Стадия 1: Заражение",
                new String[]{"Наступает|день " + s1.startDay,
                        "Рост плоти|медленный",
                        "Радиус|до " + s1.maxRadius + " блоков",
                        "Заражённые|+" + pct(s1.healthBonus) + "% здоровья, +" + pct(s1.damageBonus) + "% урона, +" + pct(s1.speedBonus) + "% скорости"},
                "На второй день в мире появляется ядро плоти: примерно в 100 блоках от игрока, на поверхности или глубоко под землёй. "
                        + "От него медленно расползается живая плоть, а из неё выбираются разносчики инфекции и заражают животных.\n\n"
                        + "Пока заражённых мало и они держатся рядом с очагом, но уже опасны: бросаются на игрока и кусают.",
                () -> new ItemStack(ModBlocks.FLESH_CORE)));
        stages.articles.add(item("Стадия 2: Распространение",
                new String[]{"Наступает|день " + s2.startDay,
                        "Рост плоти|быстрый",
                        "Радиус|до " + s2.maxRadius + " блоков",
                        "Заражённые|+" + pct(s2.healthBonus) + "% здоровья, +" + pct(s2.damageBonus) + "% урона, +" + pct(s2.speedBonus) + "% скорости",
                        "По миру|" + pct(s2.worldInfectChance) + "% новых животных заражены"},
                "Плоть разрастается заметно быстрее, а заражённые животные начинают появляться по всему Верхнему миру, а не только возле ядра.\n\n"
                        + "Встреча с ними больше не случайность: путешествуя, ты рано или поздно наткнёшься на заражённую корову или свинью.",
                () -> new ItemStack(ModBlocks.FLESH_BLOCK)));
        FleshStage s3 = FleshStage.MUTATION;
        stages.articles.add(item("Стадия 3: Мутация",
                new String[]{"Наступает|день " + s3.startDay,
                        "Рост плоти|очень быстрый",
                        "Радиус|до " + s3.maxRadius + " блоков",
                        "Заражённые|+" + pct(s3.healthBonus) + "% здоровья, +" + pct(s3.damageBonus) + "% урона, +" + pct(s3.speedBonus) + "% скорости, броня и устойчивость к отдаче",
                        "По миру|" + pct(s3.worldInfectChance) + "% новых животных заражены",
                        "Дикие разносчики|изредка вдали от очага"},
                "Плоть мутирует. Заражённые становятся заметно крепче: больше здоровья, урона и скорости, к тому же появляется броня, и их труднее отбросить. "
                        + "Заражёнными рождаются почти половина новых животных.\n\n"
                        + "Разносчики инфекции изредка начинают появляться далеко от очага, прямо на пути у путников. "
                        + "Те, кто уже заражён, подтягиваются до новой стадии сами.",
                () -> new ItemStack(ModBlocks.FLESH_VINE)));
        FleshStage s4 = FleshStage.RETRIBUTION;
        stages.articles.add(item("Стадия 4: Расплата",
                new String[]{"Наступает|день " + s4.startDay,
                        "Радиус|до " + s4.maxRadius + " блоков",
                        "Заражённые|+" + pct(s4.healthBonus) + "% здоровья, +" + pct(s4.damageBonus) + "% урона, +" + pct(s4.speedBonus) + "% скорости, крепкая броня",
                        "По миру|" + pct(s4.worldInfectChance) + "% новых существ заражены",
                        "Ядра|появляются втрое реже",
                        "Разносчики инфекции|больше не появляются",
                        "Каратели|изредка появляются сами"},
                "Разносчики инфекции больше не появляются. Ядра появляются заметно реже, зато больше половины новых существ рождается заражёнными, а те, что уже заражены, становятся ещё крепче.\n\n"
                        + "Теперь за теми, кто выжил, приходят Каратели: огромные Пермадусы, которые изредка появляются сами и идут на игрока.",
                () -> new ItemStack(ModBlocks.FLESH_CORE)));
        stages.articles.add(item("Финальная стадия",
                new String[]{"Наступает|?", "Заражённые|?"},
                "Данные отсутствуют.\n\nО конце этой истории пока никто не вернулся рассказать.",
                () -> new ItemStack(ModItems.ENCYCLOPEDIA)));
        CATEGORIES.add(stages);

        Category infected = new Category("Заражённые", "Существа плоти и те, кого она изменила.");
        Category natural = new Category("Естественные", "Существа плоти, которые появляются сами.");
        Category inf = new Category("Заражённые", "Обычные мобы, заражённые плотью.");
        Category permadus = new Category("Пермадус", "Огромное существо, покрытое плотью.");
        Category adaptus = new Category("Адаптус", "Скоро будет.");
        Category verakdus = new Category("Веракдус", "Скоро будет.");
        permadus.articles.add(mob("Каратель",
                new String[]{"Размер|3 блока", "Здоровье|90", "Урон|9", "Скорость|медленный", "Появление|стадия 4, редко"},
                "Каратель — Пермадус: двуногое существо, целиком покрытое плотью. Из его тела торчит множество конечностей, которые постоянно дёргаются, потому что ходить ему тяжело.\n\n"
                        + "Появляется сам на стадии 4 (редко), а ещё его можно призвать яйцом. Укус вызывает голод.",
                EntityPermadus::new));
        infected.subs.add(natural);
        infected.subs.add(inf);
        infected.subs.add(permadus);
        infected.subs.add(adaptus);
        infected.subs.add(verakdus);
        natural.articles.add(mob("Разносчик инфекции",
                new String[]{"Размер|с курицу", "Здоровье|6", "Урон|1,5", "Скорость|очень быстрый", "Облик|кривое, паукообразное", "Добыча|нет"},
                "Быстрое насекомоподобное существо, похожее на кривого паука: ноги разной длины, опухоли, жвалы. Выбирается из ядра, ищет добычу и бросается на неё прыжком.\n\n"
                        + "Если укусит животное, заражает его: корова, свинья, овца, курица, зомби или житель превращаются в заражённую версию. "
                        + "Игрока кусает слабо и голода не вызывает, но заражает всё вокруг.",
                EntityFleshPiece::new));
        inf.articles.add(mob("Заражённая корова",
                new String[]{"Размер|средний", "Здоровье|10 (+ бонус стадии)", "Урон|3 (+ бонус стадии)", "Добыча|только мёртвая плоть (30%)"},
                "Обычная корова, которую захватила плоть. Больше не пасётся мирно: заметив игрока, идёт на него и кусает, а укус вызывает голод.\n\n"
                        + "Выглядит как корова с красными пятнами и наростами. Призывается своим яйцом.",
                EntityInfectedCow::new));
        inf.articles.add(mob("Заражённая свинья",
                new String[]{"Размер|средний", "Здоровье|10 (+ бонус стадии)", "Урон|3 (+ бонус стадии)", "Добыча|только мёртвая плоть (30%)"},
                "Свинья, поражённая плотью. Быстрая и злая, бросается на игрока и кусает до голода.\n\n"
                        + "С заражённых животных падает мёртвая плоть, из которой делают энциклопедию.",
                EntityInfectedPig::new));
        inf.articles.add(mob("Заражённая овца",
                new String[]{"Размер|средний", "Здоровье|8 (+ бонус стадии)", "Урон|3 (+ бонус стадии)", "Добыча|только мёртвая плоть (30%)"},
                "Овца, с которой слезла шерсть, а на её месте выросла плоть. Не пасётся, а бросается на игрока и кусает.\n\n"
                        + "Шерсти и баранины с неё не получить.",
                EntityInfectedSheep::new));
        inf.articles.add(mob("Заражённая курица",
                new String[]{"Размер|малый", "Здоровье|4 (+ бонус стадии)", "Урон|2 (+ бонус стадии)", "Добыча|только мёртвая плоть (30%)"},
                "Курица, которая больше не несёт яйца. Маленькая и быстрая, поэтому её трудно сразу заметить, а кусается больно.\n\n"
                        + "Перьев и курятины с неё не падает.",
                EntityInfectedChicken::new));
        inf.articles.add(mob("Заражённый зомби",
                new String[]{"Размер|как у игрока", "Здоровье|20 (+ бонус стадии)", "Урон|3 (+ бонус стадии)", "Добыча|кость из плоти (45%)"},
                "Зомби, в которого проросла плоть. Движется так же, как обычный, но плоть делает его крепче: с каждой стадией у него больше здоровья и урона.\n\n"
                        + "Гнилой и мёртвой плоти с него не падает. Вместо неё с шансом 45% остаётся кость из плоти.",
                EntityInfectedZombie::new));
        inf.articles.add(mob("Заражённый житель",
                new String[]{"Размер|крупный, около 2 блоков", "Здоровье|24 (+ бонус стадии)", "Урон|4 (+ бонус стадии)", "Облик|сутулый, с когтями и щупальцами", "Добыча|только мёртвая плоть (30%)"},
                "Бывший житель деревни, которого изменила плоть. Сутулый, с неестественно длинными руками, когтями, раскрывающейся пастью и двумя щупальцами на спине.\n\n"
                        + "Не торгует и не прячется. Заметив игрока, бросается на него, а укус вызывает голод. Разносчик инфекции, укусивший жителя, делает его таким.",
                EntityInfectedVillager::new));
        CATEGORIES.add(infected);

        Category mech = new Category("Механики", "Как устроено заражение и что с ним делать.");
        mech.articles.add(item("Ядро плоти",
                new String[]{"Прочность|высокая (как у камня)", "Появляется|со стадии 1", "Место|поверхность или под землёй"},
                "Сердце очага. Появляется в радиусе около 100 блоков от игрока, на поверхности или под землёй, но не в воздухе. "
                        + "От него растёт плоть и спавнятся разносчики инфекции.\n\n"
                        + "Ядро можно разрушить киркой. Очаг затихнет, но примерно через игровые сутки появится новое ядро.",
                () -> new ItemStack(ModBlocks.FLESH_CORE)));
        mech.articles.add(item("Живая плоть",
                new String[]{"Копается|лопатой", "На игрока|замедляет", "На животных|заражает"},
                "Основной блок заражения. Игрок, идущий по плоти, замедляется. Животные, наступившие на неё, с небольшим шансом заражаются.\n\n"
                        + "Растёт от ядра случайным блужданием по природной земле. Постройки игрока она не трогает.",
                () -> new ItemStack(ModBlocks.FLESH_BLOCK)));
        mech.articles.add(item("Заражённая природа",
                new String[]{"Трава|становится заражённой", "Камень|2 варианта вида", "Деревья|бревно и листва"},
                "Перед тем как стать плотью, трава и камень проходят промежуточную стадию заражения: часть заражённых блоков со временем дозревает до плоти.\n\n"
                        + "Деревья заражаются снизу вверх от заражённой земли. Листва больше не опадает, и с неё иногда падает мёртвая плоть.",
                () -> new ItemStack(ModBlocks.INFECTED_LOG)));
        mech.articles.add(item("Растения плоти",
                new String[]{"Стебель|2-5 блоков, растёт вверх", "Лоза|2-3 блока, свисает вниз", "Добыча|мёртвая плоть"},
                "На заражённой земле редко вырастают мясные стебли высотой в несколько блоков.\n\n"
                        + "Из заражённого камня, листвы и плоти свисают лозы. Сквозь них можно пройти, а если срезать верхний блок, упадёт вся лоза.",
                () -> new ItemStack(ModBlocks.FLESH_VINE)));
        mech.articles.add(item("Мёртвая плоть",
                new String[]{"С заражённых|30%", "С листвы и растений|редко", "Применение|энциклопедия"},
                "Добыча с заражённых существ и растений плоти. Пока из неё делают только энциклопедию: 2 мёртвой плоти и обычная книга.",
                () -> new ItemStack(ModItems.DEAD_FLESH)));
        mech.articles.add(item("Кость из плоти",
                new String[]{"С заражённого зомби|45%", "Применение|пока нет"},
                "Кость, обросшая живой плотью. Падает только с заражённых зомби. Пока ни на что не годится, но, судя по всему, пригодится позже.",
                () -> new ItemStack(ModItems.FLESH_BONE)));
        mech.articles.add(item("Команды",
                new String[]{"Доступ|права оператора", "/flesh stage 0-4|выставить стадию", "/flesh core|создать ядро", "/flesh info|состояние"},
                "Для проверки и настройки.\n\n"
                        + "/flesh stage <0|1|2|3|4|auto>: сразу выставить стадию мира. auto возвращает автоматический ход по дням.\n"
                        + "/flesh core [расстояние]: создать ядро рядом с тобой.\n"
                        + "/flesh info: показать стадию, день и координаты ядер.",
                () -> new ItemStack(ModItems.ENCYCLOPEDIA)));
        CATEGORIES.add(mech);
    }

    private EncyclopediaData() {
    }
}

package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityFleshPiece;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

public class RenderFleshPiece extends RenderLiving<EntityFleshPiece> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/flesh_piece.png");

    public RenderFleshPiece(RenderManager manager) {
        super(manager, new ModelFleshPiece(), 0.35F);
    }

    @Override
    protected void preRenderCallback(EntityFleshPiece entity, float partialTicks) {
        net.minecraft.client.renderer.GlStateManager.scale(0.8F, 0.8F, 0.8F); // размер примерно с курицу
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityFleshPiece entity) {
        return TEXTURE;
    }
}

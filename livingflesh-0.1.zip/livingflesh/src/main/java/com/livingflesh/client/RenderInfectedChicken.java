package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderChicken;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.util.ResourceLocation;

/** Ванильная модель с заражённым скином. */
public class RenderInfectedChicken extends RenderChicken {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_chicken.png");

    public RenderInfectedChicken(RenderManager manager) {
        super(manager);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityChicken entity) {
        return TEXTURE;
    }
}

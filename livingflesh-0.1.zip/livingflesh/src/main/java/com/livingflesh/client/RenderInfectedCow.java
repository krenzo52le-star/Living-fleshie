package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import com.livingflesh.entity.EntityInfectedCow;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

/** Рисует заражённую корову собственной моделью. */
public class RenderInfectedCow extends RenderLiving<EntityInfectedCow> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_cow.png");

    public RenderInfectedCow(RenderManager manager) {
        super(manager, new ModelInfectedCow(), 0.6F);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityInfectedCow entity) {
        return TEXTURE;
    }
}

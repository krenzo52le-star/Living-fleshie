package com.livingflesh.client;

import com.livingflesh.LivingFleshMod;
import net.minecraft.client.renderer.entity.RenderCow;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.util.ResourceLocation;

/** Ванильная модель коровы с заражённым скином. */
public class RenderInfectedCow extends RenderCow {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LivingFleshMod.MODID, "textures/entity/infected_cow.png");

    public RenderInfectedCow(RenderManager manager) {
        super(manager);
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityCow entity) {
        return TEXTURE;
    }
}
